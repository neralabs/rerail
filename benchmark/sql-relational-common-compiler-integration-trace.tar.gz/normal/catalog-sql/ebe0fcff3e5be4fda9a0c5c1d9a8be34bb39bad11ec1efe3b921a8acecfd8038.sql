WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM node AS a0n0 WHERE a0n0.kind IN (130) AND NOT (EXISTS (SELECT 1 FROM r3 k WHERE k.file=a0n0.file AND k.node=a0n0.id))
),
-- linear walk target
r1(file,node) AS (
SELECT a2n0.file,a2n0.id FROM node AS a2n1 CROSS JOIN node AS a2n0 ON a2n0.file=a2n1.file AND a2n0.parent=a2n1.id WHERE a2n0.kind IN (161) AND a2n1.kind IN (137,138)
),
-- linear walk stop
r2(file,node) AS MATERIALIZED (
SELECT a3n0.file,a3n0.id FROM node AS a3n0 WHERE a3n0.kind IN (145,154)
),
-- linear walk answers
r3(file,node) AS MATERIALIZED (
SELECT a4n0.file,a4n0.id FROM r1 AS seed4 CROSS JOIN node AS a4n1 ON a4n1.file=seed4.file AND a4n1.id=seed4.node CROSS JOIN node AS a4n0 ON a4n0.file=a4n1.file AND a4n0.parent=a4n1.id
UNION
SELECT a5n0.file,a5n0.id FROM r3 AS seed5 CROSS JOIN node AS a5n1 ON a5n1.file=seed5.file AND a5n1.id=seed5.node CROSS JOIN node AS a5n0 ON a5n0.file=a5n1.file AND a5n0.parent=a5n1.id WHERE NOT (EXISTS (SELECT 1 FROM r2 k WHERE k.file=a5n1.file AND k.node=a5n1.id))
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node