WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n WHERE 1 AND n.kind IN (180,181,201,216,218)
),
outcome1 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work FROM outcome0 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1 FROM outcome1 w CROSS JOIN outcome0 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN (n.kind IN (201)) OR (n.kind IN (180)) OR (n.kind IN (181)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, CASE WHEN w.stopped<0 THEN 0 WHEN w.work=0 THEN -2 ELSE COALESCE(r.c0,0) END,w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe.kind IN (184) THEN 1 ELSE 0 END,w.work-1 FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0 AND w.work>0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 AND (w.low+(w.own=1))>=2)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 AND (w.low+(w.own=1))>=2)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<2) OR 0 THEN 0 WHEN COALESCE(t.low,0)>=2 AND (1) AND (1) THEN 1 ELSE 2 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN (n.kind IN (218)) OR (n.kind IN (216)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.work,n.parent AS next,CASE WHEN d.work>0 AND 256>0 THEN (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent WHERE COALESCE(bound0.kind IN (273),0))) ELSE 0 END AS base FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN d.base THEN 1 ELSE COALESCE(r.c0,0) END AS truth,1+COALESCE(r.c1,0) AS cost FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT s.truth,s.cost FROM component0_0_summary s WHERE d.work>0 AND 256>0 AND NOT d.base AND s.file=d.file AND s.node=d.next)
),
outcome3 AS MATERIALIZED (
SELECT k,MAX(0,work-MIN(cost,256)) AS work,CASE WHEN cost>256 AND work>=256 THEN -1 WHEN work<cost THEN -2 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, CASE WHEN w.stopped<0 THEN 0 WHEN w.work=0 THEN -2 ELSE COALESCE(r.c0,0) END,w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe.kind IN (148) THEN 1 ELSE 0 END,w.work-1 FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0 AND w.work>0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 AND (w.low+(w.own=1))>=2)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 AND (w.low+(w.own=1))>=2)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<2) OR 0 THEN 0 WHEN COALESCE(t.low,0)>=2 AND (1) AND (1) THEN 1 ELSE 2 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.truth>=0
),
component0_0_local(file,node,base,next) AS MATERIALIZED (
SELECT n.file,n.id,(EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent WHERE COALESCE(bound0.kind IN (273),0))),CASE WHEN NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent WHERE COALESCE(bound0.kind IN (273),0))) AND p.id IS NOT NULL AND (p.kind IN (216,218,226)) THEN p.id END
FROM node n LEFT JOIN node p ON p.file=n.file AND p.id=n.parent
WHERE n.kind IN (216,218,226) AND (n.kind IN (216,218,226)) AND n.file IN (SELECT DISTINCT file FROM outcome0)
),
component0_0_summary(file,node,truth,cost,peak) AS MATERIALIZED (
SELECT file,node,base,1,1 FROM component0_0_local WHERE next IS NULL
UNION ALL SELECT l.file,l.node,s.truth,s.cost+1,s.peak+1
FROM component0_0_summary s JOIN component0_0_local l ON l.file=s.file AND l.next=s.node
),
outcome3 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work FROM outcome1 o WHERE o.truth=1 OR o.truth<0
),
outcome4 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome3 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array() END AS payload,0 AS failure,m.work FROM outcome3 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome4 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome4
ORDER BY 1,2,3