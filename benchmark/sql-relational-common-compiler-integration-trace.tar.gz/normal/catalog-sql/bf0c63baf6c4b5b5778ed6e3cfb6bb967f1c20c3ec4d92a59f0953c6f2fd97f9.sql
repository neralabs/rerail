WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM r1 AS seed0 CROSS JOIN node AS a0n0 ON a0n0.file=seed0.file AND a0n0.id=seed0.node WHERE a0n0.kind IN (1) AND node_regex(0,a0n0.file,a0n0.id)
),
-- utility[0]
r1(file,node) AS MATERIALIZED (
SELECT a1n0.file,a1n0.id FROM node AS a1n1 CROSS JOIN node AS a1n0 ON a1n0.file=a1n1.file AND a1n0.parent=a1n1.id CROSS JOIN node AS a1n2 ON a1n2.file=a1n0.file AND a1n2.id=a1n0.prev WHERE a1n1.kind IN (127) AND node_regex(1,a1n2.file,a1n2.id)
UNION
SELECT a2n0.file,a2n0.id FROM r2 AS seed2 CROSS JOIN node AS a2n1 ON a2n1.file=seed2.file AND a2n1.id=seed2.node CROSS JOIN node AS a2n0 ON a2n0.file=a2n1.file AND a2n0.parent=a2n1.id WHERE NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit3 CROSS JOIN node AS a3n1 ON a3n1.file=a2n0.file AND a3n1.id=a2n0.prev WHERE a3n1."end">a3n1.start)) AND a2n1.kind IN (207)
UNION
SELECT a4n0.file,a4n0.id FROM r1 AS seed4 CROSS JOIN node AS a4n1 ON a4n1.file=seed4.file AND a4n1.id=seed4.node CROSS JOIN node AS a4n0 ON a4n0.file=a4n1.file AND a4n0.parent=a4n1.id WHERE a4n1.kind IN (226)
),
-- utility[1]
r2(file,node) AS MATERIALIZED (
SELECT a5n0.file,a5n0.id FROM node AS a5n1 CROSS JOIN node AS a5n0 ON a5n0.file=a5n1.file AND a5n0.parent=a5n1.id CROSS JOIN node AS a5n2 ON a5n2.file=a5n0.file AND a5n2.id=a5n0.prev WHERE a5n1.kind IN (127) AND node_regex(1,a5n2.file,a5n2.id)
UNION
SELECT a6n0.file,a6n0.id FROM r2 AS seed6 CROSS JOIN node AS a6n1 ON a6n1.file=seed6.file AND a6n1.id=seed6.node CROSS JOIN node AS a6n0 ON a6n0.file=a6n1.file AND a6n0.parent=a6n1.id WHERE a6n1.kind IN (226)
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node