WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT relation_memo_reset(0) AS ready
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n CROSS JOIN outcome0 init ON init.ready=1 WHERE 1 AND n.kind IN (207)
),
outcome2 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0,NULL AS c1,NULL AS c2,NULL AS c3 FROM outcome1 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2,r.c3,r.c4,r.c5 FROM outcome2 w CROSS JOIN outcome1 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,NULL AS c1,NULL AS c2,NULL AS c3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0,r.c3 AS e1,r.c4 AS e2,r.c5 AS e3 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3,0 AS u0,0 AS u1,0 AS u2,0 AS u3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0,r.c3 AS e1,r.c4 AS e2,r.c5 AS e3 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth>0 AND NOT (d.u0 OR d.u1 OR d.u2 OR d.u3)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.work,p.truth,p.c0 AS c0,p.c1 AS c1,p.c2 AS c2,p.c3 AS c3 FROM outcome0 d CROSS JOIN relation_pattern_typed p ON p.term=0 AND p.file=d.file AND p.node=d.node AND p.i0 IS d.c0 AND p.i1 IS d.c1 AND p.i2 IS d.c2 AND p.i3 IS d.c3
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2,o.c3 AS c3 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,CASE WHEN d.tested=1 THEN d.e3 ELSE d.c3 END AS c3,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2,(d.u3 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (207) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3,d.u0,d.u1,d.u2,d.u3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,8 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 5 THEN n.kind IN (226) WHEN 6 THEN (n.kind IN (122) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE node_regex(1,a0n1.file,a0n1.id)))) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1 AND CASE WHEN w.pc IN (4,8) AND w.level<256 THEN relation_peak_note(w.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 7 THEN n.parent END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 7 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 7 THEN NULL END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3,d.u0,d.u1,d.u2,d.u3 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3
),
outcome1 AS MATERIALIZED (
SELECT d.*,(0) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.peak<=256-(0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (158) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (149,215)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN ((n.kind IN (215)) OR (n.kind IN (149))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
),
outcome7 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome6 o ON o.k=d.k WHERE o.truth<>0
),
outcome8 AS MATERIALIZED (
SELECT * FROM outcome7 WHERE choice=1
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome8 o ON o.parent=d.k
),
outcome10 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome9
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3,d.u0,d.u1,d.u2,d.u3 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c1 AS c1,s.c2 AS c2,s.c3 AS c3 FROM outcome9 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2,o.c3 AS c3 FROM outcome10 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,COALESCE(d.tested,d.truth) AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,CASE WHEN d.tested=1 THEN d.e3 ELSE d.c3 END AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.c0 AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth=1 AND d.c0 IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,r.c0 AS tree,COALESCE(r.c1,1) AS rank,COALESCE(r.c2,1) AS finish,COALESCE(r.c3,0) AS origin,(0) AS incoming FROM outcome0 d CROSS JOIN node probe ON probe.file=d.file AND probe.id=d.node CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT tree,rank,finish,depth FROM semantic0_0_summary WHERE file=d.file AND node=d.node AND d.work>0 AND (0)<256 AND (probe.kind IN (226)))
),
outcome2 AS MATERIALIZED (
SELECT s.k,s.file,s.node,s.tree,s.rank,s.finish,s.origin,s.incoming,s.incoming AS level,0 AS phase,0 AS own,0 AS uncertain,s.work FROM outcome1 s
UNION ALL
SELECT semantic_entry0_0.k,semantic_entry0_0.file,semantic_entry0_0.node,semantic_entry0_0.tree,semantic_entry0_0.rank,semantic_entry0_0.finish,semantic_entry0_0.origin,semantic_entry0_0.incoming,semantic_entry0_0.level,1,CASE WHEN semantic_entry0_0.level>=256 THEN -1 WHEN semantic_entry0_0.work=0 THEN -2 ELSE r.c0 END,semantic_entry0_0.uncertain,COALESCE(r.c1,semantic_entry0_0.work)
FROM outcome2 semantic_entry0_0 JOIN outcome0 d ON d.k=semantic_entry0_0.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,semantic_entry0_0.file AS file,semantic_entry0_0.node AS node,semantic_entry0_0.work-1 AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE semantic_entry0_0.work>0 AND semantic_entry0_0.level<256
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3
),
outcome1 AS MATERIALIZED (
SELECT d.*,((semantic_entry0_0.level+1)+0) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k3 IS d.c3 AND m.peak<=256-((semantic_entry0_0.level+1)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,COALESCE(r.c2,0) AS fill_cost FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH fill_before AS MATERIALIZED (SELECT relation_cache_fill_steps() AS start WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1),
fill_result AS MATERIALIZED (SELECT b.start,r.c0,r.c1 FROM fill_before b CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,d.work-1) FROM node probe LEFT JOIN relation_value_budget(2,d.file,d.node,CASE WHEN (d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1) AND (((probe.kind IN (1)) OR (probe.kind IN (204)))) THEN d.work-1 END) v ON 1 WHERE probe.file=d.file AND probe.id=d.node AND (d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1)))
SELECT v.c0,v.c1,relation_cache_fill_delta(v.start) FROM fill_result v)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k3 IS d.c3 AND m.vtruth IS d.tested AND m.vcost IS MAX(0,d.work-d.remaining-d.fill_cost) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o) WHERE semantic_entry0_0.phase=0 AND CASE WHEN semantic_entry0_0.phase=0 AND semantic_entry0_0.level<256 THEN relation_peak_note(semantic_entry0_0.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,n.node,w.tree,n.rank,w.finish,w.origin,w.incoming,w.incoming+n.depth-w.origin,0,0,w.uncertain OR w.own=2,w.work
FROM outcome2 w JOIN semantic0_0_ranked n ON n.file=w.file AND n.tree=w.tree AND n.rank=w.rank+1
WHERE w.phase=1 AND (w.own IN (0,2)) AND w.rank<w.finish
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own=0 AND w.uncertain THEN 2 ELSE w.own END AS truth FROM outcome2 w WHERE w.phase=1 AND (NOT (w.own IN (0,2)) OR w.rank=w.finish)
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,COALESCE(d.tested,d.truth) AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.c1 AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth=1 AND d.c1 IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,(0) AS level,0 AS phase,NULL AS parent,d.work AS work,d.work AS start,0 AS fill,NULL AS token,0 AS truth,0 AS uncertain,0 AS cursor
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=0),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS 2000001 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k3 IS d.c3 AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS opened_token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.opened_token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,s.level,CASE WHEN s.hit IS NOT NULL THEN 4 WHEN s.level>=256 OR s.work=0 THEN 3 ELSE 10 END,s.parent,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
s.work,relation_cache_fill_steps(),s.opened_token,
CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,0,0 FROM noted s WHERE s.ready=1) WHERE recursive_entry_1.phase=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=3),
s AS MATERIALIZED (SELECT s.*,CASE WHEN s.token IS NOT NULL THEN relation_peak_close(s.token) END AS measured FROM reached s)
SELECT s.node,s.level,4,s.parent,s.work,s.start,s.fill,NULL,COALESCE(m.truth,s.truth),s.uncertain,s.cursor FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND s.truth>=0 AND s.token IS NOT NULL THEN 1 END AND m.clause IS 0 AND m.utility IS 2000001 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k3 IS d.c3 AND m.vtruth IS s.truth AND m.vcost IS MAX(0,s.start-s.work-relation_cache_fill_delta(s.fill)) AND m.vpeak IS s.measured WHERE COALESCE(s.measured,0)>=0) WHERE recursive_entry_1.phase=3
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=4)
SELECT COALESCE(p.c0,s.node),COALESCE(p.c1,s.level),CASE WHEN s.parent IS NULL THEN 5 WHEN s.truth IN (0,2) THEN p.c7 ELSE 3 END,p.parent,s.work,p.c2,p.c3,p.c4,s.truth,COALESCE(p.c5,0) OR s.truth=2,p.c6
FROM s LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.parent IS NOT NULL THEN 2 END AND p.h IS s.parent) WHERE recursive_entry_1.phase=4
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=10) SELECT s.node,s.level,CASE WHEN r.c0 IN (0,2) THEN 11 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,recursive_entry_1.node AS node,recursive_entry_1.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE recursive_entry_1.phase=10
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN (n.kind IN (232)) AND (node_regex(3,n.file,n.id)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (231) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (232)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (232)) AND (NOT (node_regex(3,n.file,n.id)))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
),
outcome7 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome6 o ON o.k=d.k WHERE o.truth<>0
),
outcome8 AS MATERIALIZED (
SELECT * FROM outcome7 WHERE choice=1
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome8 o ON o.parent=d.k
),
outcome10 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome9
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,v.truth AS tested,v.work AS remaining FROM outcome2 d LEFT JOIN relation_value_budget(4,d.file,d.node,CASE WHEN d.truth=0 THEN d.work END) v ON 1
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,v.truth AS tested,v.work AS remaining FROM outcome1 d LEFT JOIN relation_value_budget(5,d.file,d.node,CASE WHEN d.truth>0 AND NOT (0) THEN d.work END) v ON 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,v.work,v.truth FROM outcome1 d CROSS JOIN relation_value_budget(6,d.file,d.node,d.work) v
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,v.truth AS tested,v.work AS remaining FROM outcome6 d LEFT JOIN relation_value_budget(7,d.file,d.node,CASE WHEN d.truth=0 THEN d.work END) v ON 1
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome8 s
),
outcome10 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome9
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,v.truth AS tested,v.work AS remaining FROM outcome5 d LEFT JOIN relation_value_budget(8,d.file,d.node,CASE WHEN d.truth>0 AND NOT (0) THEN d.work END) v ON 1
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
) SELECT o.truth,o.work FROM outcome8 o)) WHERE recursive_entry_1.phase=10
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=11),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (child.parent=s.node AND child.id>s.cursor AND child.id<=n."last") AND (1) AND (n.kind IN (226)) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 3 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0
FROM s LEFT JOIN node chosen ON chosen.file=d.file AND chosen.id=s.child LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS chosen."last" AND p.v7 IS 11) WHERE recursive_entry_1.phase=11) SELECT truth,work FROM schedule WHERE phase=5)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,COALESCE(d.tested,d.truth) AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.c2 AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth=1 AND d.c2 IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3
),
outcome1 AS MATERIALIZED (
SELECT d.*,(0) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.peak<=256-(0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN NOT ((probe.kind IN (215)) OR (probe.kind IN (149)) OR (probe.kind IN (148))) THEN 1 ELSE 0 END,d.work-1 FROM node probe WHERE probe.file=d.file AND probe.id=d.node AND (d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1))
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,COALESCE(d.tested,d.truth) AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome9 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.c3 AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 WHERE d.truth=1 AND d.c3 IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3
),
outcome1 AS MATERIALIZED (
SELECT d.*,(0) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 3 AND m.file IS d.file AND m.node IS d.node AND m.peak<=256-(0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN NOT ((probe.kind IN (215)) OR (probe.kind IN (149))) THEN 1 ELSE 0 END,d.work-1 FROM node probe WHERE probe.file=d.file AND probe.id=d.node AND (d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1))
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 3 AND m.file IS d.file AND m.node IS d.node AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome11 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,COALESCE(d.tested,d.truth) AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c3 AS c3 FROM outcome10 d
),
outcome12 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c1 AS c1,s.c2 AS c2,s.c3 AS c3 FROM outcome11 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2,o.c3 AS c3 FROM outcome12 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,7,0,1),(5,4,4,1,0),(6,4,0,5,0),(7,6,6,0,1),(8,5,7,0,1))),
semantic0_0_seed(file,node,active) AS MATERIALIZED (
 SELECT n.file,n.id,CASE WHEN NOT (0) AND (n.kind IN (226)) THEN 1 ELSE 0 END
 FROM node n
 WHERE n.kind IN (226) AND n.file IN (SELECT DISTINCT file FROM outcome1)
),
semantic0_0_domain(file,node) AS MATERIALIZED (
 SELECT file,node FROM semantic0_0_seed
 UNION
 SELECT c.file,c.id FROM semantic0_0_seed s
 CROSS JOIN node c ON c.file=s.file AND c.parent=s.node
 WHERE s.active AND (1)
),
semantic0_0_local(file,node,parent,last,base,active,eligible) AS MATERIALIZED (
 SELECT n.file,n.id,n.parent,n."last",(0),
 CASE WHEN NOT (0) AND (n.kind IN (226)) THEN 1 ELSE 0 END,(1)
 FROM semantic0_0_domain d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
semantic0_0_forest(file,node,tree,depth) AS MATERIALIZED (
 SELECT l.file,l.node,l.node,0 FROM semantic0_0_local l
 LEFT JOIN semantic0_0_local p ON p.file=l.file AND p.node=l.parent
 WHERE NOT l.eligible OR COALESCE(p.active,0)=0
 UNION ALL
 SELECT c.file,c.node,f.tree,f.depth+1
 FROM semantic0_0_forest f
 JOIN semantic0_0_local p ON p.file=f.file AND p.node=f.node AND p.active
 JOIN semantic0_0_local c ON c.file=p.file AND c.parent=p.node AND c.eligible
),
semantic0_0_ranked(file,node,tree,depth,last,base,rank) AS MATERIALIZED (
 SELECT f.file,f.node,f.tree,f.depth,l.last,l.base,
 ROW_NUMBER() OVER (PARTITION BY f.file,f.tree ORDER BY f.node)
 FROM semantic0_0_forest f JOIN semantic0_0_local l ON l.file=f.file AND l.node=f.node
),
semantic0_0_success(file,node,tree,depth,last,rank,success) AS MATERIALIZED (
 SELECT file,node,tree,depth,last,rank,
 MIN(CASE WHEN base THEN rank END) OVER (
 PARTITION BY file,tree ORDER BY rank
 ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING)
 FROM semantic0_0_ranked
),
semantic0_0_events(file,node,tree,position,event,rank) AS MATERIALIZED (
 SELECT file,node,tree,node,0,rank FROM semantic0_0_ranked
 UNION ALL
 SELECT file,node,tree,last,1,NULL FROM semantic0_0_ranked
),
semantic0_0_exits(file,node,tree,event,endrank) AS MATERIALIZED (
 SELECT file,node,tree,event,
 MAX(rank) OVER (PARTITION BY file,tree ORDER BY position,event
 ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
 FROM semantic0_0_events
),
semantic0_0_finished(file,node,tree,depth,rank,finish,truth) AS MATERIALIZED (
 SELECT s.file,s.node,s.tree,s.depth,s.rank,
 CASE WHEN s.success<=e.endrank THEN s.success ELSE e.endrank END,
 CASE WHEN s.success<=e.endrank THEN 1 ELSE 0 END
 FROM semantic0_0_success s JOIN semantic0_0_exits e
 ON e.file=s.file AND e.node=s.node AND e.tree=s.tree AND e.event=1
),
semantic0_0_summary(file,node,tree,depth,rank,finish,truth,cost) AS MATERIALIZED (
 SELECT file,node,tree,depth,rank,finish,truth,finish-rank+1
 FROM semantic0_0_finished
),
outcome5 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c0 AS v0,o.c1 AS v1,o.c2 AS v2,o.c3 AS v3 FROM outcome2 o WHERE o.truth=1 OR o.truth<0
),
outcome6 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome5 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(m.v0,m.v1,m.v2,m.v3) END AS payload,0 AS failure,m.work FROM outcome5 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome6 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome6
ORDER BY 1,2,3