WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT DISTINCT a0n0.file,a0n0.id FROM r1 AS seed0 CROSS JOIN node AS a0n1 ON a0n1.file=seed0.file AND a0n1.id=seed0.node CROSS JOIN node AS a0n0 ON a0n0.file=a0n1.file AND a0n0.id=a0n1.parent WHERE a0n0.kind IN (197) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit1 CROSS JOIN node AS a1n1 ON a1n1.file=a0n0.file AND a1n1.parent=a0n0.id WHERE a1n1.kind IN (147))) AND NOT (node_regex(0,a0n1.file,a0n1.id))
),
-- utility[0]
r1(file,node) AS MATERIALIZED (
SELECT a3n0.file,a3n0.id FROM node AS a3n0 WHERE a3n0.kind IN (216,219) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit4 CROSS JOIN node AS a4n1 ON a4n1.file=a3n0.file AND a4n1.parent=a3n0.id WHERE NOT ((node_regex(1,a4n1.file,a4n1.id) OR a4n1.kind IN (99,100)))))
UNION
SELECT a7n0.file,a7n0.id FROM r1 AS seed7 CROSS JOIN node AS a7n1 ON a7n1.file=seed7.file AND a7n1.id=seed7.node CROSS JOIN node AS a7n0 ON a7n0.file=a7n1.file AND a7n0.id=a7n1.parent WHERE a7n0.kind IN (226)
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node