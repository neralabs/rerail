WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT DISTINCT a0n0.file,a0n0.id FROM r8 AS seed0 CROSS JOIN node AS a0n2 ON a0n2.file=seed0.file AND a0n2.id=seed0.node CROSS JOIN node AS a0n1 ON a0n1.file=a0n2.file AND a0n1.parent=a0n2.id CROSS JOIN node AS a0n0 ON a0n0.file=a0n1.file AND a0n0.parent=a0n1.id CROSS JOIN node AS a0n3 ON a0n3.file=a0n2.file AND a0n3.parent=a0n2.id CROSS JOIN node AS a0n4 ON a0n4.file=a0n3.file AND a0n4.parent=a0n3.id WHERE node_regex(0,a0n0.file,a0n0.id) AND a0n1.kind IN (132,133) AND NOT (EXISTS (SELECT 1 FROM r2 k WHERE k.file=a0n1.file AND k.node=a0n1.id)) AND a0n2.kind IN (131) AND a0n3.kind IN (161) AND a0n4.kind IN (130) AND NOT (EXISTS (SELECT 1 FROM r10 k WHERE k.file=a0n4.file AND k.node=a0n4.id))
),
-- linear walk target
r1(file,node) AS (
SELECT a3n0.file,a3n0.id FROM node AS a3n0 WHERE a3n0.kind IN (132,133)
),
-- linear walk answers
r2(file,node) AS MATERIALIZED (
SELECT a4n0.file,a4n0.id FROM r1 AS seed4 CROSS JOIN node AS a4n1 ON a4n1.file=seed4.file AND a4n1.id=seed4.node CROSS JOIN node AS a4n0 ON a4n0.file=a4n1.file AND a4n0.id=a4n1.next
UNION
SELECT a5n0.file,a5n0.id FROM r2 AS seed5 CROSS JOIN node AS a5n1 ON a5n1.file=seed5.file AND a5n1.id=seed5.node CROSS JOIN node AS a5n0 ON a5n0.file=a5n1.file AND a5n0.id=a5n1.next
),
-- utility[0]
r3(file,node) AS (
SELECT a6n0.file,a6n0.id FROM node AS a6n0 WHERE a6n0.kind IN (145) AND NOT (EXISTS (SELECT 1 FROM r6 k WHERE k.file=a6n0.file AND k.node=a6n0.id)) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit8 CROSS JOIN node AS a8n1 ON a8n1.file=a6n0.file AND a8n1.parent=a6n0.id CROSS JOIN node AS a8n2 ON a8n2.file=a8n1.file AND a8n2.parent=a8n1.id WHERE a8n1.kind IN (161) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit9 CROSS JOIN node AS a9n1 ON a9n1.file=a8n1.file AND a9n1.parent=a8n1.id WHERE NOT (a9n1.kind IN (99,125)))) AND a8n2.kind IN (125)))
),
-- descendant predicate
r4(file,node) AS MATERIALIZED (
SELECT a11n0.file,a11n0.id FROM node AS a11n0 WHERE a11n0.kind IN (203)
),
-- traversal stop
r5(file,node) AS MATERIALIZED (
SELECT a12n0.file,a12n0.id FROM node AS a12n0 WHERE a12n0.kind IN (145,154)
),
-- inverse descendant closure
r6(file,node) AS MATERIALIZED (SELECT n.file,n.parent FROM r4 seed CROSS JOIN node n ON n.file=seed.file AND n.id=seed.node WHERE n.parent IS NOT NULL UNION SELECT n.file,n.parent FROM r6 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.parent IS NOT NULL AND NOT EXISTS (SELECT 1 FROM r5 s WHERE s.file=w.file AND s.node=w.node)),
-- linear walk target
r7(file,node) AS (
SELECT a13n0.file,a13n0.id FROM r3 AS seed13 CROSS JOIN node AS a13n0 ON a13n0.file=seed13.file AND a13n0.id=seed13.node WHERE a13n0.kind IN (145)
),
-- linear walk answers
r8(file,node) AS MATERIALIZED (
SELECT a14n0.file,a14n0.id FROM r7 AS seed14 CROSS JOIN node AS a14n1 ON a14n1.file=seed14.file AND a14n1.id=seed14.node CROSS JOIN node AS a14n0 ON a14n0.file=a14n1.file AND a14n0.parent=a14n1.id
UNION
SELECT a15n0.file,a15n0.id FROM r8 AS seed15 CROSS JOIN node AS a15n1 ON a15n1.file=seed15.file AND a15n1.id=seed15.node CROSS JOIN node AS a15n0 ON a15n0.file=a15n1.file AND a15n0.parent=a15n1.id WHERE NOT (EXISTS (SELECT 1 FROM r5 k WHERE k.file=a15n1.file AND k.node=a15n1.id))
),
-- linear walk target
r9(file,node) AS (
SELECT a17n0.file,a17n0.id FROM node AS a17n0 WHERE a17n0.kind IN (125,127,129)
),
-- linear walk answers
r10(file,node) AS MATERIALIZED (
SELECT a18n0.file,a18n0.id FROM r9 AS seed18 CROSS JOIN node AS a18n1 ON a18n1.file=seed18.file AND a18n1.id=seed18.node CROSS JOIN node AS a18n0 ON a18n0.file=a18n1.file AND a18n0.id=a18n1.next
UNION
SELECT a19n0.file,a19n0.id FROM r10 AS seed19 CROSS JOIN node AS a19n1 ON a19n1.file=seed19.file AND a19n1.id=seed19.node CROSS JOIN node AS a19n0 ON a19n0.file=a19n1.file AND a19n0.id=a19n1.next
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node