WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM r1 AS seed0 CROSS JOIN node AS a0n1 ON a0n1.file=seed0.file AND a0n1.id=seed0.node CROSS JOIN node AS a0n0 ON a0n0.file=a0n1.file AND a0n0.id=a0n1.parent CROSS JOIN node AS a0n2 ON a0n2.file=a0n0.file AND a0n2.id=a0n0.parent WHERE a0n0.kind IN (122) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit1 CROSS JOIN node AS a1n1 ON a1n1.file=a0n0.file AND a1n1.parent=a0n0.id WHERE node_regex(1,a1n1.file,a1n1.id))) AND NOT (EXISTS (SELECT 1 FROM r3 k WHERE k.file=a0n0.file AND k.node=a0n0.id)) AND a0n2.kind IN (108)
UNION
SELECT a3n0.file,a3n0.id FROM r1 AS seed3 CROSS JOIN node AS a3n1 ON a3n1.file=seed3.file AND a3n1.id=seed3.node CROSS JOIN node AS a3n0 ON a3n0.file=a3n1.file AND a3n0.id=a3n1.parent CROSS JOIN node AS a3n2 ON a3n2.file=a3n0.file AND a3n2.id=a3n0.parent CROSS JOIN node AS a3n3 ON a3n3.file=a3n2.file AND a3n3.id=a3n2.parent WHERE a3n0.kind IN (122) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit4 CROSS JOIN node AS a4n1 ON a4n1.file=a3n0.file AND a4n1.parent=a3n0.id WHERE node_regex(1,a4n1.file,a4n1.id))) AND NOT (EXISTS (SELECT 1 FROM r3 k WHERE k.file=a3n0.file AND k.node=a3n0.id)) AND a3n2.kind IN (161) AND a3n3.kind IN (145,154)
),
-- utility[0]
r1(file,node) AS MATERIALIZED (
SELECT a6n0.file,a6n0.id FROM node AS a6n0 CROSS JOIN node AS a6n1 ON a6n1.file=a6n0.file AND a6n1.parent=a6n0.id WHERE a6n0.kind IN (232) AND a6n1.kind IN (104) AND node_regex(0,a6n1.file,a6n1.id)
UNION
SELECT a7n0.file,a7n0.id FROM r1 AS seed7 CROSS JOIN node AS a7n1 ON a7n1.file=seed7.file AND a7n1.id=seed7.node CROSS JOIN node AS a7n0 ON a7n0.file=a7n1.file AND a7n0.id=a7n1.parent WHERE a7n0.kind IN (231)
UNION
SELECT a8n0.file,a8n0.id FROM r1 AS seed8 CROSS JOIN node AS a8n1 ON a8n1.file=seed8.file AND a8n1.id=seed8.node CROSS JOIN node AS a8n0 ON a8n0.file=a8n1.file AND a8n0.id=a8n1.parent WHERE a8n0.kind IN (226)
),
-- linear walk target
r2(file,node) AS (
SELECT a9n0.file,a9n0.id FROM node AS a9n0 WHERE NOT (a9n0.kind IN (99))
),
-- linear walk answers
r3(file,node) AS MATERIALIZED (
SELECT a11n0.file,a11n0.id FROM r2 AS seed11 CROSS JOIN node AS a11n1 ON a11n1.file=seed11.file AND a11n1.id=seed11.node CROSS JOIN node AS a11n0 ON a11n0.file=a11n1.file AND a11n0.id=a11n1.next
UNION
SELECT a12n0.file,a12n0.id FROM r3 AS seed12 CROSS JOIN node AS a12n1 ON a12n1.file=seed12.file AND a12n1.id=seed12.node CROSS JOIN node AS a12n0 ON a12n0.file=a12n1.file AND a12n0.id=a12n1.next
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node