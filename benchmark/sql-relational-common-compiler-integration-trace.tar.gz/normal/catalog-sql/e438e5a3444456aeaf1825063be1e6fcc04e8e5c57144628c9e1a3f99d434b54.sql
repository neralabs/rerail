WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n WHERE 1 AND n.kind IN (207)
),
outcome1 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0,NULL AS c1,NULL AS c2 FROM outcome0 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2,r.c3,r.c4 FROM outcome1 w CROSS JOIN outcome0 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,NULL AS c1,NULL AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0,r.c3 AS e1,r.c4 AS e2 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 WHERE d.truth=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,0 AS u0,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0,r.c3 AS e1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u0 OR d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.work,p.truth,p.c0 AS c0,p.c1 AS c1 FROM outcome0 d CROSS JOIN relation_pattern_typed p ON p.term=0 AND p.file=d.file AND p.node=d.node AND p.i0 IS d.c0 AND p.i1 IS d.c1
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,d.c2 AS c2,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c2 FROM outcome0 d CROSS JOIN relation_bound_budget p ON p.term=1 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c2
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c2 FROM outcome0 d CROSS JOIN relation_bound_budget p ON p.term=2 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c2
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,d.u0,d.u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c1 AS c1,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2 FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,COALESCE(d.tested,d.truth) AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,d.work) FROM node probe LEFT JOIN relation_value_budget(3,d.file,d.c2,CASE WHEN (d.truth=1 AND d.c2 IS NOT NULL) AND (1) THEN d.work END) v ON 1 WHERE probe.file=d.file AND probe.id=d.c2 AND (d.truth=1 AND d.c2 IS NOT NULL))
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,COALESCE(d.tested,d.truth) AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c1 AS c1,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2 FROM outcome6 o) WHERE w.truth>=0
),
outcome2 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c0 AS v0,o.c1 AS v1,o.c2 AS v2 FROM outcome1 o WHERE o.truth=1 OR o.truth<0
),
outcome3 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome2 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(json(relation_list_json(m.v0,m.file)),m.v1,m.v2) END AS payload,0 AS failure,m.work FROM outcome2 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome3 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome3
ORDER BY 1,2,3