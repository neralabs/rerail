WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT relation_memo_reset(0) AS ready
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n CROSS JOIN outcome0 init ON init.ready=1 WHERE 1 AND n.kind IN (231,232)
),
outcome2 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c1 FROM outcome1 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2 FROM outcome2 w CROSS JOIN outcome1 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN (n.kind IN (232)) OR (n.kind IN (231)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c1 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c1 AS c1
),
outcome1 AS MATERIALIZED (
SELECT d.*,(0) AS incoming,m.truth AS hit,m.cost,m.peak,CASE WHEN m.truth IS NOT NULL THEN relation_capture_replay(d.file,d.c1,m.o0) END AS hit1 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 3 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS relation_capture_key(d.c1) AND m.peak<=256-(0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit1 ELSE r.c2 END AS e1,COALESCE(r.c3,0) AS fill_cost FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH fill_before AS MATERIALIZED (SELECT relation_cache_fill_steps() AS start WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1),
fill_result AS MATERIALIZED (SELECT b.start,r.c0,r.c1,r.c2 FROM fill_before b CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c1 AS c1 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.*,p.truth AS parse_truth,p.work AS parse_work,p.parsed_file,p.parsed_node FROM outcome0 d CROSS JOIN relation_parse_budget(0,d.file,d.node,d.work) p
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.parsed_file AS file,d.parsed_node AS node,d.parse_work AS work WHERE d.parse_truth=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1) AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE ((SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (238) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN 1 AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,(1) AS incoming,NULL AS hit,NULL AS cost,NULL AS peak FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (197)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (197) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(1,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.next AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.next IS NOT NULL UNION ALL SELECT w.parent,n.file,n.next,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.next IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (228)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (229) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (228)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome9 s
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,d.tested AS truth FROM outcome5 d WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,(1) AS incoming,NULL AS hit,NULL AS cost,NULL AS peak FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (197)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (197) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(1,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.next AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.next IS NOT NULL UNION ALL SELECT w.parent,n.file,n.next,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.next IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (228)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (229) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (228)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome9 s
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,d.tested AS truth FROM outcome5 d WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.parent END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN w.stopped=0 THEN n.parent END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN w.stopped=0 THEN n.parent END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome6 s
),
outcome8 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome7
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome8 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1),w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1)) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(d.remaining,d.parse_work) AS work,CASE WHEN d.parse_truth=1 THEN d.tested ELSE d.parse_truth END AS truth,CASE WHEN d.parse_truth=1 AND d.tested=1 THEN relation_capture_export(d.c1,relation_parse_export(d.parsed_file,d.file,d.e0)) ELSE d.c1 END AS c1 FROM outcome2 d
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c1 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c1 AS c1
),
outcome1 AS MATERIALIZED (
SELECT d.*,(1) AS incoming,m.truth AS hit,m.cost,m.peak,CASE WHEN m.truth IS NOT NULL THEN relation_capture_replay(d.file,d.c1,m.o0) END AS hit1 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS relation_capture_key(d.c1) AND m.peak<=256-(1)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit1 ELSE r.c2 END AS e1,COALESCE(r.c3,0) AS fill_cost FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH fill_before AS MATERIALIZED (SELECT relation_cache_fill_steps() AS start WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1),
fill_result AS MATERIALIZED (SELECT b.start,r.c0,r.c1,r.c2 FROM fill_before b CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c1 AS c1 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.*,p.truth AS parse_truth,p.work AS parse_work,p.parsed_file,p.parsed_node FROM outcome0 d CROSS JOIN relation_parse_budget(2,d.file,d.node,d.work) p
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e3 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (SELECT parsed_child.c0,parsed_child.c1,parsed_child.c2 FROM (SELECT 1 AS reached WHERE d.parse_truth=1) allowed CROSS JOIN relation_row parsed_child ON (parsed_child.c0,parsed_child.c1,parsed_child.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.parsed_file AS file,d.parsed_node AS node,d.parse_work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (231,232)) ORDER BY candidate.id LIMIT 1) AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v3 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE ((SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (231,232)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c3,0 AS u3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN (n.kind IN (232)) OR (n.kind IN (231)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c3 AS c3,d.u3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e3 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c3 AS c3 WHERE d.truth>0 AND NOT (d.u3)
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 work,r.c0 truth,r.c2 c3 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE owner AS MATERIALIZED (SELECT relation_state_begin() scope WHERE d.file IS NOT NULL),schedule AS (SELECT owner.scope scope,d.file file,d.node node,9 pc,(2) level,d.work work,NULL handle,relation_state_put_owned(owner.scope,0,3,d.c3) env,0 truth FROM owner UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH s AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=2)), entered AS MATERIALIZED (SELECT s.*,f.entry,CASE WHEN s.level<256 THEN relation_peak_note(s.level+1) ELSE 1 END ready FROM s JOIN constant0_0 i ON i.pc=s.pc JOIN constant0_1 f ON f.id=i.a)
SELECT s.scope,s.file,s.node,CASE WHEN s.level>=256 OR s.work=0 THEN 0 ELSE s.entry END,CASE WHEN s.level<256 THEN s.level+1 ELSE s.level END,CASE WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,COALESCE(frame.handle,s.handle),s.env,CASE WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END FROM entered s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.level<256 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (0) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (0) AND frame.v6 IS (0) AND frame.v7 IS (s.env) WHERE s.ready=1) WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=2) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH reached AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=3)),s AS MATERIALIZED (SELECT s.*,i.a,c.child FROM reached s JOIN constant0_0 i ON i.pc=s.pc LEFT JOIN constant0_2 c ON c.pc=s.pc AND c.ordinal=0) SELECT s.scope,s.file,s.node,COALESCE(s.child,0),s.level,s.work,COALESCE(frame.handle,s.handle),s.env,CASE WHEN s.child IS NULL THEN s.a ELSE 0 END FROM s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (CASE WHEN s.a THEN 2 ELSE 3 END) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (0) AND frame.v6 IS (0) AND frame.v7 IS (s.env)) WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=3) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH s AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=4)) SELECT s.scope,s.file,s.node,i.a,s.level,s.work,frame.handle,s.env,0 FROM s JOIN constant0_0 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN 1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (4) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (0) AND frame.v6 IS (0) AND frame.v7 IS (s.env)) WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=4) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH reached AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=5)),s AS MATERIALIZED (SELECT s.*,n."last" bound,CASE s.pc WHEN 7 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=s.file AND (candidate.id>s.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END child FROM reached s JOIN node n ON n.file=s.file AND n.id=s.node) SELECT s.scope,s.file,COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN 0 ELSE i.a END,s.level,s.work,COALESCE(frame.handle,s.handle),s.env,0 FROM s JOIN constant0_0 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (1) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (s.bound) AND frame.v6 IS (0) AND frame.v7 IS (s.env) AND frame.v8 IS (s.child)) WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=5) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH s AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=6)),parsed AS MATERIALIZED (SELECT s.*,p.truth parsed_truth,p.work parsed_work,p.parsed_file,p.parsed_node FROM s CROSS JOIN relation_parse_budget(CASE s.pc WHEN 8 THEN 4 ELSE NULL END,s.file,s.node,s.work) p) SELECT s.scope,CASE WHEN s.parsed_truth=1 THEN s.parsed_file ELSE s.file END,CASE WHEN s.parsed_truth=1 THEN s.parsed_node ELSE s.node END,CASE WHEN s.parsed_truth=1 THEN i.a ELSE 0 END,s.level,s.parsed_work,COALESCE(frame.handle,s.handle),CASE WHEN s.parsed_truth=1 THEN 0 ELSE s.env END,CASE WHEN s.parsed_truth=1 THEN 0 ELSE s.parsed_truth END FROM parsed s JOIN constant0_0 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.parsed_truth=1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (5) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (0) AND frame.v6 IS (0) AND frame.v7 IS (s.env)) WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=6) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH reached AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc=0),popped AS MATERIALIZED (SELECT s.*,frame.parent,frame.c0,frame.c1,frame.c2,frame.c3,frame.c4,frame.c5,frame.c6,frame.c7,frame.c8 FROM reached s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.handle IS NOT NULL THEN 2 END AND frame.h IS s.handle),
classified AS MATERIALIZED (SELECT p.*,CASE WHEN p.c0 IN (2,3) THEN (SELECT child FROM constant0_2 WHERE pc=p.c4 AND ordinal=p.c5+1) END child,CASE WHEN p.c0 IN (2,3) THEN COALESCE((SELECT strict FROM constant0_2 WHERE pc=p.c4 AND ordinal=p.c5),0) WHEN p.c0=1 THEN CASE p.c4 WHEN 7 THEN 1 ELSE 0 END ELSE 0 END strict,CASE WHEN p.c0=1 AND p.truth IN (0,2) THEN CASE p.c4 WHEN 7 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=p.c1 AND (candidate.id>p.c8 AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END END candidate FROM popped p LEFT JOIN node n ON p.c0=1 AND n.file=p.c1 AND n.id=p.c8),
transition AS MATERIALIZED (SELECT p.scope AS scope,CASE WHEN p.handle IS NULL THEN p.file ELSE p.c1 END AS file,
CASE WHEN search_again.handle IS NOT NULL THEN p.candidate WHEN p.handle IS NULL THEN p.node ELSE p.c2 END AS node,
CASE WHEN p.handle IS NULL THEN -1 WHEN again.handle IS NOT NULL THEN p.child WHEN search_again.handle IS NOT NULL THEN (SELECT a FROM constant0_0 WHERE pc=p.c4) ELSE 0 END AS pc,
CASE WHEN p.handle IS NULL THEN p.level ELSE p.c3 END AS level,p.work,COALESCE(again.handle,search_again.handle,p.parent) AS handle,
CASE WHEN p.handle IS NULL THEN p.env WHEN again.handle IS NOT NULL THEN CASE WHEN p.c0=2 THEN p.env ELSE p.c7 END WHEN search_again.handle IS NOT NULL THEN p.c7 WHEN p.c0=4 OR p.truth<>1 OR (p.c0=2 AND p.c6=1) THEN p.c7 WHEN p.c0=5 THEN CASE p.c4 WHEN 8 THEN relation_state_put(p.scope,p.c7,3,relation_capture_export(relation_state_get(p.c7,3),relation_parse_export(p.file,p.c1,relation_state_get(p.env,3)))) ELSE p.c7 END ELSE p.env END AS env,
CASE WHEN p.handle IS NULL THEN p.truth WHEN again.handle IS NOT NULL OR search_again.handle IS NOT NULL THEN 0 WHEN p.c0=4 THEN CASE p.truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE p.truth END WHEN p.truth=0 AND p.c6=1 AND p.c0 IN (1,3) THEN 2 WHEN p.truth=1 AND p.c6=1 AND p.c0=2 THEN 2 ELSE p.truth END AS truth,p.env AS previous_env,p.c7 AS saved_env,p.handle AS previous_frame
FROM classified p LEFT JOIN relation_continuation again ON again.mode IS CASE WHEN p.c0 IN (2,3) AND p.truth>=0 AND NOT (p.c0=2 AND p.truth=0) AND NOT (p.c0=3 AND (p.truth=1 OR (p.truth=2 AND p.strict))) AND p.child IS NOT NULL THEN 1 END AND again.parent_input IS p.parent AND again.v0 IS (p.c0) AND again.v1 IS (p.c1) AND again.v2 IS (p.c2) AND again.v3 IS (p.c3) AND again.v4 IS (p.c4) AND again.v5 IS (p.c5+1) AND again.v6 IS (p.c6 OR p.truth=2) AND again.v7 IS (p.c7) LEFT JOIN relation_continuation search_again ON search_again.mode IS CASE WHEN p.c0=1 AND p.truth IN (0,2) AND NOT (p.truth=2 AND p.strict) AND p.candidate IS NOT NULL THEN 1 END AND search_again.parent_input IS p.parent AND search_again.v0 IS (1) AND search_again.v1 IS (p.c1) AND search_again.v2 IS (p.c2) AND search_again.v3 IS (p.c3) AND search_again.v4 IS (p.c4) AND search_again.v5 IS (p.c5) AND search_again.v6 IS (p.c6 OR p.truth=2) AND search_again.v7 IS (p.c7) AND search_again.v8 IS (p.candidate))
SELECT scope,file,node,pc,level,work,handle,env,truth FROM transition WHERE relation_state_drop(CASE WHEN previous_frame IS NOT NULL AND previous_env<>env AND previous_env<>COALESCE(saved_env,0) THEN previous_env END)=1) WHERE machine.pc=0 UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH state AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc=1) SELECT state.scope,state.file,state.node,0,state.level,r.c1,state.handle,CASE WHEN r.c0=1 THEN relation_state_put(state.scope,state.env,3,r.c2) ELSE state.env END,r.c0 FROM state CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,state.file,state.node,state.work,relation_state_get(state.env,3) AS c3 WHERE state.pc=1
),
outcome1 AS MATERIALIZED (
SELECT d.*,p.truth AS parse_truth,p.work AS parse_work,p.parsed_file,p.parsed_node FROM outcome0 d CROSS JOIN relation_parse_budget(3,d.file,d.node,d.work) p
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.parsed_file AS file,d.parsed_node AS node,d.parse_work AS work WHERE d.parse_truth=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1) AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE ((SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c2,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (238) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u2) THEN CASE WHEN 1 AND (CASE WHEN d.c2 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c2,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c2 END AS c2,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c2 AS c2 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c2 AS c2 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c2 AS c2
),
outcome1 AS MATERIALIZED (
SELECT d.*,((state.level)+0) AS incoming,NULL AS hit,NULL AS cost,NULL AS peak FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c2 AS c2 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c2 AS c2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (197)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (197) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c2 AS c2 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(1,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c2 AS c2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.next AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.next IS NOT NULL UNION ALL SELECT w.parent,n.file,n.next,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.next IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c2 AS c2 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (228)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (229) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c2 AS c2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c2 AS c2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c2 AS c2 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (228)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome9 s
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,d.tested AS truth FROM outcome5 d WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c2 AS c2 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c2 AS c2
),
outcome1 AS MATERIALIZED (
SELECT d.*,((state.level)+0) AS incoming,NULL AS hit,NULL AS cost,NULL AS peak FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c2 AS c2 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c2 AS c2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (197)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (197) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c2 AS c2 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(1,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c2 AS c2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.next AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.next IS NOT NULL UNION ALL SELECT w.parent,n.file,n.next,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.next IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c2 AS c2 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (228)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (229) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c2 AS c2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c2 AS c2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c2 AS c2 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (228)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (228) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome9 s
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,d.tested AS truth FROM outcome5 d WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.parent END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN w.stopped=0 THEN n.parent END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN w.stopped=0 THEN n.parent END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c2 AS c2 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome6 s
),
outcome8 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome7
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2,d.u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c2 AS c2 FROM outcome7 s
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome8 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1),w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (238)) ORDER BY candidate.id LIMIT 1)) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v2 AS c2 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(d.remaining,d.parse_work) AS work,CASE WHEN d.parse_truth=1 THEN d.tested ELSE d.parse_truth END AS truth,CASE WHEN d.parse_truth=1 AND d.tested=1 THEN relation_capture_export(d.c3,relation_parse_export(d.parsed_file,d.file,d.e2)) ELSE d.c3 END AS c3 FROM outcome2 d
) SELECT o.truth,o.work,o.c3 AS c3 FROM outcome3 o)) WHERE machine.pc=1 UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH state AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc=4) SELECT state.scope,state.file,state.node,0,state.level,r.c1,state.handle,CASE WHEN r.c0=1 THEN state.env ELSE state.env END,r.c0 FROM state CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,state.file,state.node,state.work WHERE state.pc=4
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN ((n.kind IN (232)) OR (n.kind IN (231))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome3 s
) SELECT o.truth,o.work FROM outcome4 o)) WHERE machine.pc=4),returned AS MATERIALIZED (SELECT scope,truth,work,relation_state_get(env,3) c3 FROM schedule WHERE pc=-1),closed AS MATERIALIZED (SELECT returned.*,relation_state_end(returned.scope) ready FROM returned) SELECT truth,work,c3 FROM closed WHERE ready=1)
) SELECT o.truth,o.work,o.c3 AS c3 FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e3 ELSE d.c3 END AS c3,(d.u3 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c3 AS c3 FROM outcome5 s
) SELECT o.truth,o.work,o.c3 AS c3 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v3 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (231,232)) ORDER BY candidate.id LIMIT 1),w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (231,232)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v3 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (231,232)) ORDER BY candidate.id LIMIT 1)) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v3 AS c3 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c3 AS c3 FROM outcome3 o))
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(d.remaining,d.parse_work) AS work,CASE WHEN d.parse_truth=1 THEN d.tested ELSE d.parse_truth END AS truth,CASE WHEN d.parse_truth=1 AND d.tested=1 THEN relation_capture_export(d.c1,relation_parse_export(d.parsed_file,d.file,d.e3)) ELSE d.c1 END AS c1 FROM outcome2 d
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome3 o))
SELECT v.c0,v.c1,v.c2,relation_cache_fill_delta(v.start) FROM fill_result v)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e1 AS c1 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS relation_capture_key(d.c1) AND m.vtruth IS d.tested AND m.vcost IS MAX(0,d.work-d.remaining-d.fill_cost) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e1 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o))
SELECT v.c0,v.c1,v.c2,relation_cache_fill_delta(v.start) FROM fill_result v)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e1 AS c1 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 3 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS relation_capture_key(d.c1) AND m.vtruth IS d.tested AND m.vcost IS MAX(0,d.work-d.remaining-d.fill_cost) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e1 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c1 AS c1 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,n.parent node,n.id prior,d.work FROM outcome1 d JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT s.k,s.file,s.node,s.prior,0 phase,0 own,0 stopped,0 open,s.work FROM outcome2 s WHERE s.node IS NOT NULL UNION ALL SELECT w.k,w.file,w.node,w.prior,1,0,COALESCE(r.c0,0),w.open,COALESCE(r.c1,w.work) FROM outcome3 w CROSS JOIN outcome1 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe.kind IN (154) THEN 1 ELSE 0 END,w.work FROM node probe WHERE probe.file=w.file AND probe.id=w.node AND (1)) WHERE w.phase=0 UNION ALL SELECT w.k,w.file,w.node,w.prior,2,COALESCE(r.c0,0),w.stopped,w.open,COALESCE(r.c1,w.work) FROM outcome3 w JOIN node n ON n.file=w.file AND n.id=w.node JOIN node edge ON edge.file=w.file AND edge.id=w.prior CROSS JOIN outcome1 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe.kind IN (145) THEN 1 ELSE 0 END,w.work FROM node probe WHERE probe.file=w.file AND probe.id=w.node AND (w.stopped>=0 AND edge.field=6 AND edge.ffirst=1 AND (1))) WHERE w.phase=1 UNION ALL SELECT w.k,w.file,n.parent,w.node,0,0,0,(w.open OR w.own=2),w.work FROM outcome3 w JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.own=1) AND w.stopped=0 AND n.parent IS NOT NULL
),
outcome4 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.stopped<0 THEN w.stopped WHEN w.own<0 THEN w.own WHEN w.own=1 THEN 1 WHEN w.open OR w.own=2 OR w.stopped=2 THEN 2 ELSE 0 END truth FROM outcome3 w JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.own=1) OR w.stopped<>0 OR n.parent IS NULL)
),
outcome5 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) work,COALESCE(t.truth,0) truth FROM outcome1 d LEFT JOIN outcome4 t ON t.k=d.k
),
outcome6 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome5
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome8 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c1 AS c1 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c1 AS c1 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (145) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (159) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (160) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,w.work) FROM node probe LEFT JOIN relation_value_budget(5,w.file,n.id,CASE WHEN (w.stopped>=0) AND (((probe.kind IN (1)) OR (probe.kind IN (204)))) THEN w.work END) v ON 1 WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,NULL,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (NULL) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (NULL) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.parent END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN w.stopped=0 THEN n.parent END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN w.stopped=0 THEN n.parent END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c1 AS c1 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c1 AS c1
),
outcome1 AS MATERIALIZED (
SELECT d.*,(0) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 4 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS relation_capture_key(d.c1) AND m.peak<=256-(0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,COALESCE(r.c2,0) AS fill_cost FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH fill_before AS MATERIALIZED (SELECT relation_cache_fill_steps() AS start WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1),
fill_result AS MATERIALIZED (SELECT b.start,r.c0,r.c1 FROM fill_before b CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c1 AS c1 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (205) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.*,n.id AS selected FROM outcome0 d LEFT JOIN node n ON n.file=d.file AND n.parent=d.node AND n.field=32 AND n.ffirst=1 AND (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,d.work) AS work,COALESCE(r.c0,0) AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,d.work) FROM node probe LEFT JOIN relation_value_budget(6,d.file,d.selected,CASE WHEN (d.selected IS NOT NULL) AND (((probe.kind IN (1)) OR (probe.kind IN (204)))) THEN d.work END) v ON 1 WHERE probe.file=d.file AND probe.id=d.selected AND (d.selected IS NOT NULL))
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,NULL,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (NULL) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (NULL) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c1 AS c1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(7,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (209) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (155) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (211) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,w.work) FROM node probe LEFT JOIN relation_value_budget(8,w.file,n.id,CASE WHEN (w.stopped>=0) AND (((probe.kind IN (1)) OR (probe.kind IN (204)))) THEN w.work END) v ON 1 WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,NULL,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (NULL) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (NULL) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,NULL,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (NULL) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (NULL) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c1 AS c1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(7,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
) SELECT o.truth,o.work FROM outcome8 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,NULL,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (NULL) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (NULL) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o))
SELECT v.c0,v.c1,relation_cache_fill_delta(v.start) FROM fill_result v)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 4 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS relation_capture_key(d.c1) AND m.vtruth IS d.tested AND m.vcost IS MAX(0,d.work-d.remaining-d.fill_cost) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c1 AS c1 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome6 s
),
outcome8 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome7
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 pc,column2 op,column3 a FROM (VALUES (0,0,0),(1,1,0),(2,2,1),(3,3,0),(4,1,1),(5,2,0),(6,3,1),(7,5,6),(8,6,7),(9,2,0))),
constant0_1 AS MATERIALIZED (SELECT column1 id,column2 entry FROM (VALUES (0,3),(1,8))),
constant0_2 AS MATERIALIZED (SELECT column1 pc,column2 ordinal,column3 child,column4 strict FROM (VALUES (3,0,1,1),(3,1,2,1),(6,0,4,0),(6,1,5,1))),
outcome6 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c1 AS v0 FROM outcome2 o WHERE o.truth=1 OR o.truth<0
),
outcome7 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome6 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(CASE WHEN typeof(m.v0)='blob' THEN json(relation_span_json(m.v0,m.file)) ELSE m.v0 END) END AS payload,0 AS failure,m.work FROM outcome6 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome7 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome7
ORDER BY 1,2,3