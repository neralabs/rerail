WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n WHERE 1 AND n.kind IN (207)
),
outcome1 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0,NULL AS c1,NULL AS c2,NULL AS c3 FROM outcome0 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2,r.c3,r.c4,r.c5 FROM outcome1 w CROSS JOIN outcome0 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,NULL AS c1,NULL AS c2,NULL AS c3,0 AS u0,0 AS u1,0 AS u2,0 AS u3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0,r.c3 AS e1,r.c4 AS e2 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u0 OR d.u1 OR d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,0 AS u0,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.*,n.id AS selected FROM outcome0 d LEFT JOIN node n ON n.file=d.file AND n.parent=d.node AND n.field=14 AND n.ffirst=1 AND (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,d.work) AS work,COALESCE(r.c0,0) AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.selected AS node,d.work AS work WHERE d.selected IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.*,n.id AS selected FROM outcome0 d LEFT JOIN node n ON n.file=d.file AND n.parent=d.node AND n.field=20 AND n.ffirst=1 AND (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,d.work) AS work,COALESCE(r.c0,0) AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.selected AS node,d.work AS work WHERE d.selected IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,24 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 4 THEN node_regex(0,n.file,n.id) WHEN 6 THEN n.kind IN (154) WHEN 8 THEN ((n.kind IN (1) AND node_regex(1,n.file,n.id)) OR relation_pattern(2,n.file,n.id)) WHEN 9 THEN node_regex(3,n.file,n.id) WHEN 11 THEN n.kind IN (204) WHEN 12 THEN (n.kind IN (1) AND node_regex(3,n.file,n.id)) WHEN 14 THEN n.kind IN (207) WHEN 17 THEN n.kind IN (204) WHEN 19 THEN n.kind IN (207) WHEN 20 THEN node_regex(4,n.file,n.id) WHEN 22 THEN n.kind IN (204) WHEN 23 THEN (n.kind IN (1) AND node_regex(4,n.file,n.id)) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node AND candidate.field=28 AND candidate.ffirst=1) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 7 THEN n.parent WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node AND candidate.field=5 AND candidate.ffirst=1) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 13 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node AND candidate.field=14 AND candidate.ffirst=1) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 16 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node AND candidate.field=20 AND candidate.ffirst=1) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node AND candidate.field=14 AND candidate.ffirst=1) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node AND candidate.field=5 AND candidate.ffirst=1) AND (1) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 7 THEN 1 WHEN 10 THEN 1 WHEN 13 THEN 1 WHEN 16 THEN 1 WHEN 18 THEN 1 WHEN 21 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN NULL WHEN 7 THEN CASE WHEN NOT (0) THEN n.parent END WHEN 10 THEN NULL WHEN 13 THEN NULL WHEN 16 THEN NULL WHEN 18 THEN NULL WHEN 21 THEN NULL END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
) SELECT o.truth,o.work FROM outcome2 o)
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.u0,d.u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0,r.c3 AS e1,r.c4 AS e2 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u0 OR d.u1 OR d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c0 FROM outcome0 d CROSS JOIN relation_bound_budget p ON p.term=5 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (216) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome1 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN (n.kind IN (232)) AND (NOT (node_regex(6,n.file,n.id))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (231) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (232)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (232) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN node_regex(6,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome5 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
),
outcome9 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome8 o ON o.k=d.k WHERE o.truth<>0
),
outcome10 AS MATERIALIZED (
SELECT * FROM outcome9 WHERE choice=1
),
outcome11 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome10 o ON o.parent=d.k
),
outcome12 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome11
) SELECT o.truth,o.work FROM outcome12 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN node_regex(7,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN n.kind IN (99) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome6 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome8 s
),
outcome10 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome9
) SELECT o.truth,o.work FROM outcome10 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome4 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome1 d LEFT JOIN outcome3 t ON t.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome4
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,d.c1 AS c1,d.c2 AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c1 FROM outcome0 d CROSS JOIN relation_bound_budget p ON p.term=8 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c1
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN n.named AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (216) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome1 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN (n.kind IN (232)) AND (NOT (node_regex(6,n.file,n.id))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (231) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (232)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (232) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN node_regex(6,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome5 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
),
outcome9 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome8 o ON o.k=d.k WHERE o.truth<>0
),
outcome10 AS MATERIALIZED (
SELECT * FROM outcome9 WHERE choice=1
),
outcome11 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome10 o ON o.parent=d.k
),
outcome12 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome11
) SELECT o.truth,o.work FROM outcome12 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN node_regex(7,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN n.kind IN (99) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome6 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome8 s
),
outcome10 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome9
) SELECT o.truth,o.work FROM outcome10 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome4 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome1 d LEFT JOIN outcome3 t ON t.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome4
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v1 AS c1 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,d.c2 AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c2 FROM outcome0 d CROSS JOIN relation_bound_budget p ON p.term=9 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c2
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c2 AS c2 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c2 AS c2,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u2) THEN CASE WHEN n.named AND (CASE WHEN d.c2 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c2,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c2 END AS c2,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (219) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome1 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (220) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome1 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN (n.kind IN (232)) AND (NOT (node_regex(6,n.file,n.id))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (231) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (232)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (232) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN node_regex(6,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome5 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
),
outcome9 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome8 o ON o.k=d.k WHERE o.truth<>0
),
outcome10 AS MATERIALIZED (
SELECT * FROM outcome9 WHERE choice=1
),
outcome11 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome10 o ON o.parent=d.k
),
outcome12 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome11
) SELECT o.truth,o.work FROM outcome12 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN node_regex(10,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN n.kind IN (99) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome6 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome8 s
),
outcome10 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome9
) SELECT o.truth,o.work FROM outcome10 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome4 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome1 d LEFT JOIN outcome3 t ON t.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome4
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN node_regex(11,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN n.kind IN (99) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome6 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome8 s
),
outcome10 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome9
) SELECT o.truth,o.work FROM outcome10 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome4 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome1 d LEFT JOIN outcome3 t ON t.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome4
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c2 AS c2,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v2 AS c2 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome6 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c0 AS c0,s.c1 AS c1,s.c2 AS c2 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2 FROM outcome8 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c1 AS c1,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2 FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,d.c3 AS c3,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2,d.u3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e3 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c3 AS c3 WHERE d.truth>0 AND NOT (d.u3)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c3 AS c3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e3 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c3 AS c3 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.work,p.truth,p.c0 AS c3 FROM outcome0 d CROSS JOIN relation_pattern_typed p ON p.term=12 AND p.file=d.file AND p.node=d.node AND p.i0 IS d.c3
) SELECT o.truth,o.work,o.c3 AS c3 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e3 ELSE d.c3 END AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c3 AS c3 FROM outcome3 s
) SELECT o.truth,o.work,o.c3 AS c3 FROM outcome4 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,CASE WHEN d.tested=1 THEN d.e3 ELSE d.c3 END AS c3,d.u0,d.u1,d.u2,(d.u3 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c1 AS c1,s.c2 AS c2,s.c3 AS c3 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2,o.c3 AS c3 FROM outcome6 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,4,0,1,0),(5,6,4,0,1),(6,4,5,1,0),(7,6,6,0,1),(8,4,7,1,0),(9,4,0,1,0),(10,6,9,0,1),(11,4,10,1,0),(12,4,0,11,0),(13,6,12,0,8),(14,4,13,8,0),(15,5,23,0,1),(16,6,15,0,1),(17,4,16,1,0),(18,6,17,0,14),(19,4,18,14,0),(20,4,0,1,0),(21,6,20,0,19),(22,4,21,19,0),(23,4,0,22,0),(24,5,23,0,1))),
outcome3 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c3 AS v0,o.c2 AS v1,o.c1 AS v2,o.c0 AS v3 FROM outcome1 o WHERE o.truth=1 OR o.truth<0
),
outcome4 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome3 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(m.v0,m.v1,m.v2,m.v3) END AS payload,0 AS failure,m.work FROM outcome3 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome4 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome4
ORDER BY 1,2,3