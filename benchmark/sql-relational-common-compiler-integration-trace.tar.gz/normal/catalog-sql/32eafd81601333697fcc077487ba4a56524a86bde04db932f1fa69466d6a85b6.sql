WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT DISTINCT a0n0.file,a0n0.id FROM r1 AS seed0 CROSS JOIN node AS a0n2 ON a0n2.file=seed0.file AND a0n2.id=seed0.node CROSS JOIN node AS a0n0 ON a0n0.file=a0n2.file AND a0n0.id=a0n2.parent CROSS JOIN node AS a0n1 ON a0n1.file=a0n0.file AND a0n1.parent=a0n0.id CROSS JOIN node AS a0n3 ON a0n3.file=a0n0.file AND a0n3.id=a0n0.parent WHERE a0n0.kind IN (199) AND a0n1.kind IN (209) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit1 CROSS JOIN node AS a1n1 ON a1n1.file=a0n0.file AND a1n1.parent=a0n0.id WHERE node_regex(0,a1n1.file,a1n1.id))) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit2 CROSS JOIN node AS a2n1 ON a2n1.file=a0n2.file AND a2n1.id=a0n2.prev WHERE a2n1."end">a2n1.start)) AND a0n3.kind IN (122)
),
-- utility[2]
r1(file,node) AS MATERIALIZED (
SELECT a3n0.file,a3n0.id FROM r2 AS seed3 CROSS JOIN node AS a3n1 ON a3n1.file=seed3.file AND a3n1.id=seed3.node CROSS JOIN node AS a3n0 ON a3n0.file=a3n1.file AND a3n0.id=a3n1.parent WHERE a3n0.kind IN (205) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit4 CROSS JOIN node AS a4n1 ON a4n1.file=a3n1.file AND a4n1.id=a3n1.prev WHERE a4n1."end">a4n1.start))
UNION
SELECT a5n0.file,a5n0.id FROM r3 AS seed5 CROSS JOIN node AS a5n1 ON a5n1.file=seed5.file AND a5n1.id=seed5.node CROSS JOIN node AS a5n0 ON a5n0.file=a5n1.file AND a5n0.id=a5n1.parent WHERE a5n0.kind IN (204) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit6 CROSS JOIN node AS a6n1 ON a6n1.file=a5n1.file AND a6n1.id=a5n1.prev WHERE a6n1."end">a6n1.start))
UNION
SELECT a7n0.file,a7n0.id FROM r1 AS seed7 CROSS JOIN node AS a7n1 ON a7n1.file=seed7.file AND a7n1.id=seed7.node CROSS JOIN node AS a7n0 ON a7n0.file=a7n1.file AND a7n0.id=a7n1.parent WHERE a7n0.kind IN (180) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit8 CROSS JOIN node AS a8n1 ON a8n1.file=a7n0.file AND a8n1.parent=a7n0.id WHERE node_regex(3,a8n1.file,a8n1.id)))
UNION
SELECT a9n0.file,a9n0.id FROM r1 AS seed9 CROSS JOIN node AS a9n1 ON a9n1.file=seed9.file AND a9n1.id=seed9.node CROSS JOIN node AS a9n0 ON a9n0.file=a9n1.file AND a9n0.id=a9n1.parent WHERE a9n0.kind IN (226)
),
-- utility[0]
r2(file,node) AS MATERIALIZED (
SELECT a10n0.file,a10n0.id FROM node AS a10n0 WHERE a10n0.kind IN (1)
UNION
SELECT a11n0.file,a11n0.id FROM r2 AS seed11 CROSS JOIN node AS a11n1 ON a11n1.file=seed11.file AND a11n1.id=seed11.node CROSS JOIN node AS a11n0 ON a11n0.file=a11n1.file AND a11n0.id=a11n1.parent WHERE a11n0.kind IN (226)
),
-- utility[1]
r3(file,node) AS MATERIALIZED (
SELECT a12n0.file,a12n0.id FROM node AS a12n0 WHERE a12n0.kind IN (1) AND NOT (node_regex(2,a12n0.file,a12n0.id))
UNION
SELECT a14n0.file,a14n0.id FROM r3 AS seed14 CROSS JOIN node AS a14n1 ON a14n1.file=seed14.file AND a14n1.id=seed14.node CROSS JOIN node AS a14n0 ON a14n0.file=a14n1.file AND a14n0.id=a14n1.parent WHERE a14n0.kind IN (226)
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node