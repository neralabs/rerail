WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT relation_memo_reset(0) ready
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () k,n.file,n.id node,9223372036854775807 work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) ordinal,n.kind IN (231,232) host,(node_regex(0,n.file,n.id)) prefix_may_hold FROM node n CROSS JOIN outcome0 i ON i.ready=1 WHERE 1 AND (1)
),
outcome2 AS MATERIALIZED (
WITH events AS (SELECT k,file,node,work,ordinal native_ordinal,1 real,host FROM outcome1 WHERE host OR prefix_may_hold UNION ALL SELECT NULL,file,NULL,9223372036854775807,MAX(ordinal)+1,0,0 FROM outcome1 GROUP BY file) SELECT k,file,node,work,ROW_NUMBER() OVER (PARTITION BY file ORDER BY native_ordinal) ordinal,host,(native_ordinal-COALESCE(LAG(native_ordinal) OVER (PARTITION BY file ORDER BY native_ordinal),0)-1)*2 gap,real FROM events
),
outcome3 AS (
SELECT NULL k,file,NULL node,0 ordinal,0 truth,9223372036854775807 work,NULL AS c0,NULL AS c3 FROM outcome2 GROUP BY file UNION ALL SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2,r.c3 FROM outcome3 w CROSS JOIN outcome2 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT CASE WHEN w.work<d.gap THEN -2 WHEN NOT d.real THEN 0 WHEN f.c0 IS NOT 0 THEN f.c0 ELSE a.c0 END,CASE WHEN w.work<d.gap THEN 0 WHEN NOT d.real THEN w.work-d.gap WHEN f.c0 IS NOT 0 THEN f.c1 ELSE a.c1 END,CASE WHEN w.work>=d.gap AND d.real THEN CASE WHEN f.c0 IS NOT 0 THEN f.c2 ELSE a.c2 END END,CASE WHEN w.work>=d.gap AND d.real THEN CASE WHEN f.c0 IS NOT 0 THEN NULL ELSE a.c3 END END FROM (SELECT 1) seed CROSS JOIN relation_row f ON (f.c0,f.c1,f.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work-d.gap AS work WHERE w.work>=d.gap AND d.real
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,34 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 8 THEN node_regex(0,n.file,n.id) WHEN 11 THEN n.kind IN (226) WHEN 12 THEN n.kind IN (216,217,219,221,222,223) WHEN 16 THEN node_regex(1,n.file,n.id) WHEN 19 THEN n.kind IN (218) WHEN 22 THEN n.kind IN (226) WHEN 23 THEN n.kind IN (88,93,94,96,97,98) WHEN 24 THEN n.kind IN (234) WHEN 26 THEN n.kind IN (231) WHEN 27 THEN n.kind IN (234) WHEN 29 THEN n.kind IN (232) WHEN 32 THEN n.kind IN (226) WHEN 33 THEN n.kind IN (88,96,97,98) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1 AND CASE WHEN w.pc IN (4,6,9,13,14,15,17,20,30,34) AND w.level<256 THEN relation_peak_note(w.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN n.next WHEN 7 THEN n.prev WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 7 THEN 1 WHEN 10 THEN 1 WHEN 18 THEN 1 WHEN 21 THEN 1 WHEN 25 THEN 1 WHEN 28 THEN 1 WHEN 31 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN NULL WHEN 7 THEN NULL WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (196)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c0,d.node) ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o) LEFT JOIN relation_row a ON (a.c0,a.c1,a.c2,a.c3) IS (SELECT r.c0,r.c1,r.c2,r.c3 FROM (SELECT d.file,d.node,f.c1 work,d.host WHERE f.c0=0 AND d.real AND w.work>=d.gap) d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT CASE WHEN d.work=0 THEN -2 ELSE 0 END,MAX(0,d.work-1),NULL,NULL FROM (SELECT 1) unused WHERE NOT d.host UNION ALL SELECT r.c0,r.c1,r.c2,r.c3 FROM (SELECT 1 reached WHERE d.host) allowed CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE initial AS MATERIALIZED (SELECT f.handle FROM relation_continuation f WHERE f.mode IS CASE WHEN d.host THEN 1 END AND f.v0 IS d.file AND f.v1 IS d.node AND f.v2 IS 0 AND f.v3 IS 0 AND f.v4 IS 0),scan(file,node,cursor,bound,level,handle,phase,truth,work,c1,c2) AS (SELECT d.file,d.node,0,0,0,handle,0,0,d.work,NULL AS c1,NULL AS c2 FROM initial UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM scan CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (SELECT * FROM (WITH s AS MATERIALIZED (SELECT scan.file,scan.node,scan.cursor,scan.bound,scan.level,scan.handle,scan.phase,scan.truth,scan.work,scan.c1,scan.c2 WHERE scan.phase=0),e AS MATERIALIZED (SELECT s.*,CASE WHEN s.level<256 AND s.work>0 THEN s.work-1 END allowance,CASE WHEN s.level<256 AND s.work>0 THEN relation_peak_note(s.level+1) END noted FROM s),p AS MATERIALIZED (SELECT e.*,a.truth parsed_truth,a.work parsed_work,a.parsed_file,a.parsed_node FROM e LEFT JOIN relation_parse_budget(CASE WHEN e.level=0 THEN 2 ELSE 3 END,e.file,e.node,e.allowance) a ON 1) SELECT COALESCE(p.parsed_file,p.file),p.node,CASE WHEN p.parsed_truth=1 THEN COALESCE((SELECT candidate.id FROM node candidate WHERE candidate.file=p.parsed_file AND candidate.id>p.parsed_node AND candidate.id<=n."last" AND (1) ORDER BY candidate.id LIMIT 1),n."last"+1) ELSE p.cursor END,COALESCE(n."last",p.bound),p.level+CASE WHEN p.parsed_truth=1 THEN 1 ELSE 0 END,p.handle,CASE WHEN p.parsed_truth=1 THEN 1 ELSE 2 END,CASE WHEN p.level>=256 THEN -1 WHEN p.work=0 THEN -2 ELSE p.parsed_truth END,COALESCE(p.parsed_work,p.work),NULL AS c1,NULL AS c2 FROM p LEFT JOIN node n ON n.file=p.parsed_file AND n.id=p.parsed_node WHERE p.noted IS NOT NULL OR p.allowance IS NULL) UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT scan.file,scan.node,scan.cursor,scan.bound,scan.level,scan.handle,scan.phase,scan.truth,scan.work,scan.c1,scan.c2 WHERE scan.phase=1) SELECT s.file,CASE WHEN s.cursor<=s.bound THEN s.cursor ELSE s.node END,s.cursor,s.bound,s.level,COALESCE(frame.handle,s.handle),CASE WHEN s.cursor>s.bound OR b.c0 IS NOT 0 THEN 2 ELSE 0 END,CASE WHEN s.cursor>s.bound THEN 0 ELSE b.c0 END,COALESCE(b.c1,s.work),b.c2 AS c1,b.c3 AS c2 FROM s CROSS JOIN relation_row b ON (b.c0,b.c1,b.c2,b.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,s.file AS file,s.cursor AS node,s.work AS work WHERE s.cursor<=s.bound
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c1,NULL AS c2,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.c2 AS c2,d.u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN 1 AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c1,d.node) ELSE d.c1 END AS c1,d.c2 AS c2,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,d.c2 AS c2,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u2) THEN CASE WHEN 1 AND (CASE WHEN d.c2 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c2,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c2,d.node) ELSE d.c2 END AS c2,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,34 AS pc,d.work,((s.level)+0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 8 THEN node_regex(0,n.file,n.id) WHEN 11 THEN n.kind IN (226) WHEN 12 THEN n.kind IN (216,217,219,221,222,223) WHEN 16 THEN node_regex(1,n.file,n.id) WHEN 19 THEN n.kind IN (218) WHEN 22 THEN n.kind IN (226) WHEN 23 THEN n.kind IN (88,93,94,96,97,98) WHEN 24 THEN n.kind IN (234) WHEN 26 THEN n.kind IN (231) WHEN 27 THEN n.kind IN (234) WHEN 29 THEN n.kind IN (232) WHEN 32 THEN n.kind IN (226) WHEN 33 THEN n.kind IN (88,96,97,98) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1 AND CASE WHEN w.pc IN (4,6,9,13,14,15,17,20,30,34) AND w.level<256 THEN relation_peak_note(w.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN n.next WHEN 7 THEN n.prev WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 7 THEN 1 WHEN 10 THEN 1 WHEN 18 THEN 1 WHEN 21 THEN 1 WHEN 25 THEN 1 WHEN 28 THEN 1 WHEN 31 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN NULL WHEN 7 THEN NULL WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.c2 AS c2,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v2 AS c2 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,d.u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1,s.c2 AS c2 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome8 o) LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN scan.phase=1 AND s.cursor<=s.bound AND b.c0=0 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS s.file AND frame.v1 IS s.cursor AND frame.v2 IS COALESCE((SELECT candidate.id FROM node candidate WHERE candidate.file=s.file AND candidate.id>s.cursor AND candidate.id<=s.bound AND (1) ORDER BY candidate.id LIMIT 1),s.bound+1) AND frame.v3 IS s.bound AND frame.v4 IS s.level) UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT scan.file,scan.node,scan.cursor,scan.bound,scan.level,scan.handle,scan.phase,scan.truth,scan.work,scan.c1,scan.c2 WHERE scan.phase=2) SELECT p.c0,p.c1,p.c2,p.c3,p.c4,p.parent,CASE WHEN p.parent IS NULL THEN 3 WHEN s.truth=0 THEN 1 ELSE 2 END,s.truth,s.work,CASE WHEN s.truth=1 THEN relation_parse_export(s.file,p.c0,s.c1) END AS c1,CASE WHEN s.truth=1 THEN relation_parse_export(s.file,p.c0,s.c2) END AS c2 FROM s CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN scan.phase=2 THEN 2 END AND p.h IS s.handle)) WHERE scan.phase<>3) SELECT s.truth,s.work,s.c1,s.c2 FROM scan s WHERE s.phase=3)))) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,13,0,1),(5,6,4,0,1),(6,5,13,0,1),(7,6,6,0,5),(8,4,7,1,0),(9,5,13,0,1),(10,6,9,0,1),(11,4,10,1,0),(12,4,0,11,0),(13,5,15,0,12),(14,5,33,1,0),(15,5,29,14,1),(16,4,1,0,0),(17,5,29,1,16),(18,6,17,1,0),(19,4,18,1,0),(20,5,29,0,1),(21,6,20,0,19),(22,4,21,19,0),(23,4,0,22,0),(24,4,0,1,0),(25,6,24,23,0),(26,4,25,23,0),(27,4,0,1,0),(28,6,27,26,0),(29,4,28,26,0),(30,5,33,0,1),(31,6,30,0,1),(32,4,31,1,0),(33,4,0,32,0),(34,5,8,0,1))),
constant0_1 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,13,0,1),(5,6,4,0,1),(6,5,13,0,1),(7,6,6,0,5),(8,4,7,1,0),(9,5,13,0,1),(10,6,9,0,1),(11,4,10,1,0),(12,4,0,11,0),(13,5,15,0,12),(14,5,33,1,0),(15,5,29,14,1),(16,4,1,0,0),(17,5,29,1,16),(18,6,17,1,0),(19,4,18,1,0),(20,5,29,0,1),(21,6,20,0,19),(22,4,21,19,0),(23,4,0,22,0),(24,4,0,1,0),(25,6,24,23,0),(26,4,25,23,0),(27,4,0,1,0),(28,6,27,26,0),(29,4,28,26,0),(30,5,33,0,1),(31,6,30,0,1),(32,4,31,1,0),(33,4,0,32,0),(34,5,8,0,1))),
outcome6 AS MATERIALIZED (
SELECT w.file,w.node,w.truth,w.work,w.c0 AS c0,w.c3 AS c3 FROM outcome3 w WHERE w.truth=1 OR w.truth<0
),
outcome7 AS MATERIALIZED (
SELECT * FROM outcome6 WHERE truth<0
) SELECT 0,m.file,m.node,json_array(CASE WHEN typeof(m.c0)='blob' THEN json(relation_span_json(m.c0,m.file)) ELSE m.c0 END,CASE WHEN typeof(m.c3)='blob' THEN json(relation_span_json(m.c3,m.file)) ELSE m.c3 END),0,m.work FROM outcome6 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome7 f WHERE f.file=m.file) UNION ALL SELECT 0,file,NULL,'[]',truth,work FROM outcome7 ORDER BY 1,2,3