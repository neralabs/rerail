WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM r1 AS seed0 CROSS JOIN node AS a0n0 ON a0n0.file=seed0.file AND a0n0.id=seed0.node WHERE a0n0.kind IN (97)
),
-- utility[0]
r1(file,node) AS MATERIALIZED (
SELECT a1n0.file,a1n0.id FROM node AS a1n1 CROSS JOIN node AS a1n0 ON a1n0.file=a1n1.file AND a1n0.parent=a1n1.id CROSS JOIN node AS a1n2 ON a1n2.file=a1n0.file AND a1n2.id=a1n0.prev WHERE a1n1.kind IN (121) AND node_regex(0,a1n2.file,a1n2.id)
UNION
SELECT a2n0.file,a2n0.id FROM r1 AS seed2 CROSS JOIN node AS a2n1 ON a2n1.file=seed2.file AND a2n1.id=seed2.node CROSS JOIN node AS a2n0 ON a2n0.file=a2n1.file AND a2n0.parent=a2n1.id WHERE a2n1.kind IN (226)
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node