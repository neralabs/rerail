WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n WHERE 1 AND n.kind IN (98)
),
outcome1 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work FROM outcome0 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1 FROM outcome1 w CROSS JOIN outcome0 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (98) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,38 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 5 THEN n.kind IN (226) WHEN 8 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent WHERE COALESCE(bound0.kind IN (196),0)) WHEN 11 THEN node_regex(0,n.file,n.id) WHEN 15 THEN node_regex(0,n.file,n.id) WHEN 17 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE NOT (COALESCE(bound0."end">bound0.start,0))) WHEN 20 THEN node_regex(2,n.file,n.id) WHEN 23 THEN n.kind IN (218) WHEN 26 THEN n.kind IN (226) WHEN 27 THEN n.kind IN (88,93,94,96,97,98) WHEN 28 THEN n.kind IN (234) WHEN 30 THEN n.kind IN (231) WHEN 31 THEN n.kind IN (234) WHEN 33 THEN n.kind IN (232) WHEN 36 THEN n.kind IN (226) WHEN 37 THEN n.kind IN (88,96,97,98) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 6 THEN n.parent WHEN 10 THEN n.prev WHEN 12 THEN n.prev WHEN 14 THEN n.next WHEN 16 THEN n.next WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (88,93,94,96,97,98,218,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 29 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (candidate.kind IN (234)) ORDER BY candidate.id LIMIT 1) WHEN 32 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (candidate.kind IN (234)) ORDER BY candidate.id LIMIT 1) WHEN 35 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (88,96,97,98,226)) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 6 THEN n.kind IN (226) WHEN 10 THEN 1 WHEN 12 THEN 1 WHEN 14 THEN 1 WHEN 16 THEN 1 WHEN 22 THEN 1 WHEN 25 THEN 1 WHEN 29 THEN 1 WHEN 32 THEN 1 WHEN 35 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 6 THEN NULL WHEN 10 THEN NULL WHEN 12 THEN NULL WHEN 14 THEN NULL WHEN 16 THEN NULL WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (88,93,94,96,97,98,218,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 29 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (candidate.kind IN (234)) ORDER BY candidate.id LIMIT 1) WHEN 32 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (candidate.kind IN (234)) ORDER BY candidate.id LIMIT 1) WHEN 35 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (88,96,97,98,226)) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,7,0,1),(5,4,4,1,0),(6,6,5,0,1),(7,5,17,0,6),(8,4,0,1,0),(9,5,19,1,0),(10,6,9,0,1),(11,4,10,1,0),(12,6,11,8,1),(13,5,19,1,0),(14,6,13,0,1),(15,4,14,1,0),(16,6,15,8,12),(17,4,16,12,0),(18,5,37,1,0),(19,5,33,18,1),(20,4,1,0,0),(21,5,33,1,20),(22,6,21,1,0),(23,4,22,1,0),(24,5,33,0,1),(25,6,24,0,23),(26,4,25,23,0),(27,4,0,26,0),(28,4,0,1,0),(29,6,28,27,0),(30,4,29,27,0),(31,4,0,1,0),(32,6,31,30,0),(33,4,32,30,0),(34,5,37,0,1),(35,6,34,0,1),(36,4,35,1,0),(37,4,0,36,0),(38,5,7,0,1))),
outcome3 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work FROM outcome1 o WHERE o.truth=1 OR o.truth<0
),
outcome4 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome3 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array() END AS payload,0 AS failure,m.work FROM outcome3 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome4 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome4
ORDER BY 1,2,3