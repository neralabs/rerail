WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT relation_memo_reset(0) AS ready
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n CROSS JOIN outcome0 init ON init.ready=1 WHERE 1 AND n.kind IN (191)
),
outcome2 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0,NULL AS c1,NULL AS c2,NULL AS c23 FROM outcome1 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2,r.c3,r.c4,r.c5 FROM outcome2 w CROSS JOIN outcome1 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 work,r.c0 truth,r.c2 c0,r.c3 c1,r.c4 c2,r.c5 c23 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5) IS (WITH RECURSIVE owner AS MATERIALIZED (SELECT relation_state_begin() scope WHERE d.file IS NOT NULL),schedule AS (SELECT d.node node,33 pc,(0) level,d.work work,NULL handle,0 truth,0 env,owner.scope scope FROM owner UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7) IS (SELECT * FROM (WITH s AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc=0),popped AS MATERIALIZED (SELECT s.*,frame.parent,frame.c0,frame.c1,frame.c2,frame.c3,frame.c4,frame.c5,frame.c6,frame.c7,frame.c8,frame.c9,frame.c10,frame.c11 FROM s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.handle IS NOT NULL THEN 2 END AND frame.h IS s.handle) SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7 FROM popped p CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7) IS (SELECT * FROM (SELECT p.node,-1,p.level,p.work,NULL,p.truth,p.env,p.scope WHERE p.handle IS NULL) UNION ALL SELECT * FROM (WITH reached AS MATERIALIZED (SELECT p.node AS node,p.pc AS pc,p.level AS level,p.work AS work,p.handle AS handle,p.truth AS truth,p.env AS env,p.scope AS scope,p.parent AS parent,p.c0 AS c0,p.c1 AS c1,p.c2 AS c2,p.c3 AS c3,p.c4 AS c4,p.c5 AS c5,p.c6 AS c6,p.c7 AS c7,p.c8 AS c8,p.c9 AS c9,p.c10 AS c10,p.c11 AS c11 WHERE p.c0=0),closed AS MATERIALIZED (SELECT p.*,relation_peak_close(p.c6) measured FROM reached p)
SELECT p.c1,0,p.c2,p.work,p.parent,COALESCE(m.truth,p.truth),CASE WHEN p.truth=1 THEN p.env ELSE p.c7 END,p.scope FROM closed p JOIN constant0_2 f ON f.id=p.c3 LEFT JOIN relation_memo m ON m.mode IS CASE WHEN f.memo IS NOT NULL AND p.truth>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS f.memo AND m.file IS d.file AND m.node IS p.c1 AND m.vtruth IS p.truth AND m.vcost IS CASE WHEN p.c5 IS NULL THEN p.c4-p.work ELSE MAX(0,p.c4-p.work-relation_cache_fill_delta(p.c5)) END AND m.vpeak IS p.measured WHERE p.measured>=0) UNION ALL SELECT * FROM (SELECT p.c1,0,p.c2,p.work,p.parent,CASE p.truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE p.truth END,p.c6,p.scope WHERE p.c0=4) UNION ALL SELECT * FROM (WITH reached AS MATERIALIZED (SELECT p.node AS node,p.pc AS pc,p.level AS level,p.work AS work,p.handle AS handle,p.truth AS truth,p.env AS env,p.scope AS scope,p.parent AS parent,p.c0 AS c0,p.c1 AS c1,p.c2 AS c2,p.c3 AS c3,p.c4 AS c4,p.c5 AS c5,p.c6 AS c6,p.c7 AS c7,p.c8 AS c8,p.c9 AS c9,p.c10 AS c10,p.c11 AS c11 WHERE p.c0 IN (2,3)),edges AS MATERIALIZED (SELECT p.*,child.strict,child.wl,child.wh,(SELECT child FROM constant0_1 WHERE pc=p.c3 AND ordinal=p.c4+1) next FROM reached p JOIN constant0_1 edge ON edge.pc=p.c3 AND edge.ordinal=p.c4 JOIN constant0_0 child ON child.pc=edge.child),
changed AS MATERIALIZED (SELECT p.*,p.c5 OR p.truth=2 uncertain,CASE WHEN p.c0=2 AND p.truth=1 THEN p.env ELSE p.c7 END current_env,p.c8|CASE WHEN p.truth=2 THEN p.wl ELSE 0 END held_lo,p.c9|CASE WHEN p.truth=2 THEN p.wh ELSE 0 END held_hi FROM edges p),
s AS MATERIALIZED (SELECT p.*,p.next IS NOT NULL AND p.truth>=0 AND CASE p.c0 WHEN 2 THEN p.truth<>0 ELSE p.truth<>1 AND NOT(p.truth=2 AND p.strict) END more,COALESCE((p.held_lo & child.ml)<>0 OR (p.held_hi & child.mh)<>0,0) blocked FROM changed p LEFT JOIN constant0_0 child ON child.pc=p.next)
SELECT p.c1,CASE WHEN again.handle IS NOT NULL THEN CASE WHEN p.c0=2 AND p.blocked THEN 0 ELSE p.next END ELSE 0 END,p.c2,p.work,COALESCE(again.handle,p.parent),
CASE WHEN again.handle IS NOT NULL THEN CASE WHEN p.c0=2 AND p.blocked THEN 2 ELSE 0 END WHEN p.truth<0 THEN p.truth WHEN p.c0=2 AND p.truth=0 THEN 0 WHEN p.c0=3 AND p.truth=1 THEN 1 WHEN p.uncertain THEN 2 WHEN p.c0=2 THEN 1 ELSE 0 END,
CASE WHEN again.handle IS NOT NULL THEN CASE WHEN p.c0=2 THEN p.current_env ELSE p.c6 END WHEN p.c0=3 AND p.truth=1 THEN p.env WHEN p.c0=2 AND p.truth=1 AND NOT p.uncertain THEN p.current_env ELSE p.c6 END,p.scope FROM s p LEFT JOIN relation_continuation again ON again.mode IS CASE WHEN p.more THEN 1 END AND again.parent_input IS p.parent AND again.v0 IS (p.c0) AND again.v1 IS (p.c1) AND again.v2 IS (p.c2) AND again.v3 IS (p.c3) AND again.v4 IS (p.c4+1) AND again.v5 IS (p.uncertain) AND again.v6 IS (p.c6) AND again.v7 IS (p.current_env) AND again.v8 IS (p.held_lo) AND again.v9 IS (p.held_hi)) UNION ALL SELECT * FROM (WITH seed AS MATERIALIZED (SELECT p.node AS node,p.pc AS pc,p.level AS level,p.work AS work,p.handle AS handle,p.truth AS truth,p.env AS env,p.scope AS scope,p.parent AS parent,p.c0 AS c0,p.c1 AS c1,p.c2 AS c2,p.c3 AS c3,p.c4 AS c4,p.c5 AS c5,p.c6 AS c6,p.c7 AS c7,p.c8 AS c8,p.c9 AS c9,p.c10 AS c10,p.c11 AS c11 WHERE p.c0 IN (1,7)), parameters AS MATERIALIZED (SELECT p.*,i.axis,i.ending,i.field,i.body,i.stop,i.minimum,i.maximum,i.count_slot,i.count_offset,i.strict FROM seed p JOIN constant0_3 i ON i.pc=p.c3), answers AS MATERIALIZED (SELECT p.*,CASE WHEN p.axis=0 AND p.stop IS NOT NULL AND p.c0=7 THEN p.c10 ELSE p.truth END own,CASE WHEN p.stop IS NULL THEN 0 WHEN p.axis=0 THEN CASE WHEN p.c0=7 THEN p.truth ELSE 0 END ELSE CASE WHEN p.c0=7 THEN p.truth ELSE p.c10 END END stopped FROM parameters p), counts AS MATERIALIZED (SELECT p.*,p.c7+(p.own=1) low,p.c8+(p.own=2) uncertain,(p.c9 OR p.stopped=2) open FROM answers p), decision AS MATERIALIZED (SELECT p.*,(CASE WHEN p.minimum IS NOT NULL THEN CASE WHEN p.maximum IS NOT NULL THEN p.low>p.maximum WHEN p.count_slot IS NULL THEN p.own=1 AND p.low>=p.minimum ELSE 0 END WHEN p.strict THEN p.own IN (1,2) OR p.c9 ELSE p.own=1 END) decisive,CASE WHEN p.stop IS NULL THEN 1 WHEN p.axis=0 THEN p.c0=7 OR p.own<0 OR (CASE WHEN p.minimum IS NOT NULL THEN CASE WHEN p.maximum IS NOT NULL THEN p.low>p.maximum WHEN p.count_slot IS NULL THEN p.own=1 AND p.low>=p.minimum ELSE 0 END WHEN p.strict THEN p.own IN (1,2) OR p.c9 ELSE p.own=1 END) ELSE p.c0=1 OR p.truth<0 END own_done FROM counts p), advancing AS MATERIALIZED (SELECT p.*,CASE WHEN p.own_done AND p.own>=0 AND p.stopped>=0 AND NOT p.decisive THEN (CASE p.axis WHEN 0 THEN CASE WHEN p.ending=0 THEN CASE WHEN p.field IS NULL THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND candidate.parent=p.c1 AND candidate.id>n."last" ORDER BY candidate.id LIMIT 1) END ELSE CASE WHEN (CASE WHEN p.stopped<>0 THEN n."last"+1 ELSE n.id+1 END)<=p.c5 THEN CASE WHEN p.stopped<>0 THEN n."last"+1 ELSE n.id+1 END END END WHEN 1 THEN CASE WHEN p.ending=1 AND p.stopped=0 THEN n.parent END WHEN 2 THEN CASE WHEN p.ending=1 AND p.stopped=0 THEN n.prev END WHEN 3 THEN CASE WHEN p.ending=1 AND p.stopped=0 THEN n.next END END) END next FROM decision p JOIN node n ON n.file=d.file AND n.id=p.c4), routing AS MATERIALIZED (SELECT p.*,CASE WHEN p.axis=0 AND p.stop IS NOT NULL AND p.c0=1 AND p.own>=0 AND NOT p.decisive THEN 1 WHEN p.axis<>0 AND p.stop IS NOT NULL AND p.c0=7 AND p.truth>=0 THEN 2 WHEN p.own_done AND (p.own<0 OR p.stopped<0 OR p.decisive OR p.next IS NULL) THEN 0 ELSE 3 END route FROM advancing p), chosen AS MATERIALIZED (SELECT p.*,CASE WHEN p.route=3 THEN p.next ELSE p.c4 END chosen,CASE WHEN p.route=3 THEN p.c4 ELSE p.c11 END edge_node,CASE WHEN p.route=1 OR (p.route=3 AND p.axis<>0 AND p.stop IS NOT NULL) THEN 7 ELSE 1 END phase_kind FROM routing p) SELECT CASE WHEN p.route=0 THEN p.c1 ELSE p.chosen END,CASE WHEN p.route=0 OR (p.phase_kind=1 AND p.minimum IS NOT NULL AND p.work=0) THEN 0 WHEN (p.phase_kind=7 OR p.minimum IS NOT NULL OR (((p.axis<>1 OR p.ending=0 OR p.field IS NULL OR (edge.field=p.field AND edge.ffirst=1))) AND (CASE p.c3 WHEN 13 THEN (candidate.kind IN (191)) WHEN 21 THEN (candidate.kind IN (207,226)) WHEN 23 THEN (candidate.kind IN (191)) WHEN 25 THEN (candidate.kind IN (207,226)) WHEN 28 THEN (candidate.kind IN (191,207,226)) WHEN 32 THEN (candidate.kind IN (207,226)) ELSE 1 END))) THEN CASE WHEN p.phase_kind=7 THEN p.stop ELSE p.body END ELSE 0 END,p.c2,CASE WHEN p.route<>0 AND p.phase_kind=1 AND p.minimum IS NOT NULL THEN MAX(0,p.work-1) ELSE p.work END,COALESCE(frame.handle,p.parent),CASE WHEN p.route=0 THEN (CASE WHEN p.own<0 THEN p.own WHEN p.stopped<0 THEN p.stopped ELSE (CASE WHEN p.minimum IS NULL THEN CASE WHEN p.low>0 THEN 1 WHEN p.open OR p.uncertain>0 THEN 2 ELSE 0 END WHEN (NOT (p.open) AND (p.low+p.uncertain)<p.minimum) OR (p.maximum IS NOT NULL AND p.low>p.maximum) THEN 0 WHEN p.low>=p.minimum AND (p.maximum IS NULL OR (NOT (p.open) AND (p.low+p.uncertain)<=p.maximum)) AND (p.count_slot IS NULL OR (NOT (p.open) AND p.low=(p.low+p.uncertain))) THEN 1 ELSE 2 END) END) WHEN p.phase_kind=1 AND p.minimum IS NOT NULL AND p.work=0 THEN -2 ELSE 0 END,CASE WHEN p.route=0 THEN CASE WHEN p.minimum IS NULL THEN CASE WHEN p.own=1 THEN p.env ELSE p.c6 END WHEN p.count_slot IS NOT NULL AND (CASE WHEN p.own<0 THEN p.own WHEN p.stopped<0 THEN p.stopped ELSE (CASE WHEN p.minimum IS NULL THEN CASE WHEN p.low>0 THEN 1 WHEN p.open OR p.uncertain>0 THEN 2 ELSE 0 END WHEN (NOT (p.open) AND (p.low+p.uncertain)<p.minimum) OR (p.maximum IS NOT NULL AND p.low>p.maximum) THEN 0 WHEN p.low>=p.minimum AND (p.maximum IS NULL OR (NOT (p.open) AND (p.low+p.uncertain)<=p.maximum)) AND (p.count_slot IS NULL OR (NOT (p.open) AND p.low=(p.low+p.uncertain))) THEN 1 ELSE 2 END) END)=1 THEN relation_state_put(p.scope,p.c6,p.count_slot,p.low+p.count_offset) ELSE p.c6 END WHEN p.phase_kind=7 THEN (relation_state_project(p.scope,p.c6,0,0)) ELSE p.c6 END,p.scope FROM chosen p LEFT JOIN node candidate ON candidate.file=d.file AND candidate.id=p.chosen LEFT JOIN node edge ON edge.file=d.file AND edge.id=p.edge_node LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN p.route<>0 THEN 1 END AND frame.parent_input IS p.parent AND frame.v0 IS (p.phase_kind) AND frame.v1 IS (p.c1) AND frame.v2 IS (p.c2) AND frame.v3 IS (p.c3) AND frame.v4 IS (p.chosen) AND frame.v5 IS (p.c5) AND frame.v6 IS (p.c6) AND frame.v7 IS (CASE WHEN p.route=3 THEN p.low ELSE p.c7 END) AND frame.v8 IS (CASE WHEN p.route=3 THEN p.uncertain ELSE p.c8 END) AND frame.v9 IS (CASE WHEN p.route=3 THEN p.open ELSE p.c9 END) AND frame.v10 IS (CASE WHEN p.route=1 THEN p.own WHEN p.route=2 THEN p.truth ELSE 0 END) AND frame.v11 IS (p.edge_node)))) WHERE machine.pc=0 UNION ALL SELECT * FROM (WITH reached AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=2)), s AS MATERIALIZED (SELECT s.*,f.id function,f.entry,f.memo,f.fills FROM reached s JOIN constant0_0 i ON i.pc=s.pc JOIN constant0_2 f ON f.id=i.a),
lookup AS MATERIALIZED (SELECT s.*,m.truth hit,m.cost,m.peak,CASE WHEN m.truth=1 AND s.work>=m.cost THEN CASE f.id WHEN 0 THEN s.env ELSE s.env END ELSE s.env END hit_env FROM s JOIN constant0_2 f ON f.id=s.function LEFT JOIN relation_memo m ON m.mode IS CASE WHEN f.memo IS NOT NULL THEN 0 END AND m.clause IS 0 AND m.utility IS f.memo AND m.file IS d.file AND m.node IS s.node AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN hit IS NULL AND level<256 THEN relation_peak_open(level) END token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN hit IS NOT NULL THEN relation_peak_note(level+peak) WHEN token IS NOT NULL THEN relation_peak_note(level+1) ELSE 1 END ready FROM opened s)
SELECT s.node,CASE WHEN s.hit IS NOT NULL OR s.level>=256 OR s.work=0 THEN 0 ELSE s.entry END,CASE WHEN s.hit IS NULL AND s.level<256 THEN s.level+1 ELSE s.level END,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,COALESCE(frame.handle,s.handle),CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,CASE WHEN s.hit IS NOT NULL AND s.work>=s.cost THEN s.hit_env ELSE s.env END,s.scope FROM noted s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.hit IS NULL AND s.level<256 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (0) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.function) AND frame.v4 IS (s.work) AND frame.v5 IS (CASE WHEN s.fills THEN relation_cache_fill_steps() END) AND frame.v6 IS (s.token) AND frame.v7 IS (s.env) WHERE s.ready=1) WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=2) UNION ALL SELECT * FROM (WITH reached AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op IN (3,4))),s AS MATERIALIZED (SELECT s.*,i.op,(SELECT child FROM constant0_1 WHERE pc=s.pc AND ordinal=0) child FROM reached s JOIN constant0_0 i ON i.pc=s.pc) SELECT s.node,COALESCE(s.child,0),s.level,s.work,COALESCE(frame.handle,s.handle),CASE WHEN s.child IS NULL THEN s.op=3 ELSE 0 END,s.env,s.scope FROM s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (CASE s.op WHEN 3 THEN 2 ELSE 3 END) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (0) AND frame.v5 IS (0) AND frame.v6 IS (s.env) AND frame.v7 IS (s.env) AND frame.v8 IS (0) AND frame.v9 IS (0)) WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op IN (3,4)) UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=5)) SELECT s.node,i.a,s.level,s.work,frame.handle,0,s.env,s.scope FROM s JOIN constant0_0 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN 1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (4) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (0) AND frame.v5 IS (0) AND frame.v6 IS (s.env)) WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op=5) UNION ALL SELECT * FROM (WITH seed AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc IN (SELECT pc FROM constant0_3)), parameters AS MATERIALIZED (SELECT s.*,i.axis,i.ending,i.field,i.body,i.stop,i.minimum,i.maximum,i.count_slot,i.count_offset,i.strict,(i.axis<>0 AND i.stop IS NOT NULL) stop_first FROM seed s JOIN constant0_3 i ON i.pc=s.pc), first AS MATERIALIZED (SELECT s.*,CASE s.axis WHEN 0 THEN CASE WHEN s.field IS NULL THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND candidate.parent=s.node ORDER BY candidate.id LIMIT 1) ELSE (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND candidate.parent=s.node AND candidate.field=s.field AND candidate.ffirst=1 LIMIT 1) END WHEN 1 THEN CASE WHEN s.field IS NULL OR s.ending=1 OR (origin.field=s.field AND origin.ffirst=1) THEN origin.parent END WHEN 2 THEN origin.prev ELSE origin.next END first FROM parameters s JOIN node origin ON origin.file=d.file AND origin.id=s.node), picked AS MATERIALIZED (SELECT s.*,CASE WHEN s.axis=0 AND s.ending=1 AND s.field IS NOT NULL THEN candidate."last" ELSE origin."last" END bound FROM first s JOIN node origin ON origin.file=d.file AND origin.id=s.node LEFT JOIN node candidate ON candidate.file=d.file AND candidate.id=s.first) SELECT COALESCE(s.first,s.node),CASE WHEN s.first IS NULL OR ((s.minimum IS NOT NULL AND NOT s.stop_first) AND s.work=0) THEN 0 WHEN (CASE WHEN s.stop_first OR s.minimum IS NOT NULL THEN 1 ELSE ((s.axis<>1 OR s.ending=0 OR s.field IS NULL OR (origin.field=s.field AND origin.ffirst=1))) AND (CASE s.pc WHEN 13 THEN (candidate.kind IN (191)) WHEN 21 THEN (candidate.kind IN (207,226)) WHEN 23 THEN (candidate.kind IN (191)) WHEN 25 THEN (candidate.kind IN (207,226)) WHEN 28 THEN (candidate.kind IN (191,207,226)) WHEN 32 THEN (candidate.kind IN (207,226)) ELSE 1 END) END) THEN (CASE WHEN s.stop_first THEN s.stop ELSE s.body END) ELSE 0 END,s.level,CASE WHEN s.first IS NOT NULL AND (s.minimum IS NOT NULL AND NOT s.stop_first) THEN MAX(0,s.work-1) ELSE s.work END,COALESCE(frame.handle,s.handle),CASE WHEN s.first IS NULL THEN (CASE WHEN s.minimum IS NULL THEN CASE WHEN 0>0 THEN 1 WHEN 0 OR 0>0 THEN 2 ELSE 0 END WHEN (NOT (0) AND (0+0)<s.minimum) OR (s.maximum IS NOT NULL AND 0>s.maximum) THEN 0 WHEN 0>=s.minimum AND (s.maximum IS NULL OR (NOT (0) AND (0+0)<=s.maximum)) AND (s.count_slot IS NULL OR (NOT (0) AND 0=(0+0))) THEN 1 ELSE 2 END) WHEN (s.minimum IS NOT NULL AND NOT s.stop_first) AND s.work=0 THEN -2 ELSE 0 END,CASE WHEN s.first IS NULL THEN (CASE WHEN s.count_slot IS NOT NULL AND (CASE WHEN s.minimum IS NULL THEN CASE WHEN 0>0 THEN 1 WHEN 0 OR 0>0 THEN 2 ELSE 0 END WHEN (NOT (0) AND (0+0)<s.minimum) OR (s.maximum IS NOT NULL AND 0>s.maximum) THEN 0 WHEN 0>=s.minimum AND (s.maximum IS NULL OR (NOT (0) AND (0+0)<=s.maximum)) AND (s.count_slot IS NULL OR (NOT (0) AND 0=(0+0))) THEN 1 ELSE 2 END)=1 THEN relation_state_put(s.scope,s.env,s.count_slot,s.count_offset) ELSE s.env END) WHEN s.stop_first THEN (relation_state_project(s.scope,s.env,0,0)) ELSE s.env END,s.scope FROM picked s JOIN node origin ON origin.file=d.file AND origin.id=s.node LEFT JOIN node candidate ON candidate.file=d.file AND candidate.id=s.first LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.first IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (CASE WHEN s.stop_first THEN 7 ELSE 1 END) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (s.first) AND frame.v5 IS (s.bound) AND frame.v6 IS (s.env) AND frame.v7 IS (0) AND frame.v8 IS (0) AND frame.v9 IS (0) AND frame.v10 IS (0) AND frame.v11 IS (s.node)) WHERE machine.pc IN (SELECT pc FROM constant0_3) UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc=15) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(s.scope,s.env,0,r.c2) ELSE s.env END,s.scope FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 k,d.file,machine.node,machine.work,relation_state_get(machine.env,0) AS c0,relation_state_get(machine.env,1) AS c1,relation_state_get(machine.env,2) AS c2,relation_state_get(machine.env,23) AS c23 WHERE machine.pc=15
),outcome1 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END AS truth,d.node AS c0 FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)) WHERE machine.pc=15 UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc=16) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(s.scope,relation_state_put(s.scope,s.env,1,r.c2),2,r.c3) ELSE s.env END,s.scope FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 k,d.file,machine.node,machine.work,relation_state_get(machine.env,0) AS c0,relation_state_get(machine.env,1) AS c1,relation_state_get(machine.env,2) AS c2,relation_state_get(machine.env,23) AS c23 WHERE machine.pc=16
),outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth,r.c2 AS c1,r.c3 AS c2 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,((machine.level)+0) AS level,0 AS phase,NULL AS parent,d.work AS work,d.work AS start,0 AS fill,NULL AS token,0 AS truth,0 AS uncertain,0 AS cursor,NULL AS c1,NULL AS c2
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12 FROM schedule recursive_entry_3 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_3.node AS node,recursive_entry_3.level AS level,recursive_entry_3.phase AS phase,recursive_entry_3.parent AS parent,recursive_entry_3.work AS work,recursive_entry_3.start AS start,recursive_entry_3.fill AS fill,recursive_entry_3.token AS token,recursive_entry_3.truth AS truth,recursive_entry_3.uncertain AS uncertain,recursive_entry_3.cursor AS cursor,recursive_entry_3.c1 AS c1,recursive_entry_3.c2 AS c2 WHERE recursive_entry_3.phase=0),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak,m.o1 AS e1,m.o2 AS e2 FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS 2000003 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k23 IS d.c23 AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS opened_token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.opened_token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,s.level,CASE WHEN s.hit IS NOT NULL THEN 4 WHEN s.level>=256 OR s.work=0 THEN 3 ELSE 10 END,s.parent,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
s.work,relation_cache_fill_steps(),s.opened_token,
CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,0,0,s.e1,s.e2 FROM noted s WHERE s.ready=1) WHERE recursive_entry_3.phase=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12 FROM schedule recursive_entry_3 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_3.node AS node,recursive_entry_3.level AS level,recursive_entry_3.phase AS phase,recursive_entry_3.parent AS parent,recursive_entry_3.work AS work,recursive_entry_3.start AS start,recursive_entry_3.fill AS fill,recursive_entry_3.token AS token,recursive_entry_3.truth AS truth,recursive_entry_3.uncertain AS uncertain,recursive_entry_3.cursor AS cursor,recursive_entry_3.c1 AS c1,recursive_entry_3.c2 AS c2 WHERE recursive_entry_3.phase=3),
s AS MATERIALIZED (SELECT s.*,CASE WHEN s.token IS NOT NULL THEN relation_peak_close(s.token) END AS measured FROM reached s)
SELECT s.node,s.level,4,s.parent,s.work,s.start,s.fill,NULL,COALESCE(m.truth,s.truth),s.uncertain,s.cursor,s.c1,s.c2 FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND s.truth>=0 AND s.token IS NOT NULL THEN 1 END AND m.clause IS 0 AND m.utility IS 2000003 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k23 IS d.c23 AND m.vtruth IS s.truth AND m.vcost IS MAX(0,s.start-s.work-relation_cache_fill_delta(s.fill)) AND m.vpeak IS s.measured AND m.v1 IS CASE WHEN s.truth=1 THEN s.c1 END AND m.v2 IS CASE WHEN s.truth=1 THEN s.c2 END WHERE COALESCE(s.measured,0)>=0) WHERE recursive_entry_3.phase=3
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12 FROM schedule recursive_entry_3 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_3.node AS node,recursive_entry_3.level AS level,recursive_entry_3.phase AS phase,recursive_entry_3.parent AS parent,recursive_entry_3.work AS work,recursive_entry_3.start AS start,recursive_entry_3.fill AS fill,recursive_entry_3.token AS token,recursive_entry_3.truth AS truth,recursive_entry_3.uncertain AS uncertain,recursive_entry_3.cursor AS cursor,recursive_entry_3.c1 AS c1,recursive_entry_3.c2 AS c2 WHERE recursive_entry_3.phase=4)
SELECT COALESCE(p.c0,s.node),COALESCE(p.c1,s.level),CASE WHEN s.parent IS NULL THEN 5 WHEN s.truth=0 THEN p.c7 ELSE 3 END,p.parent,s.work,p.c2,p.c3,p.c4,s.truth,COALESCE(p.c5,0) OR s.truth=2,p.c6,s.c1,s.c2
FROM s LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.parent IS NOT NULL THEN 2 END AND p.h IS s.parent) WHERE recursive_entry_3.phase=4
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12 FROM schedule recursive_entry_3 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_3.node AS node,recursive_entry_3.level AS level,recursive_entry_3.phase AS phase,recursive_entry_3.parent AS parent,recursive_entry_3.work AS work,recursive_entry_3.start AS start,recursive_entry_3.fill AS fill,recursive_entry_3.token AS token,recursive_entry_3.truth AS truth,recursive_entry_3.uncertain AS uncertain,recursive_entry_3.cursor AS cursor,recursive_entry_3.c1 AS c1,recursive_entry_3.c2 AS c2 WHERE recursive_entry_3.phase=11) SELECT s.node,s.level,CASE WHEN r.c0=0 THEN 3 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0,r.c2,r.c3 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,recursive_entry_3.node AS node,recursive_entry_3.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE recursive_entry_3.phase=11
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (207) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1,r.c3 AS e2 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth>0 AND NOT (d.u1 OR d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.*,n.id AS selected FROM outcome0 d LEFT JOIN node n ON n.file=d.file AND n.parent=d.node AND n.field=14 AND n.ffirst=1 AND (n.kind IN (204))
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,d.work) AS work,COALESCE(r.c0,0) AS truth,CASE WHEN r.c0=1 THEN r.c2 ELSE d.c1 END AS c1,CASE WHEN r.c0=1 THEN r.c3 ELSE d.c2 END AS c2 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.selected AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.selected IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (204) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.*,n.id AS selected FROM outcome0 d LEFT JOIN node n ON n.file=d.file AND n.parent=d.node AND n.field=20 AND n.ffirst=1 AND (n.kind IN (1))
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,d.work) AS work,COALESCE(r.c0,0) AS truth,CASE WHEN r.c0=1 THEN r.c2 ELSE d.c1 END AS c1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.selected AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.selected IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN n.named AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.node ELSE d.c1 END AS c1,d.c2 AS c2,d.c23 AS c23,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome2 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,d.c2 AS c2,d.c23 AS c23,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth>0 AND NOT (d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.*,n.id AS selected FROM outcome0 d LEFT JOIN node n ON n.file=d.file AND n.parent=d.node AND n.field=5 AND n.ffirst=1 AND (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,d.work) AS work,COALESCE(r.c0,0) AS truth,CASE WHEN r.c0=1 THEN r.c2 ELSE d.c2 END AS c2 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.selected AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.selected IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u2) THEN CASE WHEN n.named AND (CASE WHEN d.c2 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c2,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,CASE WHEN d.tested=1 THEN d.node ELSE d.c2 END AS c2,d.c23 AS c23,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN node_regex(1,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome6 o)
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome2 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,d.c23 AS c23,d.u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1,s.c2 AS c2 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome8 o)
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome2 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,d.c23 AS c23,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.*,n.id AS selected FROM outcome0 d LEFT JOIN node n ON n.file=d.file AND n.parent=d.node AND n.field=4 AND n.ffirst=1 AND (n.kind IN (158))
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,d.work) AS work,COALESCE(r.c0,0) AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.selected AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.selected IS NOT NULL
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (158) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome1 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE w.stopped>=0 AND (n.kind IN (1,149,215,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN n.kind IN (149,215) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,((recursive_entry_3.level+1)+0) AS level,0 AS phase,NULL AS parent,d.work AS work,d.work AS start,0 AS fill,NULL AS token,0 AS truth,0 AS uncertain,0 AS cursor
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_2 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_2.node AS node,recursive_entry_2.level AS level,recursive_entry_2.phase AS phase,recursive_entry_2.parent AS parent,recursive_entry_2.work AS work,recursive_entry_2.start AS start,recursive_entry_2.fill AS fill,recursive_entry_2.token AS token,recursive_entry_2.truth AS truth,recursive_entry_2.uncertain AS uncertain,recursive_entry_2.cursor AS cursor WHERE recursive_entry_2.phase=0),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS 2000002 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k23 IS d.c23 AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS opened_token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.opened_token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,s.level,CASE WHEN s.hit IS NOT NULL THEN 4 WHEN s.level>=256 OR s.work=0 THEN 3 ELSE 10 END,s.parent,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
s.work,relation_cache_fill_steps(),s.opened_token,
CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,0,0 FROM noted s WHERE s.ready=1) WHERE recursive_entry_2.phase=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_2 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_2.node AS node,recursive_entry_2.level AS level,recursive_entry_2.phase AS phase,recursive_entry_2.parent AS parent,recursive_entry_2.work AS work,recursive_entry_2.start AS start,recursive_entry_2.fill AS fill,recursive_entry_2.token AS token,recursive_entry_2.truth AS truth,recursive_entry_2.uncertain AS uncertain,recursive_entry_2.cursor AS cursor WHERE recursive_entry_2.phase=3),
s AS MATERIALIZED (SELECT s.*,CASE WHEN s.token IS NOT NULL THEN relation_peak_close(s.token) END AS measured FROM reached s)
SELECT s.node,s.level,4,s.parent,s.work,s.start,s.fill,NULL,COALESCE(m.truth,s.truth),s.uncertain,s.cursor FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND s.truth>=0 AND s.token IS NOT NULL THEN 1 END AND m.clause IS 0 AND m.utility IS 2000002 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k23 IS d.c23 AND m.vtruth IS s.truth AND m.vcost IS MAX(0,s.start-s.work-relation_cache_fill_delta(s.fill)) AND m.vpeak IS s.measured WHERE COALESCE(s.measured,0)>=0) WHERE recursive_entry_2.phase=3
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_2 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_2.node AS node,recursive_entry_2.level AS level,recursive_entry_2.phase AS phase,recursive_entry_2.parent AS parent,recursive_entry_2.work AS work,recursive_entry_2.start AS start,recursive_entry_2.fill AS fill,recursive_entry_2.token AS token,recursive_entry_2.truth AS truth,recursive_entry_2.uncertain AS uncertain,recursive_entry_2.cursor AS cursor WHERE recursive_entry_2.phase=4)
SELECT COALESCE(p.c0,s.node),COALESCE(p.c1,s.level),CASE WHEN s.parent IS NULL THEN 5 WHEN s.truth IN (0,2) THEN p.c7 ELSE 3 END,p.parent,s.work,p.c2,p.c3,p.c4,s.truth,COALESCE(p.c5,0) OR s.truth=2,p.c6
FROM s LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.parent IS NOT NULL THEN 2 END AND p.h IS s.parent) WHERE recursive_entry_2.phase=4
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_2 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_2.node AS node,recursive_entry_2.level AS level,recursive_entry_2.phase AS phase,recursive_entry_2.parent AS parent,recursive_entry_2.work AS work,recursive_entry_2.start AS start,recursive_entry_2.fill AS fill,recursive_entry_2.token AS token,recursive_entry_2.truth AS truth,recursive_entry_2.uncertain AS uncertain,recursive_entry_2.cursor AS cursor WHERE recursive_entry_2.phase=11) SELECT s.node,s.level,CASE WHEN r.c0 IN (0,2) THEN 3 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,recursive_entry_2.node AS node,recursive_entry_2.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE recursive_entry_2.phase=11
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,NULL AS c3,NULL AS c4,NULL AS c5,NULL AS c6,d.c23 AS c23 FROM outcome1 d WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c3,p.c1 AS c4,p.c2 AS c5,p.c3 AS c6 FROM outcome2 d CROSS JOIN relation_binding_budget p ON p.term=2 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c3 AND p.i1 IS d.c4 AND p.i2 IS d.c5 AND p.i3 IS d.c6
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,o.work,o.truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,o.c3 AS c3,o.c4 AS c4,o.c5 AS c5,o.c6 AS c6 FROM outcome1 d JOIN outcome3 o ON o.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=probe.file AND bound0.id=probe.parent WHERE ((probe.kind IN (184) AND COALESCE(bound0.kind IN (146),0)) OR (probe.kind IN (208) AND COALESCE(bound0.kind IN (146),0) AND EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=probe.file AND a0n1.parent=probe.id WHERE a0n1.kind IN (184))))) THEN 1 ELSE 0 END,d.work-1 FROM node probe WHERE probe.file=d.file AND probe.id=d.c3 AND (d.truth=1 AND d.c3 IS NOT NULL AND d.work>0))
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>1 THEN d.truth WHEN d.c3 IS NULL THEN 0 WHEN d.work=0 THEN -2 ELSE d.tested END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.c3 AS c3,d.c4 AS c4,d.c5 AS c5,d.c6 AS c6 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
) SELECT o.truth,o.work FROM outcome7 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,NULL AS c7,NULL AS c8,NULL AS c9,NULL AS c10,d.c23 AS c23 FROM outcome1 d WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c7,p.c1 AS c8,p.c2 AS c9,p.c3 AS c10 FROM outcome2 d CROSS JOIN relation_binding_budget p ON p.term=3 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c7 AND p.i1 IS d.c8 AND p.i2 IS d.c9 AND p.i3 IS d.c10
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,o.work,o.truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,o.c7 AS c7,o.c8 AS c8,o.c9 AS c9,o.c10 AS c10 FROM outcome1 d JOIN outcome3 o ON o.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=probe.file AND a0n1.parent=probe.id WHERE a0n1.kind IN (209))) THEN 1 ELSE 0 END,d.work-1 FROM node probe WHERE probe.file=d.file AND probe.id=d.c7 AND (d.truth=1 AND d.c7 IS NOT NULL AND d.work>0))
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>1 THEN d.truth WHEN d.c7 IS NULL THEN 0 WHEN d.work=0 THEN -2 ELSE d.tested END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.c7 AS c7,d.c8 AS c8,d.c9 AS c9,d.c10 AS c10 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome6 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.c8 AS node,d.work-1 AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 WHERE d.truth=1 AND d.c8 IS NOT NULL AND d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23
),
outcome1 AS MATERIALIZED (
SELECT d.*,((recursive_entry_2.level+1)+0) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k8 IS d.c8 AND m.k23 IS d.c23 AND m.peak<=256-((recursive_entry_2.level+1)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,COALESCE(r.c2,0) AS fill_cost FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH fill_before AS MATERIALIZED (SELECT relation_cache_fill_steps() AS start WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1),
fill_result AS MATERIALIZED (SELECT b.start,r.c0,r.c1 FROM fill_before b CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,28 AS pc,d.work,((recursive_entry_2.level+1)+1) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 4 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE node_regex(4,a0n1.file,a0n1.id)) WHEN 6 THEN (node_regex(4,n.file,n.id) OR n.kind IN (99)) WHEN 8 THEN n.kind IN (192) WHEN 10 THEN (node_regex(5,n.file,n.id) OR n.kind IN (99)) WHEN 12 THEN n.kind IN (191) WHEN 13 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(6,bound0.file,bound0.id) ELSE 0 END) WHEN 16 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(7,bound0.file,bound0.id) ELSE 0 END) WHEN 19 THEN n.kind IN (230) WHEN 20 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(8,bound0.file,bound0.id) ELSE 0 END) WHEN 23 THEN n.kind IN (123) WHEN 26 THEN n.kind IN (226) WHEN 27 THEN n.kind IN (162,218) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_4 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_4 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1 AND CASE WHEN w.pc IN (5,9,14,17,21,24,28) AND w.level<256 THEN relation_peak_note(w.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_4 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 7 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 11 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 7 THEN 1 WHEN 11 THEN 1 WHEN 15 THEN 1 WHEN 18 THEN 1 WHEN 22 THEN 1 WHEN 25 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 7 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 11 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (207) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 WHERE w.stopped>=0 AND (n.kind IN (1,204,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,r.c0 AS tree,COALESCE(r.c1,1) AS rank,COALESCE(r.c2,1) AS finish,COALESCE(r.c3,0) AS origin,((recursive_entry_2.level+1)+1) AS incoming FROM outcome0 d CROSS JOIN node probe ON probe.file=d.file AND probe.id=d.node CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT tree,rank,finish,depth FROM semantic0_0_summary WHERE file=d.file AND node=d.node AND d.work>0 AND ((recursive_entry_2.level+1)+1)<256 AND (probe.kind IN (226)))
),
outcome2 AS MATERIALIZED (
SELECT s.k,s.file,s.node,s.tree,s.rank,s.finish,s.origin,s.incoming,s.incoming AS level,0 AS phase,0 AS own,0 AS uncertain,s.work FROM outcome1 s
UNION ALL
SELECT semantic_entry0_0.k,semantic_entry0_0.file,semantic_entry0_0.node,semantic_entry0_0.tree,semantic_entry0_0.rank,semantic_entry0_0.finish,semantic_entry0_0.origin,semantic_entry0_0.incoming,semantic_entry0_0.level,1,CASE WHEN semantic_entry0_0.level>=256 THEN -1 WHEN semantic_entry0_0.work=0 THEN -2 ELSE r.c0 END,semantic_entry0_0.uncertain,COALESCE(r.c1,semantic_entry0_0.work)
FROM outcome2 semantic_entry0_0 JOIN outcome0 d ON d.k=semantic_entry0_0.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,semantic_entry0_0.work-1) FROM node probe LEFT JOIN relation_value_budget(9,semantic_entry0_0.file,semantic_entry0_0.node,CASE WHEN (semantic_entry0_0.work>0 AND semantic_entry0_0.level<256) AND ((probe.kind IN (1,204))) THEN semantic_entry0_0.work-1 END) v ON 1 WHERE probe.file=semantic_entry0_0.file AND probe.id=semantic_entry0_0.node AND (semantic_entry0_0.work>0 AND semantic_entry0_0.level<256)) WHERE semantic_entry0_0.phase=0 AND CASE WHEN semantic_entry0_0.phase=0 AND semantic_entry0_0.level<256 THEN relation_peak_note(semantic_entry0_0.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,n.node,w.tree,n.rank,w.finish,w.origin,w.incoming,w.incoming+n.depth-w.origin,0,0,w.uncertain OR w.own=2,w.work
FROM outcome2 w JOIN semantic0_0_ranked n ON n.file=w.file AND n.tree=w.tree AND n.rank=w.rank+1
WHERE w.phase=1 AND (w.own IN (0,2)) AND w.rank<w.finish
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own=0 AND w.uncertain THEN 2 ELSE w.own END AS truth FROM outcome2 w WHERE w.phase=1 AND (NOT (w.own IN (0,2)) OR w.rank=w.finish)
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next WHERE COALESCE(bound0.kind IN (158,224),0)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c8 AS c8,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o))
SELECT v.c0,v.c1,relation_cache_fill_delta(v.start) FROM fill_result v)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k8 IS d.c8 AND m.k23 IS d.c23 AND m.vtruth IS d.tested AND m.vcost IS MAX(0,d.work-d.remaining-d.fill_cost) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>1 THEN d.truth WHEN d.c8 IS NULL THEN 0 WHEN d.work=0 THEN -2 ELSE d.tested END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.c7 AS c7,d.c8 AS c8,d.c9 AS c9,d.c10 AS c10 FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome8 s
) SELECT o.truth,o.work FROM outcome9 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,NULL AS c11,NULL AS c12,NULL AS c13,NULL AS c14,d.c23 AS c23 FROM outcome1 d WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c11,p.c1 AS c12,p.c2 AS c13,p.c3 AS c14 FROM outcome2 d CROSS JOIN relation_binding_budget p ON p.term=10 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c11 AND p.i1 IS d.c12 AND p.i2 IS d.c13 AND p.i3 IS d.c14
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,o.work,o.truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,o.c11 AS c11,o.c12 AS c12,o.c13 AS c13,o.c14 AS c14 FROM outcome1 d JOIN outcome3 o ON o.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.c11 AS node,d.work-1 AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth=1 AND d.c11 IS NOT NULL AND d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (186) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE w.stopped>=0 AND (n.kind IN (123,162,191,192,207,218,226,230))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23
),
outcome1 AS MATERIALIZED (
SELECT d.*,((recursive_entry_2.level+1)+0) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k11 IS d.c11 AND m.k23 IS d.c23 AND m.peak<=256-((recursive_entry_2.level+1)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,COALESCE(r.c2,0) AS fill_cost FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH fill_before AS MATERIALIZED (SELECT relation_cache_fill_steps() AS start WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1),
fill_result AS MATERIALIZED (SELECT b.start,r.c0,r.c1 FROM fill_before b CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,28 AS pc,d.work,((recursive_entry_2.level+1)+1) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 4 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE node_regex(4,a0n1.file,a0n1.id)) WHEN 6 THEN (node_regex(4,n.file,n.id) OR n.kind IN (99)) WHEN 8 THEN n.kind IN (192) WHEN 10 THEN (node_regex(5,n.file,n.id) OR n.kind IN (99)) WHEN 12 THEN n.kind IN (191) WHEN 13 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(6,bound0.file,bound0.id) ELSE 0 END) WHEN 16 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(7,bound0.file,bound0.id) ELSE 0 END) WHEN 19 THEN n.kind IN (230) WHEN 20 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(8,bound0.file,bound0.id) ELSE 0 END) WHEN 23 THEN n.kind IN (123) WHEN 26 THEN n.kind IN (226) WHEN 27 THEN n.kind IN (162,218) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_5 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_5 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1 AND CASE WHEN w.pc IN (5,9,14,17,21,24,28) AND w.level<256 THEN relation_peak_note(w.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_5 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 7 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 11 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 7 THEN 1 WHEN 11 THEN 1 WHEN 15 THEN 1 WHEN 18 THEN 1 WHEN 22 THEN 1 WHEN 25 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 7 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 11 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (123,162,191,192,218,226,230)) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (207) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE w.stopped>=0 AND (n.kind IN (1,204,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,r.c0 AS tree,COALESCE(r.c1,1) AS rank,COALESCE(r.c2,1) AS finish,COALESCE(r.c3,0) AS origin,((recursive_entry_2.level+1)+1) AS incoming FROM outcome0 d CROSS JOIN node probe ON probe.file=d.file AND probe.id=d.node CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT tree,rank,finish,depth FROM semantic0_0_summary WHERE file=d.file AND node=d.node AND d.work>0 AND ((recursive_entry_2.level+1)+1)<256 AND (probe.kind IN (226)))
),
outcome2 AS MATERIALIZED (
SELECT s.k,s.file,s.node,s.tree,s.rank,s.finish,s.origin,s.incoming,s.incoming AS level,0 AS phase,0 AS own,0 AS uncertain,s.work FROM outcome1 s
UNION ALL
SELECT semantic_entry0_0.k,semantic_entry0_0.file,semantic_entry0_0.node,semantic_entry0_0.tree,semantic_entry0_0.rank,semantic_entry0_0.finish,semantic_entry0_0.origin,semantic_entry0_0.incoming,semantic_entry0_0.level,1,CASE WHEN semantic_entry0_0.level>=256 THEN -1 WHEN semantic_entry0_0.work=0 THEN -2 ELSE r.c0 END,semantic_entry0_0.uncertain,COALESCE(r.c1,semantic_entry0_0.work)
FROM outcome2 semantic_entry0_0 JOIN outcome0 d ON d.k=semantic_entry0_0.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,semantic_entry0_0.work-1) FROM node probe LEFT JOIN relation_value_budget(9,semantic_entry0_0.file,semantic_entry0_0.node,CASE WHEN (semantic_entry0_0.work>0 AND semantic_entry0_0.level<256) AND ((probe.kind IN (1,204))) THEN semantic_entry0_0.work-1 END) v ON 1 WHERE probe.file=semantic_entry0_0.file AND probe.id=semantic_entry0_0.node AND (semantic_entry0_0.work>0 AND semantic_entry0_0.level<256)) WHERE semantic_entry0_0.phase=0 AND CASE WHEN semantic_entry0_0.phase=0 AND semantic_entry0_0.level<256 THEN relation_peak_note(semantic_entry0_0.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,n.node,w.tree,n.rank,w.finish,w.origin,w.incoming,w.incoming+n.depth-w.origin,0,0,w.uncertain OR w.own=2,w.work
FROM outcome2 w JOIN semantic0_0_ranked n ON n.file=w.file AND n.tree=w.tree AND n.rank=w.rank+1
WHERE w.phase=1 AND (w.own IN (0,2)) AND w.rank<w.finish
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own=0 AND w.uncertain THEN 2 ELSE w.own END AS truth FROM outcome2 w WHERE w.phase=1 AND (NOT (w.own IN (0,2)) OR w.rank=w.finish)
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next WHERE COALESCE(bound0.kind IN (158,224),0)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o))
SELECT v.c0,v.c1,relation_cache_fill_delta(v.start) FROM fill_result v)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k11 IS d.c11 AND m.k23 IS d.c23 AND m.vtruth IS d.tested AND m.vcost IS MAX(0,d.work-d.remaining-d.fill_cost) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.next AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.next IS NOT NULL UNION ALL SELECT w.parent,n.file,n.next,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.next IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(11,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome5 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE w.stopped>=0 AND (n.kind IN (273))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (273) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 WHERE w.stopped>=0 AND (n.kind IN (1,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,CASE WHEN d.work>0 AND MAX(0,256-((recursive_entry_2.level+1)+0))>0 THEN (n.kind IN (1)) ELSE 0 END AS base,CASE WHEN d.work>0 AND MAX(0,256-((recursive_entry_2.level+1)+0))>0 THEN (n.kind IN (226)) ELSE 0 END AS active FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN d.base THEN 1 ELSE COALESCE(r.c0,0) END AS truth,COALESCE(r.c1,1) AS cost,CASE WHEN MAX(0,256-((recursive_entry_2.level+1)+0))=0 THEN 0 ELSE r.c2 END AS breach,COALESCE(r.c3,1) AS peak FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH reached AS MATERIALIZED (SELECT s.*,((SELECT MIN(n.rank)-s.rank FROM downward0_0_ranked n WHERE n.file=s.file AND n.tree=s.tree AND n.rank BETWEEN s.rank AND s.finish AND n.depth>=s.depth+(MAX(0,256-((recursive_entry_2.level+1)+0))))) AS breach FROM downward0_0_summary s WHERE d.work>0 AND MAX(0,256-((recursive_entry_2.level+1)+0))>0 AND NOT d.base AND d.active AND s.file=d.file AND s.node=d.node) SELECT s.truth,s.cost,s.breach,(SELECT MAX(n.depth)-s.depth+1 FROM downward0_0_ranked n WHERE n.file=s.file AND n.tree=s.tree AND n.rank>=s.rank AND n.rank<s.rank+MIN(s.cost,d.work+1,COALESCE(s.breach,s.cost))) FROM reached s)
),
outcome3 AS MATERIALIZED (
SELECT k,MAX(0,work-COALESCE(breach,cost)) AS work,CASE WHEN breach IS NOT NULL AND work>=breach THEN -1 WHEN work<COALESCE(breach,cost) THEN -2 ELSE truth END AS truth FROM outcome2 WHERE CASE WHEN MAX(0,256-((recursive_entry_2.level+1)+0))>0 THEN relation_peak_note(((recursive_entry_2.level+1)+0)+peak) ELSE 1 END=1
) SELECT o.truth,o.work FROM outcome3 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent WHERE COALESCE(bound0.kind IN (144),0)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome7 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c11 AS c11,d.c23 AS c23 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome9 s
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>1 THEN d.truth WHEN d.c11 IS NULL THEN 0 WHEN d.work=0 THEN -2 ELSE d.tested END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.c11 AS c11,d.c12 AS c12,d.c13 AS c13,d.c14 AS c14 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
) SELECT o.truth,o.work FROM outcome7 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,NULL AS c15,NULL AS c16,NULL AS c17,NULL AS c18,d.c23 AS c23 FROM outcome1 d WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c15,p.c1 AS c16,p.c2 AS c17,p.c3 AS c18 FROM outcome2 d CROSS JOIN relation_binding_budget p ON p.term=12 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c15 AND p.i1 IS d.c16 AND p.i2 IS d.c17 AND p.i3 IS d.c18
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,o.work,o.truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,o.c15 AS c15,o.c16 AS c16,o.c17 AS c17,o.c18 AS c18 FROM outcome1 d JOIN outcome3 o ON o.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=probe.file AND a0n1.parent=probe.id WHERE a0n1.kind IN (184,185))) THEN 1 ELSE 0 END,d.work-1 FROM node probe WHERE probe.file=d.file AND probe.id=d.c15 AND (d.truth=1 AND d.c15 IS NOT NULL AND d.work>0))
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>1 THEN d.truth WHEN d.c15 IS NULL THEN 0 WHEN d.work=0 THEN -2 ELSE d.tested END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.c15 AS c15,d.c16 AS c16,d.c17 AS c17,d.c18 AS c18 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome6 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.c17 AS node,d.work-1 AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c17 AS c17,d.c23 AS c23 WHERE d.truth=1 AND d.c17 IS NOT NULL AND d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,((recursive_entry_2.level+1)+0) AS level,0 AS phase,NULL AS parent,d.work AS work,d.work AS start,0 AS fill,NULL AS token,0 AS truth,0 AS uncertain,0 AS cursor
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=0),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS 2000001 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k17 IS d.c17 AND m.k23 IS d.c23 AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS opened_token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.opened_token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,s.level,CASE WHEN s.hit IS NOT NULL THEN 4 WHEN s.level>=256 OR s.work=0 THEN 3 ELSE 10 END,s.parent,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
s.work,relation_cache_fill_steps(),s.opened_token,
CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,0,0 FROM noted s WHERE s.ready=1) WHERE recursive_entry_1.phase=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=3),
s AS MATERIALIZED (SELECT s.*,CASE WHEN s.token IS NOT NULL THEN relation_peak_close(s.token) END AS measured FROM reached s)
SELECT s.node,s.level,4,s.parent,s.work,s.start,s.fill,NULL,COALESCE(m.truth,s.truth),s.uncertain,s.cursor FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND s.truth>=0 AND s.token IS NOT NULL THEN 1 END AND m.clause IS 0 AND m.utility IS 2000001 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k17 IS d.c17 AND m.k23 IS d.c23 AND m.vtruth IS s.truth AND m.vcost IS MAX(0,s.start-s.work-relation_cache_fill_delta(s.fill)) AND m.vpeak IS s.measured WHERE COALESCE(s.measured,0)>=0) WHERE recursive_entry_1.phase=3
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=4)
SELECT COALESCE(p.c0,s.node),COALESCE(p.c1,s.level),CASE WHEN s.parent IS NULL THEN 5 WHEN s.truth IN (0,2) THEN p.c7 ELSE 3 END,p.parent,s.work,p.c2,p.c3,p.c4,s.truth,COALESCE(p.c5,0) OR s.truth=2,p.c6
FROM s LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.parent IS NOT NULL THEN 2 END AND p.h IS s.parent) WHERE recursive_entry_1.phase=4
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=10) SELECT s.node,s.level,CASE WHEN r.c0 IN (0,2) THEN 11 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,recursive_entry_1.work) FROM node probe LEFT JOIN relation_value_budget(14,d.file,recursive_entry_1.node,CASE WHEN (recursive_entry_1.phase=10) AND ((probe.kind IN (1,204))) THEN recursive_entry_1.work END) v ON 1 WHERE probe.file=d.file AND probe.id=recursive_entry_1.node AND (recursive_entry_1.phase=10))) WHERE recursive_entry_1.phase=10
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=11) SELECT s.node,s.level,CASE WHEN r.c0 IN (0,2) THEN 12 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,recursive_entry_1.work) FROM node probe LEFT JOIN relation_value_budget(15,d.file,recursive_entry_1.node,CASE WHEN (recursive_entry_1.phase=11) AND ((probe.kind IN (1,204))) THEN recursive_entry_1.work END) v ON 1 WHERE probe.file=d.file AND probe.id=recursive_entry_1.node AND (recursive_entry_1.phase=11))) WHERE recursive_entry_1.phase=11
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=12),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (child.parent=s.node AND child.id>s.cursor AND child.id<=n."last") AND ((child.kind IN (1,204,205,211,226)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=child.file AND bound0.id=child.prev WHERE NOT (COALESCE(bound0."end">bound0.start,0))))) AND (n.kind IN (205,211)) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 13 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0
FROM s LEFT JOIN node chosen ON chosen.file=d.file AND chosen.id=s.child LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS chosen."last" AND p.v7 IS 12) WHERE recursive_entry_1.phase=12
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=13),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (child.parent=s.node AND child.id>s.cursor AND child.id<=n."last") AND (child.kind IN (1,204,205,211,226)) AND (n.kind IN (226)) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 3 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0
FROM s LEFT JOIN node chosen ON chosen.file=d.file AND chosen.id=s.child LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS chosen."last" AND p.v7 IS 13) WHERE recursive_entry_1.phase=13) SELECT truth,work FROM schedule WHERE phase=5)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>1 THEN d.truth WHEN d.c17 IS NULL THEN 0 WHEN d.work=0 THEN -2 ELSE d.tested END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.c15 AS c15,d.c16 AS c16,d.c17 AS c17,d.c18 AS c18 FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome8 s
) SELECT o.truth,o.work FROM outcome9 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome9 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,NULL AS c19,NULL AS c20,NULL AS c21,NULL AS c22,d.c23 AS c23 FROM outcome1 d WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,p.work,p.truth,p.c0 AS c19,p.c1 AS c20,p.c2 AS c21,p.c3 AS c22 FROM outcome2 d CROSS JOIN relation_binding_budget p ON p.term=16 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c19 AND p.i1 IS d.c20 AND p.i2 IS d.c21 AND p.i3 IS d.c22
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,o.work,o.truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,o.c19 AS c19,o.c20 AS c20,o.c21 AS c21,o.c22 AS c22 FROM outcome1 d JOIN outcome3 o ON o.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.c19 AS node,d.work-1 AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 WHERE d.truth=1 AND d.c19 IS NOT NULL AND d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (145) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 WHERE w.stopped>=0 AND (n.kind IN (209))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (209) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 WHERE w.stopped>=0 AND (n.kind IN (1,204,205,211,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,((recursive_entry_2.level+1)+0) AS level,0 AS phase,NULL AS parent,d.work AS work,d.work AS start,0 AS fill,NULL AS token,0 AS truth,0 AS uncertain,0 AS cursor
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=0),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS 2000001 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k19 IS d.c19 AND m.k23 IS d.c23 AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS opened_token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.opened_token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,s.level,CASE WHEN s.hit IS NOT NULL THEN 4 WHEN s.level>=256 OR s.work=0 THEN 3 ELSE 10 END,s.parent,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
s.work,relation_cache_fill_steps(),s.opened_token,
CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,0,0 FROM noted s WHERE s.ready=1) WHERE recursive_entry_1.phase=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=3),
s AS MATERIALIZED (SELECT s.*,CASE WHEN s.token IS NOT NULL THEN relation_peak_close(s.token) END AS measured FROM reached s)
SELECT s.node,s.level,4,s.parent,s.work,s.start,s.fill,NULL,COALESCE(m.truth,s.truth),s.uncertain,s.cursor FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND s.truth>=0 AND s.token IS NOT NULL THEN 1 END AND m.clause IS 0 AND m.utility IS 2000001 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.k1 IS d.c1 AND m.k2 IS d.c2 AND m.k19 IS d.c19 AND m.k23 IS d.c23 AND m.vtruth IS s.truth AND m.vcost IS MAX(0,s.start-s.work-relation_cache_fill_delta(s.fill)) AND m.vpeak IS s.measured WHERE COALESCE(s.measured,0)>=0) WHERE recursive_entry_1.phase=3
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=4)
SELECT COALESCE(p.c0,s.node),COALESCE(p.c1,s.level),CASE WHEN s.parent IS NULL THEN 5 WHEN s.truth IN (0,2) THEN p.c7 ELSE 3 END,p.parent,s.work,p.c2,p.c3,p.c4,s.truth,COALESCE(p.c5,0) OR s.truth=2,p.c6
FROM s LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.parent IS NOT NULL THEN 2 END AND p.h IS s.parent) WHERE recursive_entry_1.phase=4
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=10) SELECT s.node,s.level,CASE WHEN r.c0 IN (0,2) THEN 11 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,recursive_entry_1.work) FROM node probe LEFT JOIN relation_value_budget(14,d.file,recursive_entry_1.node,CASE WHEN (recursive_entry_1.phase=10) AND ((probe.kind IN (1,204))) THEN recursive_entry_1.work END) v ON 1 WHERE probe.file=d.file AND probe.id=recursive_entry_1.node AND (recursive_entry_1.phase=10))) WHERE recursive_entry_1.phase=10
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=11) SELECT s.node,s.level,CASE WHEN r.c0 IN (0,2) THEN 12 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,recursive_entry_1.work) FROM node probe LEFT JOIN relation_value_budget(15,d.file,recursive_entry_1.node,CASE WHEN (recursive_entry_1.phase=11) AND ((probe.kind IN (1,204))) THEN recursive_entry_1.work END) v ON 1 WHERE probe.file=d.file AND probe.id=recursive_entry_1.node AND (recursive_entry_1.phase=11))) WHERE recursive_entry_1.phase=11
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=12),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (child.parent=s.node AND child.id>s.cursor AND child.id<=n."last") AND ((child.kind IN (1,204,205,211,226)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=child.file AND bound0.id=child.prev WHERE NOT (COALESCE(bound0."end">bound0.start,0))))) AND (n.kind IN (205,211)) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 13 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0
FROM s LEFT JOIN node chosen ON chosen.file=d.file AND chosen.id=s.child LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS chosen."last" AND p.v7 IS 12) WHERE recursive_entry_1.phase=12
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor WHERE recursive_entry_1.phase=13),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (child.parent=s.node AND child.id>s.cursor AND child.id<=n."last") AND (child.kind IN (1,204,205,211,226)) AND (n.kind IN (226)) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 3 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0
FROM s LEFT JOIN node chosen ON chosen.file=d.file AND chosen.id=s.child LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS chosen."last" AND p.v7 IS 13) WHERE recursive_entry_1.phase=13) SELECT truth,work FROM schedule WHERE phase=5)
) SELECT o.truth,o.work FROM outcome1 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c19 AS c19,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>1 THEN d.truth WHEN d.c19 IS NULL THEN 0 WHEN d.work=0 THEN -2 ELSE d.tested END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.c19 AS c19,d.c20 AS c20,d.c21 AS c21,d.c22 AS c22 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
) SELECT o.truth,o.work FROM outcome7 o)
),
outcome11 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome10 d
),
outcome12 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome11 s
) SELECT o.truth,o.work FROM outcome12 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)) WHERE recursive_entry_2.phase=11
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_2 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_2.node AS node,recursive_entry_2.level AS level,recursive_entry_2.phase AS phase,recursive_entry_2.parent AS parent,recursive_entry_2.work AS work,recursive_entry_2.start AS start,recursive_entry_2.fill AS fill,recursive_entry_2.token AS token,recursive_entry_2.truth AS truth,recursive_entry_2.uncertain AS uncertain,recursive_entry_2.cursor AS cursor WHERE recursive_entry_2.phase=10),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (child.parent=s.node AND child.id>s.cursor AND child.id<=n."last") AND (child.kind IN (1,226)) AND (n.kind IN (226)) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 11 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0
FROM s LEFT JOIN node chosen ON chosen.file=d.file AND chosen.id=s.child LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS chosen."last" AND p.v7 IS 10) WHERE recursive_entry_2.phase=10) SELECT truth,work FROM schedule WHERE phase=5)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome4 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome1 d LEFT JOIN outcome3 t ON t.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome4
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, CASE WHEN w.stopped<0 THEN 0 WHEN w.work=0 THEN -2 ELSE COALESCE(r.c0,0) END,w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN NOT (node_regex(17,probe.file,probe.id)) THEN 1 ELSE 0 END,w.work-1 FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0 AND w.work>0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<1) OR COALESCE(t.low,0)>1 THEN 0 WHEN COALESCE(t.low,0)>=1 AND (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<=1) AND (1) THEN 1 ELSE 2 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
) SELECT o.truth,o.work FROM outcome8 o)
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.c23 AS c23,d.u1,d.u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1,s.c2 AS c2 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome8 o)) WHERE recursive_entry_3.phase=11
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12 FROM schedule recursive_entry_3 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_3.node AS node,recursive_entry_3.level AS level,recursive_entry_3.phase AS phase,recursive_entry_3.parent AS parent,recursive_entry_3.work AS work,recursive_entry_3.start AS start,recursive_entry_3.fill AS fill,recursive_entry_3.token AS token,recursive_entry_3.truth AS truth,recursive_entry_3.uncertain AS uncertain,recursive_entry_3.cursor AS cursor,recursive_entry_3.c1 AS c1,recursive_entry_3.c2 AS c2 WHERE recursive_entry_3.phase=10),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (child.parent=s.node AND child.id>s.cursor AND child.id<=n."last") AND (child.kind IN (207,226)) AND (n.kind IN (226)) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 11 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0,NULL,NULL
FROM s LEFT JOIN node chosen ON chosen.file=d.file AND chosen.id=s.child LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS chosen."last" AND p.v7 IS 10) WHERE recursive_entry_3.phase=10) SELECT truth,work,c1,c2 FROM schedule WHERE phase=5)
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome1 o)) WHERE machine.pc=16 UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc=17) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(s.scope,s.env,23,r.c2) ELSE s.env END,s.scope FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 k,d.file,machine.node,machine.work,relation_state_get(machine.env,0) AS c0,relation_state_get(machine.env,1) AS c1,relation_state_get(machine.env,2) AS c2,relation_state_get(machine.env,23) AS c23 WHERE machine.pc=17
),outcome1 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.named AND (CASE WHEN d.c23 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c23,d.node) END) THEN 1 ELSE 0 END AS truth,d.node AS c23 FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
) SELECT o.truth,o.work,o.c23 AS c23 FROM outcome1 o)) WHERE machine.pc=17 UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc=19) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN s.env ELSE s.env END,s.scope FROM s CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 k,d.file,machine.node,machine.work,relation_state_get(machine.env,0) AS c0,relation_state_get(machine.env,1) AS c1,relation_state_get(machine.env,2) AS c2,relation_state_get(machine.env,23) AS c23 WHERE machine.pc=19
),outcome1 AS MATERIALIZED (
SELECT d.k,p.work,p.truth FROM outcome0 d CROSS JOIN relation_bound_budget p ON p.term=18 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c23 AND p.i1 IS d.c0
) SELECT o.truth,o.work FROM outcome1 o)) WHERE machine.pc=19 UNION ALL SELECT * FROM (SELECT machine.node,0,machine.level,machine.work,machine.handle,CASE WHEN machine.pc IN (10) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END WHEN machine.pc IN (11) THEN CASE WHEN (n.kind IN (191) AND EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE node_regex(0,a0n1.file,a0n1.id))) THEN 1 ELSE 0 END END,machine.env,machine.scope FROM node n  WHERE (machine.pc IN (10,11)) AND n.file=d.file AND n.id=machine.node) WHERE machine.pc IN (10,11)) WHERE machine.pc<>-1 AND r.c0 IS NOT NULL),returned AS MATERIALIZED (SELECT scope,truth,work,relation_state_get(env,0) c0,relation_state_get(env,1) c1,relation_state_get(env,2) c2,relation_state_get(env,23) c23 FROM schedule WHERE pc=-1),closed AS MATERIALIZED (SELECT returned.*,relation_state_end(scope) ready FROM returned) SELECT truth,work,c0,c1,c2,c23 FROM closed WHERE ready=1)
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2,o.c23 AS c23 FROM outcome1 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 pc,column2 op,column3 a,column4 ml,column5 mh,column6 wl,column7 wh,column8 strict FROM (VALUES (10,1,0,0,0,0,0,0),(11,1,1,0,0,0,0,0),(12,2,0,0,0,0,0,0),(13,6,0,0,0,0,0,0),(14,5,13,0,0,0,0,0),(15,1,2,1,0,1,0,1),(16,1,3,6,0,6,0,1),(17,1,4,8388608,0,8388608,0,1),(18,5,12,0,0,0,0,0),(19,1,5,8388609,0,0,0,0),(20,3,0,8388615,0,8388614,0,1),(21,6,0,8388615,0,8388614,0,1),(22,3,0,8388615,0,8388614,0,1),(23,6,0,8388615,0,8388614,0,1),(24,3,0,6,0,6,0,1),(25,6,0,6,0,6,0,1),(26,3,0,6,0,6,0,1),(27,4,0,6,0,6,0,1),(28,6,0,6,0,6,0,1),(29,4,0,6,0,6,0,1),(30,5,29,6,0,0,0,0),(31,3,0,8388615,0,8388615,0,1),(32,6,0,8388615,0,8388615,0,1),(33,3,0,8388615,0,8388615,0,1))),
constant0_1 AS MATERIALIZED (SELECT column1 pc,column2 ordinal,column3 child FROM (VALUES (20,0,17),(20,1,18),(20,2,16),(20,3,19),(22,0,14),(22,1,12),(22,2,21),(24,0,18),(24,1,16),(26,0,12),(26,1,25),(27,0,24),(27,1,26),(29,0,12),(29,1,28),(31,0,15),(31,1,16),(31,2,23),(31,3,30),(33,0,10),(33,1,14),(33,2,12),(33,3,32))),
constant0_2 AS MATERIALIZED (SELECT column1 id,column2 entry,column3 memo,column4 fills FROM (VALUES (0,11,0,0))),
constant0_3 AS MATERIALIZED (SELECT column1 pc,column2 axis,column3 ending,column4 field,column5 body,column6 stop,column7 minimum,column8 maximum,column9 count_slot,column10 count_offset,column11 strict FROM (VALUES (13,1,0,NULL,12,NULL,NULL,NULL,NULL,0,0),(21,0,1,NULL,20,18,NULL,NULL,NULL,0,1),(23,1,1,NULL,22,18,NULL,NULL,NULL,0,1),(25,0,1,NULL,24,18,NULL,NULL,NULL,0,1),(28,2,1,NULL,27,NULL,NULL,NULL,NULL,0,1),(32,0,1,NULL,31,18,NULL,NULL,NULL,0,1))),
constant0_4 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,4,0,1,0),(5,5,27,1,0),(6,4,1,5,0),(7,6,6,1,4),(8,4,7,1,0),(9,5,27,1,0),(10,4,1,9,0),(11,6,10,8,0),(12,4,11,8,0),(13,4,0,1,0),(14,5,27,13,1),(15,6,14,0,12),(16,4,0,1,0),(17,5,27,16,1),(18,6,17,15,12),(19,4,18,12,0),(20,4,0,1,0),(21,5,27,20,1),(22,6,21,0,19),(23,4,22,19,0),(24,5,27,0,1),(25,6,24,0,23),(26,4,25,23,0),(27,4,0,26,0),(28,5,27,0,1))),
constant0_5 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,4,0,1,0),(5,5,27,1,0),(6,4,1,5,0),(7,6,6,1,4),(8,4,7,1,0),(9,5,27,1,0),(10,4,1,9,0),(11,6,10,8,0),(12,4,11,8,0),(13,4,0,1,0),(14,5,27,13,1),(15,6,14,0,12),(16,4,0,1,0),(17,5,27,16,1),(18,6,17,15,12),(19,4,18,12,0),(20,4,0,1,0),(21,5,27,20,1),(22,6,21,0,19),(23,4,22,19,0),(24,5,27,0,1),(25,6,24,0,23),(26,4,25,23,0),(27,4,0,26,0),(28,5,27,0,1))),
semantic0_0_seed(file,node,active) AS MATERIALIZED (
 SELECT n.file,n.id,CASE WHEN NOT (0) AND (n.kind IN (226)) THEN 1 ELSE 0 END
 FROM node n
 WHERE n.kind IN (226) AND n.file IN (SELECT DISTINCT file FROM outcome1)
),
semantic0_0_domain(file,node) AS MATERIALIZED (
 SELECT file,node FROM semantic0_0_seed
 UNION
 SELECT c.file,c.id FROM semantic0_0_seed s
 CROSS JOIN node c ON c.file=s.file AND c.parent=s.node
 WHERE s.active AND (c.kind IN (1,204,226))
),
semantic0_0_local(file,node,parent,last,base,active,eligible) AS MATERIALIZED (
 SELECT n.file,n.id,n.parent,n."last",(0),
 CASE WHEN NOT (0) AND (n.kind IN (226)) THEN 1 ELSE 0 END,(n.kind IN (1,204,226))
 FROM semantic0_0_domain d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
semantic0_0_forest(file,node,tree,depth) AS MATERIALIZED (
 SELECT l.file,l.node,l.node,0 FROM semantic0_0_local l
 LEFT JOIN semantic0_0_local p ON p.file=l.file AND p.node=l.parent
 WHERE NOT l.eligible OR COALESCE(p.active,0)=0
 UNION ALL
 SELECT c.file,c.node,f.tree,f.depth+1
 FROM semantic0_0_forest f
 JOIN semantic0_0_local p ON p.file=f.file AND p.node=f.node AND p.active
 JOIN semantic0_0_local c ON c.file=p.file AND c.parent=p.node AND c.eligible
),
semantic0_0_ranked(file,node,tree,depth,last,base,rank) AS MATERIALIZED (
 SELECT f.file,f.node,f.tree,f.depth,l.last,l.base,
 ROW_NUMBER() OVER (PARTITION BY f.file,f.tree ORDER BY f.node)
 FROM semantic0_0_forest f JOIN semantic0_0_local l ON l.file=f.file AND l.node=f.node
),
semantic0_0_success(file,node,tree,depth,last,rank,success) AS MATERIALIZED (
 SELECT file,node,tree,depth,last,rank,
 MIN(CASE WHEN base THEN rank END) OVER (
 PARTITION BY file,tree ORDER BY rank
 ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING)
 FROM semantic0_0_ranked
),
semantic0_0_events(file,node,tree,position,event,rank) AS MATERIALIZED (
 SELECT file,node,tree,node,0,rank FROM semantic0_0_ranked
 UNION ALL
 SELECT file,node,tree,last,1,NULL FROM semantic0_0_ranked
),
semantic0_0_exits(file,node,tree,event,endrank) AS MATERIALIZED (
 SELECT file,node,tree,event,
 MAX(rank) OVER (PARTITION BY file,tree ORDER BY position,event
 ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
 FROM semantic0_0_events
),
semantic0_0_finished(file,node,tree,depth,rank,finish,truth) AS MATERIALIZED (
 SELECT s.file,s.node,s.tree,s.depth,s.rank,
 CASE WHEN s.success<=e.endrank THEN s.success ELSE e.endrank END,
 CASE WHEN s.success<=e.endrank THEN 1 ELSE 0 END
 FROM semantic0_0_success s JOIN semantic0_0_exits e
 ON e.file=s.file AND e.node=s.node AND e.tree=s.tree AND e.event=1
),
semantic0_0_summary(file,node,tree,depth,rank,finish,truth,cost) AS MATERIALIZED (
 SELECT file,node,tree,depth,rank,finish,truth,finish-rank+1
 FROM semantic0_0_finished
),
downward0_0_seed(file,node,active) AS MATERIALIZED (
 SELECT n.file,n.id,CASE WHEN NOT (n.kind IN (1)) AND (n.kind IN (226)) THEN 1 ELSE 0 END
 FROM node n
 WHERE n.kind IN (226) AND n.file IN (SELECT DISTINCT file FROM outcome1)
),
downward0_0_domain(file,node) AS MATERIALIZED (
 SELECT file,node FROM downward0_0_seed
 UNION
 SELECT c.file,c.id FROM downward0_0_seed s
 CROSS JOIN node c ON c.file=s.file AND c.parent=s.node
 WHERE s.active AND (c.kind IN (1,226))
),
downward0_0_local(file,node,parent,last,base,active,eligible) AS MATERIALIZED (
 SELECT n.file,n.id,n.parent,n."last",(n.kind IN (1)),
 CASE WHEN NOT (n.kind IN (1)) AND (n.kind IN (226)) THEN 1 ELSE 0 END,(n.kind IN (1,226))
 FROM downward0_0_domain d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
downward0_0_forest(file,node,tree,depth) AS MATERIALIZED (
 SELECT l.file,l.node,l.node,0 FROM downward0_0_local l
 LEFT JOIN downward0_0_local p ON p.file=l.file AND p.node=l.parent
 WHERE NOT l.eligible OR COALESCE(p.active,0)=0
 UNION ALL
 SELECT c.file,c.node,f.tree,f.depth+1
 FROM downward0_0_forest f
 JOIN downward0_0_local p ON p.file=f.file AND p.node=f.node AND p.active
 JOIN downward0_0_local c ON c.file=p.file AND c.parent=p.node AND c.eligible
),
downward0_0_ranked(file,node,tree,depth,last,base,rank) AS MATERIALIZED (
 SELECT f.file,f.node,f.tree,f.depth,l.last,l.base,
 ROW_NUMBER() OVER (PARTITION BY f.file,f.tree ORDER BY f.node)
 FROM downward0_0_forest f JOIN downward0_0_local l ON l.file=f.file AND l.node=f.node
),
downward0_0_success(file,node,tree,depth,last,rank,success) AS MATERIALIZED (
 SELECT file,node,tree,depth,last,rank,
 MIN(CASE WHEN base THEN rank END) OVER (
 PARTITION BY file,tree ORDER BY rank
 ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING)
 FROM downward0_0_ranked
),
downward0_0_events(file,node,tree,position,event,rank) AS MATERIALIZED (
 SELECT file,node,tree,node,0,rank FROM downward0_0_ranked
 UNION ALL
 SELECT file,node,tree,last,1,NULL FROM downward0_0_ranked
),
downward0_0_exits(file,node,tree,event,endrank) AS MATERIALIZED (
 SELECT file,node,tree,event,
 MAX(rank) OVER (PARTITION BY file,tree ORDER BY position,event
 ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
 FROM downward0_0_events
),
downward0_0_finished(file,node,tree,depth,rank,finish,truth) AS MATERIALIZED (
 SELECT s.file,s.node,s.tree,s.depth,s.rank,
 CASE WHEN s.success<=e.endrank THEN s.success ELSE e.endrank END,
 CASE WHEN s.success<=e.endrank THEN 1 ELSE 0 END
 FROM downward0_0_success s JOIN downward0_0_exits e
 ON e.file=s.file AND e.node=s.node AND e.tree=s.tree AND e.event=1
),
downward0_0_summary(file,node,tree,depth,rank,finish,truth,cost) AS MATERIALIZED (
 SELECT file,node,tree,depth,rank,finish,truth,finish-rank+1
 FROM downward0_0_finished
),
outcome11 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c0 AS v0,o.c2 AS v1,o.c1 AS v2,o.c23 AS v3 FROM outcome2 o WHERE o.truth=1 OR o.truth<0
),
outcome12 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome11 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(m.v0,m.v1,m.v2,m.v3) END AS payload,0 AS failure,m.work FROM outcome11 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome12 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome12
ORDER BY 1,2,3