WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n WHERE 1 AND n.kind IN (1,204)
),
outcome1 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0 FROM outcome0 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2 FROM outcome1 w CROSS JOIN outcome0 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,20 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 5 THEN n.kind IN (226) WHEN 7 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.prev LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.parent WHERE ((CASE WHEN bound0.id IS NOT NULL THEN node_regex(0,bound0.file,bound0.id) ELSE 0 END OR CASE WHEN bound1.id IS NOT NULL THEN node_regex(0,bound1.file,bound1.id) ELSE 0 END) AND COALESCE(bound2.kind IN (140),0))) WHEN 9 THEN n.kind IN (218) WHEN 13 THEN n.kind IN (226) WHEN 16 THEN n.kind IN (186) WHEN 18 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE NOT (COALESCE(bound0."end">bound0.start,0))) WHEN 19 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.parent LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.prev WHERE (NOT (CASE WHEN bound0.id IS NOT NULL THEN node_regex(0,bound0.file,bound0.id) ELSE 0 END) AND COALESCE(bound1.kind IN (140),0) AND CASE WHEN bound2.id IS NOT NULL THEN node_regex(2,bound2.file,bound2.id) ELSE 0 END)) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 6 THEN n.parent WHEN 10 THEN n.parent WHEN 14 THEN n.parent WHEN 17 THEN n.parent END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 6 THEN n.kind IN (226) WHEN 10 THEN n.kind IN (218) WHEN 14 THEN n.kind IN (226) WHEN 17 THEN n.kind IN (186) ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 6 THEN NULL WHEN 10 THEN NULL WHEN 14 THEN NULL WHEN 17 THEN NULL END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome3 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0 FROM outcome2 w JOIN outcome1 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE 1
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END AS truth,d.node AS c0 FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome3 d JOIN outcome4 o ON o.k=d.k WHERE o.truth<>0
),
outcome6 AS MATERIALIZED (
SELECT * FROM outcome5 WHERE choice=1
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome1 d LEFT JOIN outcome6 o ON o.parent=d.k
),
outcome8 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome7
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,COALESCE(r.c0,0),w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe.kind IN (140) THEN 1 ELSE 0 END,w.work FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (1)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0 AND (n.kind IN (140))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (140) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.prev AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.prev) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0 AND (n.kind IN (140))
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (140) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0 AND (n.kind IN (1,204))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,20 AS pc,d.work,(1) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 5 THEN n.kind IN (226) WHEN 7 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.prev LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.parent WHERE ((CASE WHEN bound0.id IS NOT NULL THEN node_regex(0,bound0.file,bound0.id) ELSE 0 END OR CASE WHEN bound1.id IS NOT NULL THEN node_regex(0,bound1.file,bound1.id) ELSE 0 END) AND COALESCE(bound2.kind IN (140),0))) WHEN 9 THEN n.kind IN (218) WHEN 13 THEN n.kind IN (226) WHEN 16 THEN n.kind IN (186) WHEN 18 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE NOT (COALESCE(bound0."end">bound0.start,0))) WHEN 19 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.parent LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.prev WHERE (NOT (CASE WHEN bound0.id IS NOT NULL THEN node_regex(0,bound0.file,bound0.id) ELSE 0 END) AND COALESCE(bound1.kind IN (140),0) AND CASE WHEN bound2.id IS NOT NULL THEN node_regex(2,bound2.file,bound2.id) ELSE 0 END)) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 6 THEN n.parent WHEN 10 THEN n.parent WHEN 14 THEN n.parent WHEN 17 THEN n.parent END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 6 THEN n.kind IN (226) WHEN 10 THEN n.kind IN (218) WHEN 14 THEN n.kind IN (226) WHEN 17 THEN n.kind IN (186) ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 6 THEN NULL WHEN 10 THEN NULL WHEN 14 THEN NULL WHEN 17 THEN NULL END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome3 s
) SELECT o.truth,o.work FROM outcome4 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,9 AS pc,d.work,(1) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 5 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE NOT (COALESCE(bound0."end">bound0.start,0))) WHEN 7 THEN n.kind IN (204) WHEN 8 THEN n.kind IN (1) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_2 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_2 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_2 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 6 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (1,204)) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 6 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 6 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (1,204)) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome8 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,COALESCE(r.c0,0),w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe.kind IN (161) THEN 1 ELSE 0 END,w.work FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)))) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.prev END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN w.stopped=0 THEN n.prev END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN w.stopped=0 THEN n.prev END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.parent END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN w.stopped=0 THEN n.parent END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN w.stopped=0 THEN n.parent END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome8 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,9 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 5 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE NOT (COALESCE(bound0."end">bound0.start,0))) WHEN 7 THEN n.kind IN (204) WHEN 8 THEN n.kind IN (1) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_3 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_3 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_3 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 6 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (1,204)) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 6 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 6 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (1,204)) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome8 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,11,0,1),(5,4,4,1,0),(6,6,5,0,1),(7,4,0,6,0),(8,5,19,0,1),(9,4,8,1,0),(10,6,9,0,7),(11,5,19,0,10),(12,5,19,0,1),(13,4,12,1,0),(14,6,13,0,1),(15,5,19,0,1),(16,4,15,1,0),(17,6,16,0,14),(18,4,17,14,0),(19,4,0,18,0),(20,5,11,0,1))),
constant0_1 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,11,0,1),(5,4,4,1,0),(6,6,5,0,1),(7,4,0,6,0),(8,5,19,0,1),(9,4,8,1,0),(10,6,9,0,7),(11,5,19,0,10),(12,5,19,0,1),(13,4,12,1,0),(14,6,13,0,1),(15,5,19,0,1),(16,4,15,1,0),(17,6,16,0,14),(18,4,17,14,0),(19,4,0,18,0),(20,5,11,0,1))),
constant0_2 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,8,0,1),(5,4,4,1,0),(6,6,5,0,1),(7,4,6,1,0),(8,4,0,7,0),(9,5,8,0,1))),
constant0_3 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,8,0,1),(5,4,4,1,0),(6,6,5,0,1),(7,4,6,1,0),(8,4,0,7,0),(9,5,8,0,1))),
outcome6 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c0 AS v0 FROM outcome1 o WHERE o.truth=1 OR o.truth<0
),
outcome7 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome6 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(m.v0) END AS payload,0 AS failure,m.work FROM outcome6 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome7 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome7
ORDER BY 1,2,3