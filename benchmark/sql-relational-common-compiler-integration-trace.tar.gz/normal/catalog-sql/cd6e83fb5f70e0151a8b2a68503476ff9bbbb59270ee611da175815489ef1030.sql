WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM node AS a0n1 CROSS JOIN node AS a0n0 ON a0n0.file=a0n1.file AND a0n0.parent=a0n1.id CROSS JOIN node AS a0n2 ON a0n2.file=a0n0.file AND a0n2.id=a0n0.next WHERE node_regex(0,a0n0.file,a0n0.id) AND a0n1.kind IN (140) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit1 CROSS JOIN node AS a1n1 ON a1n1.file=a0n1.file AND a1n1.parent=a0n1.id CROSS JOIN node AS a1n2 ON a1n2.file=a1n1.file AND a1n2.parent=a1n1.id WHERE a1n1.kind IN (161) AND a1n2.kind IN (127) AND node_regex(1,a1n2.file,a1n2.id))) AND node_regex(2,a0n2.file,a0n2.id)
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node