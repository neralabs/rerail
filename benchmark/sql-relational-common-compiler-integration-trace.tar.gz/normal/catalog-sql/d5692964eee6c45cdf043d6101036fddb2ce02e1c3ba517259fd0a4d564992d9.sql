WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work FROM node n WHERE 1 AND n.kind IN (111,115)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,NULL AS c0,NULL AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN (n.kind IN (111) AND relation_pattern(0,n.file,n.id)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.work,p.truth,p.c0 AS c0 FROM outcome0 d CROSS JOIN relation_pattern_typed p ON p.term=1 AND p.file=d.file AND p.node=d.node AND p.i0 IS d.c0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,d.c1 AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.work,p.truth,p.c0 AS c1 FROM outcome0 d CROSS JOIN relation_pattern_typed p ON p.term=2 AND p.file=d.file AND p.node=d.node AND p.i0 IS d.c1
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome1 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN (n.kind IN (115) AND relation_pattern(3,n.file,n.id)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome7 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome9 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.work,p.truth,p.c0 AS c0 FROM outcome0 d CROSS JOIN relation_pattern_typed p ON p.term=4 AND p.file=d.file AND p.node=d.node AND p.i0 IS d.c0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)
),
outcome11 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,d.c1 AS c1 FROM outcome10 d
),
outcome12 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN (n.kind IN (111) AND relation_pattern(5,n.file,n.id)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome11 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome13 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1 FROM outcome12 d
),
outcome14 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome13 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.work,p.truth,p.c0 AS c0 FROM outcome0 d CROSS JOIN relation_pattern_typed p ON p.term=6 AND p.file=d.file AND p.node=d.node AND p.i0 IS d.c0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)
),
outcome15 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,d.c1 AS c1 FROM outcome14 d
),
outcome16 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome15 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.work,p.truth,p.c0 AS c1 FROM outcome0 d CROSS JOIN relation_pattern_typed p ON p.term=7 AND p.file=d.file AND p.node=d.node AND p.i0 IS d.c1
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome1 o)
),
outcome17 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1 FROM outcome16 d
),
outcome18 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN (n.kind IN (115) AND relation_pattern(8,n.file,n.id)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome17 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome19 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0,d.c1 AS c1 FROM outcome18 d
),
outcome20 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome19 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.work,p.truth,p.c0 AS c0 FROM outcome0 d CROSS JOIN relation_pattern_typed p ON p.term=9 AND p.file=d.file AND p.node=d.node AND p.i0 IS d.c0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)
),
outcome21 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,d.c1 AS c1 FROM outcome20 d
),
outcome22 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c0 AS c0,s.c1 AS c1 FROM outcome21 s
)
-- final matches
SELECT 0,d.file,d.node,json_array(o.c0,json(relation_list_json(o.c1,d.file))) FROM outcome0 d JOIN outcome22 o ON o.k=d.k WHERE o.truth=1 ORDER BY d.file,d.node