WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT relation_memo_reset(0) AS ready
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n CROSS JOIN outcome0 init ON init.ready=1 WHERE 1 AND n.kind IN (1)
),
outcome2 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0 FROM outcome1 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2 FROM outcome2 w CROSS JOIN outcome1 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 work,r.c0 truth,r.c2 c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE owner AS MATERIALIZED (SELECT relation_state_begin() scope WHERE d.file IS NOT NULL),schedule AS (SELECT d.node node,16 pc,(0) level,d.work work,NULL handle,0 truth,0 env,owner.scope scope FROM owner UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7) IS (SELECT * FROM (WITH s AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc=0),popped AS MATERIALIZED (SELECT s.*,frame.parent,frame.c0,frame.c1,frame.c2,frame.c3,frame.c4,frame.c5,frame.c6,frame.c7,frame.c8,frame.c9,frame.c10,frame.c11 FROM s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.handle IS NOT NULL THEN 2 END AND frame.h IS s.handle) SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7 FROM popped p CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7) IS (SELECT * FROM (SELECT p.node,-1,p.level,p.work,NULL,p.truth,p.env,p.scope WHERE p.handle IS NULL) UNION ALL SELECT * FROM (WITH reached AS MATERIALIZED (SELECT p.node AS node,p.pc AS pc,p.level AS level,p.work AS work,p.handle AS handle,p.truth AS truth,p.env AS env,p.scope AS scope,p.parent AS parent,p.c0 AS c0,p.c1 AS c1,p.c2 AS c2,p.c3 AS c3,p.c4 AS c4,p.c5 AS c5,p.c6 AS c6,p.c7 AS c7,p.c8 AS c8,p.c9 AS c9,p.c10 AS c10,p.c11 AS c11 WHERE p.c0 IN (2,3)),edges AS MATERIALIZED (SELECT p.*,child.strict,child.wl,child.wh,(SELECT child FROM constant0_1 WHERE pc=p.c3 AND ordinal=p.c4+1) next FROM reached p JOIN constant0_1 edge ON edge.pc=p.c3 AND edge.ordinal=p.c4 JOIN constant0_0 child ON child.pc=edge.child),
changed AS MATERIALIZED (SELECT p.*,p.c5 OR p.truth=2 uncertain,CASE WHEN p.c0=2 AND p.truth=1 THEN p.env ELSE p.c7 END current_env,p.c8|CASE WHEN p.truth=2 THEN p.wl ELSE 0 END held_lo,p.c9|CASE WHEN p.truth=2 THEN p.wh ELSE 0 END held_hi FROM edges p),
s AS MATERIALIZED (SELECT p.*,p.next IS NOT NULL AND p.truth>=0 AND CASE p.c0 WHEN 2 THEN p.truth<>0 ELSE p.truth<>1 AND NOT(p.truth=2 AND p.strict) END more,COALESCE((p.held_lo & child.ml)<>0 OR (p.held_hi & child.mh)<>0,0) blocked FROM changed p LEFT JOIN constant0_0 child ON child.pc=p.next)
SELECT p.c1,CASE WHEN again.handle IS NOT NULL THEN CASE WHEN p.c0=2 AND p.blocked THEN 0 ELSE p.next END ELSE 0 END,p.c2,p.work,COALESCE(again.handle,p.parent),
CASE WHEN again.handle IS NOT NULL THEN CASE WHEN p.c0=2 AND p.blocked THEN 2 ELSE 0 END WHEN p.truth<0 THEN p.truth WHEN p.c0=2 AND p.truth=0 THEN 0 WHEN p.c0=3 AND p.truth=1 THEN 1 WHEN p.uncertain THEN 2 WHEN p.c0=2 THEN 1 ELSE 0 END,
CASE WHEN again.handle IS NOT NULL THEN CASE WHEN p.c0=2 THEN p.current_env ELSE p.c6 END WHEN p.c0=3 AND p.truth=1 THEN p.env WHEN p.c0=2 AND p.truth=1 AND NOT p.uncertain THEN p.current_env ELSE p.c6 END,p.scope FROM s p LEFT JOIN relation_continuation again ON again.mode IS CASE WHEN p.more THEN 1 END AND again.parent_input IS p.parent AND again.v0 IS (p.c0) AND again.v1 IS (p.c1) AND again.v2 IS (p.c2) AND again.v3 IS (p.c3) AND again.v4 IS (p.c4+1) AND again.v5 IS (p.uncertain) AND again.v6 IS (p.c6) AND again.v7 IS (p.current_env) AND again.v8 IS (p.held_lo) AND again.v9 IS (p.held_hi)) UNION ALL SELECT * FROM (WITH seed AS MATERIALIZED (SELECT p.node AS node,p.pc AS pc,p.level AS level,p.work AS work,p.handle AS handle,p.truth AS truth,p.env AS env,p.scope AS scope,p.parent AS parent,p.c0 AS c0,p.c1 AS c1,p.c2 AS c2,p.c3 AS c3,p.c4 AS c4,p.c5 AS c5,p.c6 AS c6,p.c7 AS c7,p.c8 AS c8,p.c9 AS c9,p.c10 AS c10,p.c11 AS c11 WHERE p.c0 IN (1,7) AND p.c3=11), parts AS MATERIALIZED (SELECT p.*,p.truth AS own,0 AS stopped FROM seed p), decision AS MATERIALIZED (SELECT p.*,p.own=1 AS decisive FROM parts p), ready AS MATERIALIZED (SELECT p.*,CASE WHEN p.stopped=0 THEN n.parent END AS next FROM decision p JOIN node n ON n.file=d.file AND n.id=p.c4) SELECT p.c1,0,p.c2,p.work,p.parent,CASE WHEN p.own<0 THEN p.own WHEN p.stopped<0 THEN p.stopped ELSE CASE WHEN (p.c7+(p.own=1))>0 THEN 1 WHEN (p.c9 OR p.stopped=2) OR (p.c8+(p.own=2))>0 THEN 2 ELSE 0 END END,CASE WHEN p.own=1 THEN p.env ELSE p.c6 END,p.scope FROM ready p WHERE (1) AND (p.own<0 OR p.stopped<0 OR p.decisive OR p.next IS NULL) UNION ALL SELECT p.next,CASE WHEN 0 THEN 0 WHEN ((edge.field=17 AND edge.ffirst=1) AND (candidate.kind IN (137))) THEN 10 ELSE 0 END,p.c2,p.work,frame.handle,0,p.c6,p.scope FROM ready p LEFT JOIN node candidate ON candidate.file=d.file AND candidate.id=p.next LEFT JOIN node edge ON edge.file=d.file AND edge.id=p.c4 LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN (1) AND NOT ((1) AND (p.own<0 OR p.stopped<0 OR p.decisive OR p.next IS NULL)) THEN 1 END AND frame.parent_input IS p.parent AND frame.v0 IS (1) AND frame.v1 IS (p.c1) AND frame.v2 IS (p.c2) AND frame.v3 IS (11) AND frame.v4 IS (p.next) AND frame.v5 IS (p.c5) AND frame.v6 IS (p.c6) AND frame.v7 IS ((p.c7+(p.own=1))) AND frame.v8 IS ((p.c8+(p.own=2))) AND frame.v9 IS ((p.c9 OR p.stopped=2)) AND frame.v10 IS (0) AND frame.v11 IS (p.c4) WHERE (1) AND NOT ((1) AND (p.own<0 OR p.stopped<0 OR p.decisive OR p.next IS NULL))))) WHERE machine.pc=0 UNION ALL SELECT * FROM (WITH reached AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op IN (3,4))),s AS MATERIALIZED (SELECT s.*,i.op,(SELECT child FROM constant0_1 WHERE pc=s.pc AND ordinal=0) child FROM reached s JOIN constant0_0 i ON i.pc=s.pc) SELECT s.node,COALESCE(s.child,0),s.level,s.work,COALESCE(frame.handle,s.handle),CASE WHEN s.child IS NULL THEN s.op=3 ELSE 0 END,s.env,s.scope FROM s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (CASE s.op WHEN 3 THEN 2 ELSE 3 END) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (0) AND frame.v5 IS (0) AND frame.v6 IS (s.env) AND frame.v7 IS (s.env) AND frame.v8 IS (0) AND frame.v9 IS (0)) WHERE machine.pc IN (SELECT pc FROM constant0_0 WHERE op IN (3,4)) UNION ALL SELECT * FROM (WITH seed AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc=11), first AS MATERIALIZED (SELECT s.*,origin.parent AS first FROM seed s JOIN node origin ON origin.file=d.file AND origin.id=s.node), picked AS MATERIALIZED (SELECT s.*,origin."last" AS bound FROM first s JOIN node origin ON origin.file=d.file AND origin.id=s.node LEFT JOIN node candidate ON candidate.file=d.file AND candidate.id=s.first) SELECT s.first,CASE WHEN 0 THEN 0 WHEN ((origin.field=17 AND origin.ffirst=1) AND (candidate.kind IN (137))) THEN 10 ELSE 0 END,s.level,s.work,frame.handle,0,s.env,s.scope FROM picked s JOIN node origin ON origin.file=d.file AND origin.id=s.node JOIN node candidate ON candidate.file=d.file AND candidate.id=s.first LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.first IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (1) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (11) AND frame.v4 IS (s.first) AND frame.v5 IS (s.bound) AND frame.v6 IS (s.env) AND frame.v7 IS (0) AND frame.v8 IS (0) AND frame.v9 IS (0) AND frame.v10 IS (0) AND frame.v11 IS (s.node) WHERE s.first IS NOT NULL UNION ALL SELECT s.node,0,s.level,s.work,s.handle,CASE WHEN 0>0 THEN 1 WHEN 0 OR 0>0 THEN 2 ELSE 0 END,s.env,s.scope FROM picked s WHERE s.first IS NULL) WHERE machine.pc=11 UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc=13) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(s.scope,s.env,0,r.c2) ELSE s.env END,s.scope FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 k,d.file,machine.node,machine.work,relation_state_get(machine.env,0) AS c0 WHERE machine.pc=13
),outcome1 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END AS truth,d.node AS c0 FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)) WHERE machine.pc=13 UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.truth AS truth,machine.env AS env,machine.scope AS scope WHERE machine.pc=15) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(s.scope,s.env,0,r.c2) ELSE s.env END,s.scope FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 k,d.file,machine.node,machine.work,relation_state_get(machine.env,0) AS c0 WHERE machine.pc=15
),outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,((machine.level)+0) AS level,0 AS phase,NULL AS parent,d.work AS work,d.work AS start,0 AS fill,NULL AS token,0 AS truth,0 AS uncertain,0 AS cursor,NULL AS c0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor,recursive_entry_1.c0 AS c0 WHERE recursive_entry_1.phase=0),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak,m.o0 AS e0 FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS 2000001 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS opened_token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.opened_token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,s.level,CASE WHEN s.hit IS NOT NULL THEN 4 WHEN s.level>=256 OR s.work=0 THEN 3 ELSE 10 END,s.parent,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
s.work,relation_cache_fill_steps(),s.opened_token,
CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,0,0,s.e0 FROM noted s WHERE s.ready=1) WHERE recursive_entry_1.phase=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor,recursive_entry_1.c0 AS c0 WHERE recursive_entry_1.phase=3),
s AS MATERIALIZED (SELECT s.*,CASE WHEN s.token IS NOT NULL THEN relation_peak_close(s.token) END AS measured FROM reached s)
SELECT s.node,s.level,4,s.parent,s.work,s.start,s.fill,NULL,COALESCE(m.truth,s.truth),s.uncertain,s.cursor,s.c0 FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND s.truth>=0 AND s.token IS NOT NULL THEN 1 END AND m.clause IS 0 AND m.utility IS 2000001 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.vtruth IS s.truth AND m.vcost IS MAX(0,s.start-s.work-relation_cache_fill_delta(s.fill)) AND m.vpeak IS s.measured AND m.v0 IS CASE WHEN s.truth=1 THEN s.c0 END WHERE COALESCE(s.measured,0)>=0) WHERE recursive_entry_1.phase=3
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor,recursive_entry_1.c0 AS c0 WHERE recursive_entry_1.phase=4)
SELECT COALESCE(p.c0,s.node),COALESCE(p.c1,s.level),CASE WHEN s.parent IS NULL THEN 5 WHEN s.truth=0 THEN p.c7 ELSE 3 END,p.parent,s.work,p.c2,p.c3,p.c4,s.truth,COALESCE(p.c5,0) OR s.truth=2,p.c6,s.c0
FROM s LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.parent IS NOT NULL THEN 2 END AND p.h IS s.parent) WHERE recursive_entry_1.phase=4
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor,recursive_entry_1.c0 AS c0 WHERE recursive_entry_1.phase=10) SELECT s.node,s.level,CASE WHEN r.c0=0 THEN 11 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0,r.c2 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,recursive_entry_1.node AS node,recursive_entry_1.work AS work,d.c0 AS c0 WHERE recursive_entry_1.phase=10
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0 AND (n.kind IN (137))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (137) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.*,relation_state_begin() AS state_scope FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth,r.c2 AS c0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,42 AS pc,((recursive_entry_1.level+1)+0) AS level,d.work AS work,NULL AS handle,0 AS truth,relation_state_put_owned(d.state_scope,0,0,d.c0) AS env
UNION ALL
SELECT mixed_entry_4000000.node,0,mixed_entry_4000000.level,mixed_entry_4000000.work,mixed_entry_4000000.handle,mixed_entry_4000000.truth,mixed_entry_4000000.env FROM schedule mixed_entry_4000000 WHERE mixed_entry_4000000.pc=1
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH reached AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=4)),
s AS MATERIALIZED (SELECT reached.*,f.id AS function,f.entry FROM reached JOIN constant0_3 i ON i.pc=reached.pc JOIN constant0_5 f ON f.id=i.a),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak,m.o0 AS o0 FROM s JOIN constant0_5 f ON f.id=s.function LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS f.memo AND m.file IS d.file AND m.node IS s.node AND m.k0 IS CASE f.id WHEN 0 THEN relation_state_get(s.env,0) WHEN 1 THEN relation_state_get(s.env,0) WHEN 2 THEN relation_state_get(s.env,0) ELSE NULL END AND m.peak<=256-s.level),
replay0 AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL AND s.o0 IS NOT NULL THEN relation_state_put(d.state_scope,s.env,0,s.o0) ELSE s.env END AS replay_env0 FROM lookup s),
opened AS MATERIALIZED (SELECT s.*,s.replay_env0 AS recalled_env,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS token FROM replay0 s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,CASE WHEN s.hit IS NOT NULL OR s.level>=256 THEN 0 WHEN s.work=0 THEN 1 ELSE s.entry END,
CASE WHEN s.hit IS NULL AND s.level<256 THEN s.level+1 ELSE s.level END,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
COALESCE(frame.handle,s.handle),CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,CASE WHEN s.hit IS NOT NULL THEN s.recalled_env ELSE s.env END
FROM noted s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.hit IS NULL AND s.level<256 AND s.ready=1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (0) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.function) AND frame.v4 IS (s.work) AND frame.v5 IS (relation_cache_fill_steps()) AND frame.v6 IS (s.token) AND frame.v7 IS (s.env) WHERE s.ready=1) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=4)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=2)) SELECT s.node,0,s.level,s.work,s.handle,CASE WHEN (CASE s.pc WHEN 3 THEN n.kind IN (221,222,223,224) WHEN 4 THEN n.kind IN (228) WHEN 6 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(2,bound0.file,bound0.id) ELSE 0 END) WHEN 12 THEN n.kind IN (197) WHEN 14 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(3,bound0.file,bound0.id) ELSE 0 END) WHEN 18 THEN NOT (n.kind IN (197,221,222,223,224)) WHEN 22 THEN n.kind IN (226) WHEN 26 THEN NOT (n.kind IN (226)) WHEN 28 THEN n.kind IN (228,229) WHEN 37 THEN n.kind IN (197,221,222,223,224) ELSE 0 END) THEN 1 ELSE 0 END,s.env FROM s JOIN node n ON n.file=d.file AND n.id=s.node) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=2)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=5)), i AS MATERIALIZED (SELECT s.*,i.a,(SELECT child FROM constant0_4 WHERE pc=s.pc AND ordinal=0) AS child FROM s JOIN constant0_3 i ON i.pc=s.pc) SELECT s.node,COALESCE(s.child,0),s.level,s.work,COALESCE(frame.handle,s.handle),CASE WHEN s.child IS NULL THEN s.a ELSE 0 END,s.env FROM i s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (CASE WHEN s.a=1 THEN 2 ELSE 3 END) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (0) AND frame.v5 IS (0) AND frame.v6 IS (s.env)) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=5)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=6)) SELECT s.node,i.a,s.level,s.work,frame.handle,0,s.env FROM s JOIN constant0_3 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN 1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (4) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.env)) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=6)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH reached AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=7)),s AS MATERIALIZED (SELECT s.*,n."last" AS bound,CASE s.pc WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (candidate.kind IN (228)) ORDER BY candidate.id LIMIT 1) WHEN 16 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 24 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 30 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 33 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 41 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.id>s.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END AS child FROM reached s JOIN node n ON n.file=d.file AND n.id=s.node) SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN 0 ELSE -2 END,s.level,s.work,COALESCE(frame.handle,s.handle),0,s.env FROM s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (1) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (s.child) AND frame.v5 IS (s.bound) AND frame.v6 IS (0) AND frame.v7 IS (s.env)) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_3 WHERE op=7)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=-2) SELECT s.node,CASE WHEN (CASE p.c3 WHEN 8 THEN 1 WHEN 10 THEN 1 WHEN 16 THEN 1 WHEN 24 THEN 1 WHEN 30 THEN 1 WHEN 33 THEN 1 WHEN 41 THEN n.kind IN (1,197,221,222,223,224) ELSE 1 END) THEN i.a ELSE 0 END,s.level,s.work,s.handle,0,s.env FROM s CROSS JOIN relation_continuation p ON p.mode IS 0 AND p.h IS s.handle JOIN constant0_3 i ON i.pc=p.c3 JOIN node n ON n.file=d.file AND n.id=s.node) WHERE mixed_entry_4000000.pc=-2
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH reached AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=0),
popped AS MATERIALIZED (SELECT s.*,frame.parent,frame.c0,frame.c1,frame.c2,frame.c3,frame.c4,frame.c5,frame.c6,frame.c7 FROM reached s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.handle IS NOT NULL THEN 2 END AND frame.h IS s.handle),
closed AS MATERIALIZED (SELECT p.*,CASE WHEN p.c0=0 THEN relation_peak_close(p.c6) END AS measured FROM popped p),
published AS MATERIALIZED (SELECT p.*,COALESCE(m.truth,p.truth) AS returned FROM closed p LEFT JOIN constant0_5 f ON p.c0=0 AND f.id=p.c3 LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND p.c0=0 AND p.truth>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS f.memo AND m.file IS d.file AND m.node IS p.c1 AND m.k0 IS CASE f.id WHEN 0 THEN relation_state_get(p.c7,0) WHEN 1 THEN relation_state_get(p.c7,0) WHEN 2 THEN relation_state_get(p.c7,0) ELSE NULL END AND m.v0 IS CASE WHEN p.truth=1 THEN CASE f.id WHEN 0 THEN relation_state_get(p.env,0) WHEN 1 THEN relation_state_get(p.env,0) WHEN 2 THEN relation_state_get(p.env,0) ELSE NULL END END AND m.vtruth IS p.truth AND m.vcost IS CASE WHEN p.c0=0 AND p.truth>=0 THEN MAX(0,p.c4-p.work-relation_cache_fill_delta(p.c5)) END AND m.vpeak IS p.measured WHERE COALESCE(p.measured,0)>=0),
classified AS MATERIALIZED (SELECT p.*,CASE WHEN p.c0 IN (2,3) AND p.truth>=0 AND NOT ((p.c0=2 AND p.truth=0) OR (p.c0=3 AND p.truth=1)) THEN (SELECT child FROM constant0_4 WHERE pc=p.c3 AND ordinal=p.c4+1) END AS child,CASE WHEN p.c0=1 AND p.truth IN (0,2) THEN CASE p.c3 WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (candidate.kind IN (228)) ORDER BY candidate.id LIMIT 1) WHEN 16 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 24 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 30 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 33 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 41 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.id>CASE WHEN (n.kind IN (197,221,222,223,224)) THEN n."last" ELSE p.c4 END AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END END AS candidate FROM published p LEFT JOIN node n ON p.c0=1 AND n.file=d.file AND n.id=p.c4)
SELECT CASE WHEN p.handle IS NULL THEN p.node WHEN p.c0=1 AND search_again.handle IS NOT NULL THEN p.candidate ELSE p.c1 END,
CASE WHEN p.handle IS NULL THEN -1 WHEN bool_again.handle IS NOT NULL THEN p.child WHEN search_again.handle IS NOT NULL THEN -2 ELSE 0 END,
CASE WHEN p.handle IS NULL THEN p.level ELSE p.c2 END,p.work,
COALESCE(bool_again.handle,search_again.handle,p.parent),
CASE WHEN p.handle IS NULL THEN p.truth WHEN p.c0=0 THEN p.returned WHEN p.c0=4 THEN CASE p.truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE p.truth END
WHEN bool_again.handle IS NOT NULL OR search_again.handle IS NOT NULL THEN 0 WHEN p.truth<0 THEN p.truth
WHEN p.c0=2 AND p.truth=0 THEN 0 WHEN p.c0=3 AND p.truth=1 THEN 1
WHEN p.c0 IN (2,3) THEN CASE WHEN p.c5 OR p.truth=2 THEN 2 WHEN p.c0=2 THEN 1 ELSE 0 END
WHEN p.c0=1 THEN CASE WHEN p.truth=1 THEN 1 WHEN p.c6 OR p.truth=2 THEN 2 ELSE 0 END END,
CASE WHEN p.handle IS NULL THEN p.env
WHEN p.c0=0 THEN CASE WHEN p.truth=1 THEN p.env ELSE p.c7 END
WHEN p.c0=4 THEN p.c3
WHEN p.c0 IN (2,3) THEN CASE WHEN bool_again.handle IS NOT NULL AND p.c0=2 THEN p.env WHEN bool_again.handle IS NOT NULL OR p.truth<>1 THEN p.c6 ELSE p.env END
WHEN p.c0=1 THEN CASE WHEN search_again.handle IS NOT NULL OR p.truth<>1 THEN p.c7 ELSE p.env END END
FROM classified p LEFT JOIN relation_continuation bool_again ON bool_again.mode IS CASE WHEN p.c0 IN (2,3) AND p.truth>=0 AND NOT ((p.c0=2 AND p.truth=0) OR (p.c0=3 AND p.truth=1)) AND p.child IS NOT NULL THEN 1 END AND bool_again.parent_input IS p.parent AND bool_again.v0 IS (p.c0) AND bool_again.v1 IS (p.c1) AND bool_again.v2 IS (p.c2) AND bool_again.v3 IS (p.c3) AND bool_again.v4 IS (p.c4+1) AND bool_again.v5 IS (p.c5 OR p.truth=2) AND bool_again.v6 IS (p.c6) LEFT JOIN relation_continuation search_again ON search_again.mode IS CASE WHEN p.c0=1 AND p.truth IN (0,2) AND p.candidate IS NOT NULL THEN 1 END AND search_again.parent_input IS p.parent AND search_again.v0 IS (1) AND search_again.v1 IS (p.c1) AND search_again.v2 IS (p.c2) AND search_again.v3 IS (p.c3) AND search_again.v4 IS (p.candidate) AND search_again.v5 IS (p.c5) AND search_again.v6 IS (p.c6 OR p.truth=2) AND search_again.v7 IS (p.c7)) WHERE mixed_entry_4000000.pc=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=2) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(d.state_scope,s.env,0,r.c2) ELSE s.env END FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,mixed_entry_4000000.node AS node,mixed_entry_4000000.work AS work,relation_state_get(mixed_entry_4000000.env,0) AS c0 WHERE mixed_entry_4000000.pc=2
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((mixed_entry_4000000.level)+0) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((mixed_entry_4000000.level)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (1)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.next LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.prev WHERE NOT (((COALESCE(bound0.kind IN (215),0) AND CASE WHEN bound1.id IS NOT NULL THEN node_regex(1,bound1.file,bound1.id) ELSE 0 END) OR CASE WHEN bound2.id IS NOT NULL THEN node_regex(0,bound2.file,bound2.id) ELSE 0 END))))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 FROM outcome1 o)) WHERE mixed_entry_4000000.pc=2
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=36) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(d.state_scope,s.env,0,r.c2) ELSE s.env END FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,mixed_entry_4000000.node AS node,mixed_entry_4000000.work AS work,relation_state_get(mixed_entry_4000000.env,0) AS c0 WHERE mixed_entry_4000000.pc=36
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((mixed_entry_4000000.level)+0) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((mixed_entry_4000000.level)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (1)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.next LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.prev WHERE NOT (((COALESCE(bound0.kind IN (215),0) AND CASE WHEN bound1.id IS NOT NULL THEN node_regex(1,bound1.file,bound1.id) ELSE 0 END) OR CASE WHEN bound2.id IS NOT NULL THEN node_regex(0,bound2.file,bound2.id) ELSE 0 END))))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 FROM outcome1 o)) WHERE mixed_entry_4000000.pc=36) SELECT truth,work,relation_state_get(env,0) FROM schedule WHERE pc=-1) WHERE relation_state_end(CASE WHEN r.c0 IS NOT NULL THEN d.state_scope END)=1
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((recursive_entry_1.level+1)+0) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((recursive_entry_1.level+1)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((recursive_entry_1.level+1)+1) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((recursive_entry_1.level+1)+1)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (197) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (147)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (147) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1,182)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (182) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (1)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(1,bound0.file,bound0.id) ELSE 0 END))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c0 AS c0 FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome10 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth,r.c2 AS c0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,((recursive_entry_1.level+1)+1) AS level,0 AS phase,NULL AS parent,d.work AS work,d.work AS start,0 AS fill,NULL AS token,0 AS truth,0 AS uncertain,0 AS cursor,NULL AS c0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=0),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak,m.o0 AS e0 FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS 2000000 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS opened_token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.opened_token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,s.level,CASE WHEN s.hit IS NOT NULL THEN 4 WHEN s.level>=256 OR s.work=0 THEN 3 ELSE 10 END,s.parent,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
s.work,relation_cache_fill_steps(),s.opened_token,
CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,0,0,s.e0 FROM noted s WHERE s.ready=1) WHERE recursive_entry_0.phase=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=3),
s AS MATERIALIZED (SELECT s.*,CASE WHEN s.token IS NOT NULL THEN relation_peak_close(s.token) END AS measured FROM reached s)
SELECT s.node,s.level,4,s.parent,s.work,s.start,s.fill,NULL,COALESCE(m.truth,s.truth),s.uncertain,s.cursor,s.c0 FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND s.truth>=0 AND s.token IS NOT NULL THEN 1 END AND m.clause IS 0 AND m.utility IS 2000000 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.vtruth IS s.truth AND m.vcost IS MAX(0,s.start-s.work-relation_cache_fill_delta(s.fill)) AND m.vpeak IS s.measured AND m.v0 IS CASE WHEN s.truth=1 THEN s.c0 END WHERE COALESCE(s.measured,0)>=0) WHERE recursive_entry_0.phase=3
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=4)
SELECT COALESCE(p.c0,s.node),COALESCE(p.c1,s.level),CASE WHEN s.parent IS NULL THEN 5 WHEN s.truth=0 THEN p.c7 ELSE 3 END,p.parent,s.work,p.c2,p.c3,p.c4,s.truth,COALESCE(p.c5,0) OR s.truth=2,p.c6,s.c0
FROM s LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.parent IS NOT NULL THEN 2 END AND p.h IS s.parent) WHERE recursive_entry_0.phase=4
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=10) SELECT s.node,s.level,CASE WHEN r.c0=0 THEN 11 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0,r.c2 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,recursive_entry_0.node AS node,recursive_entry_0.work AS work,d.c0 AS c0 WHERE recursive_entry_0.phase=10
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.next AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.next) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.*,relation_state_begin() AS state_scope FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth,r.c2 AS c0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,42 AS pc,((recursive_entry_0.level+1)+0) AS level,d.work AS work,NULL AS handle,0 AS truth,relation_state_put_owned(d.state_scope,0,0,d.c0) AS env
UNION ALL
SELECT mixed_entry_4000000.node,0,mixed_entry_4000000.level,mixed_entry_4000000.work,mixed_entry_4000000.handle,mixed_entry_4000000.truth,mixed_entry_4000000.env FROM schedule mixed_entry_4000000 WHERE mixed_entry_4000000.pc=1
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH reached AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=4)),
s AS MATERIALIZED (SELECT reached.*,f.id AS function,f.entry FROM reached JOIN constant0_6 i ON i.pc=reached.pc JOIN constant0_8 f ON f.id=i.a),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak,m.o0 AS o0 FROM s JOIN constant0_8 f ON f.id=s.function LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS f.memo AND m.file IS d.file AND m.node IS s.node AND m.k0 IS CASE f.id WHEN 0 THEN relation_state_get(s.env,0) WHEN 1 THEN relation_state_get(s.env,0) WHEN 2 THEN relation_state_get(s.env,0) ELSE NULL END AND m.peak<=256-s.level),
replay0 AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL AND s.o0 IS NOT NULL THEN relation_state_put(d.state_scope,s.env,0,s.o0) ELSE s.env END AS replay_env0 FROM lookup s),
opened AS MATERIALIZED (SELECT s.*,s.replay_env0 AS recalled_env,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS token FROM replay0 s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,CASE WHEN s.hit IS NOT NULL OR s.level>=256 THEN 0 WHEN s.work=0 THEN 1 ELSE s.entry END,
CASE WHEN s.hit IS NULL AND s.level<256 THEN s.level+1 ELSE s.level END,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
COALESCE(frame.handle,s.handle),CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,CASE WHEN s.hit IS NOT NULL THEN s.recalled_env ELSE s.env END
FROM noted s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.hit IS NULL AND s.level<256 AND s.ready=1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (0) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.function) AND frame.v4 IS (s.work) AND frame.v5 IS (relation_cache_fill_steps()) AND frame.v6 IS (s.token) AND frame.v7 IS (s.env) WHERE s.ready=1) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=4)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=2)) SELECT s.node,0,s.level,s.work,s.handle,CASE WHEN (CASE s.pc WHEN 3 THEN n.kind IN (221,222,223,224) WHEN 4 THEN n.kind IN (228) WHEN 6 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(2,bound0.file,bound0.id) ELSE 0 END) WHEN 12 THEN n.kind IN (197) WHEN 14 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(3,bound0.file,bound0.id) ELSE 0 END) WHEN 18 THEN NOT (n.kind IN (197,221,222,223,224)) WHEN 22 THEN n.kind IN (226) WHEN 26 THEN NOT (n.kind IN (226)) WHEN 28 THEN n.kind IN (228,229) WHEN 37 THEN n.kind IN (197,221,222,223,224) ELSE 0 END) THEN 1 ELSE 0 END,s.env FROM s JOIN node n ON n.file=d.file AND n.id=s.node) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=2)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=5)), i AS MATERIALIZED (SELECT s.*,i.a,(SELECT child FROM constant0_7 WHERE pc=s.pc AND ordinal=0) AS child FROM s JOIN constant0_6 i ON i.pc=s.pc) SELECT s.node,COALESCE(s.child,0),s.level,s.work,COALESCE(frame.handle,s.handle),CASE WHEN s.child IS NULL THEN s.a ELSE 0 END,s.env FROM i s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (CASE WHEN s.a=1 THEN 2 ELSE 3 END) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (0) AND frame.v5 IS (0) AND frame.v6 IS (s.env)) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=5)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=6)) SELECT s.node,i.a,s.level,s.work,frame.handle,0,s.env FROM s JOIN constant0_6 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN 1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (4) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.env)) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=6)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH reached AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=7)),s AS MATERIALIZED (SELECT s.*,n."last" AS bound,CASE s.pc WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (candidate.kind IN (228)) ORDER BY candidate.id LIMIT 1) WHEN 16 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 24 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 30 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 33 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 41 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.id>s.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END AS child FROM reached s JOIN node n ON n.file=d.file AND n.id=s.node) SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN 0 ELSE -2 END,s.level,s.work,COALESCE(frame.handle,s.handle),0,s.env FROM s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (1) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (s.child) AND frame.v5 IS (s.bound) AND frame.v6 IS (0) AND frame.v7 IS (s.env)) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_6 WHERE op=7)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=-2) SELECT s.node,CASE WHEN (CASE p.c3 WHEN 8 THEN 1 WHEN 10 THEN 1 WHEN 16 THEN 1 WHEN 24 THEN 1 WHEN 30 THEN 1 WHEN 33 THEN 1 WHEN 41 THEN n.kind IN (1,197,221,222,223,224) ELSE 1 END) THEN i.a ELSE 0 END,s.level,s.work,s.handle,0,s.env FROM s CROSS JOIN relation_continuation p ON p.mode IS 0 AND p.h IS s.handle JOIN constant0_6 i ON i.pc=p.c3 JOIN node n ON n.file=d.file AND n.id=s.node) WHERE mixed_entry_4000000.pc=-2
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH reached AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=0),
popped AS MATERIALIZED (SELECT s.*,frame.parent,frame.c0,frame.c1,frame.c2,frame.c3,frame.c4,frame.c5,frame.c6,frame.c7 FROM reached s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.handle IS NOT NULL THEN 2 END AND frame.h IS s.handle),
closed AS MATERIALIZED (SELECT p.*,CASE WHEN p.c0=0 THEN relation_peak_close(p.c6) END AS measured FROM popped p),
published AS MATERIALIZED (SELECT p.*,COALESCE(m.truth,p.truth) AS returned FROM closed p LEFT JOIN constant0_8 f ON p.c0=0 AND f.id=p.c3 LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND p.c0=0 AND p.truth>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS f.memo AND m.file IS d.file AND m.node IS p.c1 AND m.k0 IS CASE f.id WHEN 0 THEN relation_state_get(p.c7,0) WHEN 1 THEN relation_state_get(p.c7,0) WHEN 2 THEN relation_state_get(p.c7,0) ELSE NULL END AND m.v0 IS CASE WHEN p.truth=1 THEN CASE f.id WHEN 0 THEN relation_state_get(p.env,0) WHEN 1 THEN relation_state_get(p.env,0) WHEN 2 THEN relation_state_get(p.env,0) ELSE NULL END END AND m.vtruth IS p.truth AND m.vcost IS CASE WHEN p.c0=0 AND p.truth>=0 THEN MAX(0,p.c4-p.work-relation_cache_fill_delta(p.c5)) END AND m.vpeak IS p.measured WHERE COALESCE(p.measured,0)>=0),
classified AS MATERIALIZED (SELECT p.*,CASE WHEN p.c0 IN (2,3) AND p.truth>=0 AND NOT ((p.c0=2 AND p.truth=0) OR (p.c0=3 AND p.truth=1)) THEN (SELECT child FROM constant0_7 WHERE pc=p.c3 AND ordinal=p.c4+1) END AS child,CASE WHEN p.c0=1 AND p.truth IN (0,2) THEN CASE p.c3 WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (candidate.kind IN (228)) ORDER BY candidate.id LIMIT 1) WHEN 16 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 24 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 30 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 33 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 41 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.id>CASE WHEN (n.kind IN (197,221,222,223,224)) THEN n."last" ELSE p.c4 END AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END END AS candidate FROM published p LEFT JOIN node n ON p.c0=1 AND n.file=d.file AND n.id=p.c4)
SELECT CASE WHEN p.handle IS NULL THEN p.node WHEN p.c0=1 AND search_again.handle IS NOT NULL THEN p.candidate ELSE p.c1 END,
CASE WHEN p.handle IS NULL THEN -1 WHEN bool_again.handle IS NOT NULL THEN p.child WHEN search_again.handle IS NOT NULL THEN -2 ELSE 0 END,
CASE WHEN p.handle IS NULL THEN p.level ELSE p.c2 END,p.work,
COALESCE(bool_again.handle,search_again.handle,p.parent),
CASE WHEN p.handle IS NULL THEN p.truth WHEN p.c0=0 THEN p.returned WHEN p.c0=4 THEN CASE p.truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE p.truth END
WHEN bool_again.handle IS NOT NULL OR search_again.handle IS NOT NULL THEN 0 WHEN p.truth<0 THEN p.truth
WHEN p.c0=2 AND p.truth=0 THEN 0 WHEN p.c0=3 AND p.truth=1 THEN 1
WHEN p.c0 IN (2,3) THEN CASE WHEN p.c5 OR p.truth=2 THEN 2 WHEN p.c0=2 THEN 1 ELSE 0 END
WHEN p.c0=1 THEN CASE WHEN p.truth=1 THEN 1 WHEN p.c6 OR p.truth=2 THEN 2 ELSE 0 END END,
CASE WHEN p.handle IS NULL THEN p.env
WHEN p.c0=0 THEN CASE WHEN p.truth=1 THEN p.env ELSE p.c7 END
WHEN p.c0=4 THEN p.c3
WHEN p.c0 IN (2,3) THEN CASE WHEN bool_again.handle IS NOT NULL AND p.c0=2 THEN p.env WHEN bool_again.handle IS NOT NULL OR p.truth<>1 THEN p.c6 ELSE p.env END
WHEN p.c0=1 THEN CASE WHEN search_again.handle IS NOT NULL OR p.truth<>1 THEN p.c7 ELSE p.env END END
FROM classified p LEFT JOIN relation_continuation bool_again ON bool_again.mode IS CASE WHEN p.c0 IN (2,3) AND p.truth>=0 AND NOT ((p.c0=2 AND p.truth=0) OR (p.c0=3 AND p.truth=1)) AND p.child IS NOT NULL THEN 1 END AND bool_again.parent_input IS p.parent AND bool_again.v0 IS (p.c0) AND bool_again.v1 IS (p.c1) AND bool_again.v2 IS (p.c2) AND bool_again.v3 IS (p.c3) AND bool_again.v4 IS (p.c4+1) AND bool_again.v5 IS (p.c5 OR p.truth=2) AND bool_again.v6 IS (p.c6) LEFT JOIN relation_continuation search_again ON search_again.mode IS CASE WHEN p.c0=1 AND p.truth IN (0,2) AND p.candidate IS NOT NULL THEN 1 END AND search_again.parent_input IS p.parent AND search_again.v0 IS (1) AND search_again.v1 IS (p.c1) AND search_again.v2 IS (p.c2) AND search_again.v3 IS (p.c3) AND search_again.v4 IS (p.candidate) AND search_again.v5 IS (p.c5) AND search_again.v6 IS (p.c6 OR p.truth=2) AND search_again.v7 IS (p.c7)) WHERE mixed_entry_4000000.pc=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=2) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(d.state_scope,s.env,0,r.c2) ELSE s.env END FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,mixed_entry_4000000.node AS node,mixed_entry_4000000.work AS work,relation_state_get(mixed_entry_4000000.env,0) AS c0 WHERE mixed_entry_4000000.pc=2
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((mixed_entry_4000000.level)+0) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((mixed_entry_4000000.level)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (1)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.next LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.prev WHERE NOT (((COALESCE(bound0.kind IN (215),0) AND CASE WHEN bound1.id IS NOT NULL THEN node_regex(1,bound1.file,bound1.id) ELSE 0 END) OR CASE WHEN bound2.id IS NOT NULL THEN node_regex(0,bound2.file,bound2.id) ELSE 0 END))))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 FROM outcome1 o)) WHERE mixed_entry_4000000.pc=2
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=36) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(d.state_scope,s.env,0,r.c2) ELSE s.env END FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,mixed_entry_4000000.node AS node,mixed_entry_4000000.work AS work,relation_state_get(mixed_entry_4000000.env,0) AS c0 WHERE mixed_entry_4000000.pc=36
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((mixed_entry_4000000.level)+0) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((mixed_entry_4000000.level)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (1)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.next LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.prev WHERE NOT (((COALESCE(bound0.kind IN (215),0) AND CASE WHEN bound1.id IS NOT NULL THEN node_regex(1,bound1.file,bound1.id) ELSE 0 END) OR CASE WHEN bound2.id IS NOT NULL THEN node_regex(0,bound2.file,bound2.id) ELSE 0 END))))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 FROM outcome1 o)) WHERE mixed_entry_4000000.pc=36) SELECT truth,work,relation_state_get(env,0) FROM schedule WHERE pc=-1) WHERE relation_state_end(CASE WHEN r.c0 IS NOT NULL THEN d.state_scope END)=1
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome2 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.next END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN w.stopped=0 THEN n.next END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN w.stopped=0 THEN n.next END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)) WHERE recursive_entry_0.phase=10
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=11),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (s.cursor=0 AND child.id=n.parent) AND ((1) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=child.file AND bound0.id=child.parent LEFT JOIN node bound1 ON bound1.file=child.file AND bound1.id=child.prev WHERE NOT ((COALESCE(bound0.kind IN (137),0) AND CASE WHEN bound1.id IS NOT NULL THEN node_regex(2,bound1.file,bound1.id) ELSE 0 END))))) AND (1) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 3 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0,NULL
FROM s  LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS 1 AND p.v7 IS 11) WHERE recursive_entry_0.phase=11) SELECT truth,work,c0 FROM schedule WHERE phase=5)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (197)) ORDER BY candidate.id LIMIT 1) AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE ((SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (197)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((recursive_entry_1.level+1)+0) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((recursive_entry_1.level+1)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((recursive_entry_1.level+1)+1) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((recursive_entry_1.level+1)+1)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (197) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (147)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (147) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1,182)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (182) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (1)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(1,bound0.file,bound0.id) ELSE 0 END))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c0 AS c0 FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome10 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth,r.c2 AS c0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,((recursive_entry_1.level+1)+1) AS level,0 AS phase,NULL AS parent,d.work AS work,d.work AS start,0 AS fill,NULL AS token,0 AS truth,0 AS uncertain,0 AS cursor,NULL AS c0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=0),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak,m.o0 AS e0 FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS 2000000 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS opened_token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.opened_token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,s.level,CASE WHEN s.hit IS NOT NULL THEN 4 WHEN s.level>=256 OR s.work=0 THEN 3 ELSE 10 END,s.parent,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
s.work,relation_cache_fill_steps(),s.opened_token,
CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,0,0,s.e0 FROM noted s WHERE s.ready=1) WHERE recursive_entry_0.phase=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=3),
s AS MATERIALIZED (SELECT s.*,CASE WHEN s.token IS NOT NULL THEN relation_peak_close(s.token) END AS measured FROM reached s)
SELECT s.node,s.level,4,s.parent,s.work,s.start,s.fill,NULL,COALESCE(m.truth,s.truth),s.uncertain,s.cursor,s.c0 FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND s.truth>=0 AND s.token IS NOT NULL THEN 1 END AND m.clause IS 0 AND m.utility IS 2000000 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.vtruth IS s.truth AND m.vcost IS MAX(0,s.start-s.work-relation_cache_fill_delta(s.fill)) AND m.vpeak IS s.measured AND m.v0 IS CASE WHEN s.truth=1 THEN s.c0 END WHERE COALESCE(s.measured,0)>=0) WHERE recursive_entry_0.phase=3
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=4)
SELECT COALESCE(p.c0,s.node),COALESCE(p.c1,s.level),CASE WHEN s.parent IS NULL THEN 5 WHEN s.truth=0 THEN p.c7 ELSE 3 END,p.parent,s.work,p.c2,p.c3,p.c4,s.truth,COALESCE(p.c5,0) OR s.truth=2,p.c6,s.c0
FROM s LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.parent IS NOT NULL THEN 2 END AND p.h IS s.parent) WHERE recursive_entry_0.phase=4
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=10) SELECT s.node,s.level,CASE WHEN r.c0=0 THEN 11 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0,r.c2 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,recursive_entry_0.node AS node,recursive_entry_0.work AS work,d.c0 AS c0 WHERE recursive_entry_0.phase=10
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.next AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.next) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.*,relation_state_begin() AS state_scope FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth,r.c2 AS c0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,42 AS pc,((recursive_entry_0.level+1)+0) AS level,d.work AS work,NULL AS handle,0 AS truth,relation_state_put_owned(d.state_scope,0,0,d.c0) AS env
UNION ALL
SELECT mixed_entry_4000000.node,0,mixed_entry_4000000.level,mixed_entry_4000000.work,mixed_entry_4000000.handle,mixed_entry_4000000.truth,mixed_entry_4000000.env FROM schedule mixed_entry_4000000 WHERE mixed_entry_4000000.pc=1
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH reached AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=4)),
s AS MATERIALIZED (SELECT reached.*,f.id AS function,f.entry FROM reached JOIN constant0_9 i ON i.pc=reached.pc JOIN constant0_11 f ON f.id=i.a),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak,m.o0 AS o0 FROM s JOIN constant0_11 f ON f.id=s.function LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS f.memo AND m.file IS d.file AND m.node IS s.node AND m.k0 IS CASE f.id WHEN 0 THEN relation_state_get(s.env,0) WHEN 1 THEN relation_state_get(s.env,0) WHEN 2 THEN relation_state_get(s.env,0) ELSE NULL END AND m.peak<=256-s.level),
replay0 AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL AND s.o0 IS NOT NULL THEN relation_state_put(d.state_scope,s.env,0,s.o0) ELSE s.env END AS replay_env0 FROM lookup s),
opened AS MATERIALIZED (SELECT s.*,s.replay_env0 AS recalled_env,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS token FROM replay0 s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,CASE WHEN s.hit IS NOT NULL OR s.level>=256 THEN 0 WHEN s.work=0 THEN 1 ELSE s.entry END,
CASE WHEN s.hit IS NULL AND s.level<256 THEN s.level+1 ELSE s.level END,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
COALESCE(frame.handle,s.handle),CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,CASE WHEN s.hit IS NOT NULL THEN s.recalled_env ELSE s.env END
FROM noted s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.hit IS NULL AND s.level<256 AND s.ready=1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (0) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.function) AND frame.v4 IS (s.work) AND frame.v5 IS (relation_cache_fill_steps()) AND frame.v6 IS (s.token) AND frame.v7 IS (s.env) WHERE s.ready=1) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=4)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=2)) SELECT s.node,0,s.level,s.work,s.handle,CASE WHEN (CASE s.pc WHEN 3 THEN n.kind IN (221,222,223,224) WHEN 4 THEN n.kind IN (228) WHEN 6 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(2,bound0.file,bound0.id) ELSE 0 END) WHEN 12 THEN n.kind IN (197) WHEN 14 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(3,bound0.file,bound0.id) ELSE 0 END) WHEN 18 THEN NOT (n.kind IN (197,221,222,223,224)) WHEN 22 THEN n.kind IN (226) WHEN 26 THEN NOT (n.kind IN (226)) WHEN 28 THEN n.kind IN (228,229) WHEN 37 THEN n.kind IN (197,221,222,223,224) ELSE 0 END) THEN 1 ELSE 0 END,s.env FROM s JOIN node n ON n.file=d.file AND n.id=s.node) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=2)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=5)), i AS MATERIALIZED (SELECT s.*,i.a,(SELECT child FROM constant0_10 WHERE pc=s.pc AND ordinal=0) AS child FROM s JOIN constant0_9 i ON i.pc=s.pc) SELECT s.node,COALESCE(s.child,0),s.level,s.work,COALESCE(frame.handle,s.handle),CASE WHEN s.child IS NULL THEN s.a ELSE 0 END,s.env FROM i s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (CASE WHEN s.a=1 THEN 2 ELSE 3 END) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (0) AND frame.v5 IS (0) AND frame.v6 IS (s.env)) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=5)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=6)) SELECT s.node,i.a,s.level,s.work,frame.handle,0,s.env FROM s JOIN constant0_9 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN 1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (4) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.env)) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=6)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH reached AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=7)),s AS MATERIALIZED (SELECT s.*,n."last" AS bound,CASE s.pc WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (candidate.kind IN (228)) ORDER BY candidate.id LIMIT 1) WHEN 16 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 24 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 30 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 33 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=s.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 41 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.id>s.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END AS child FROM reached s JOIN node n ON n.file=d.file AND n.id=s.node) SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN 0 ELSE -2 END,s.level,s.work,COALESCE(frame.handle,s.handle),0,s.env FROM s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (1) AND frame.v1 IS (s.node) AND frame.v2 IS (s.level) AND frame.v3 IS (s.pc) AND frame.v4 IS (s.child) AND frame.v5 IS (s.bound) AND frame.v6 IS (0) AND frame.v7 IS (s.env)) WHERE mixed_entry_4000000.pc IN (SELECT pc FROM constant0_9 WHERE op=7)
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=-2) SELECT s.node,CASE WHEN (CASE p.c3 WHEN 8 THEN 1 WHEN 10 THEN 1 WHEN 16 THEN 1 WHEN 24 THEN 1 WHEN 30 THEN 1 WHEN 33 THEN 1 WHEN 41 THEN n.kind IN (1,197,221,222,223,224) ELSE 1 END) THEN i.a ELSE 0 END,s.level,s.work,s.handle,0,s.env FROM s CROSS JOIN relation_continuation p ON p.mode IS 0 AND p.h IS s.handle JOIN constant0_9 i ON i.pc=p.c3 JOIN node n ON n.file=d.file AND n.id=s.node) WHERE mixed_entry_4000000.pc=-2
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH reached AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=0),
popped AS MATERIALIZED (SELECT s.*,frame.parent,frame.c0,frame.c1,frame.c2,frame.c3,frame.c4,frame.c5,frame.c6,frame.c7 FROM reached s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.handle IS NOT NULL THEN 2 END AND frame.h IS s.handle),
closed AS MATERIALIZED (SELECT p.*,CASE WHEN p.c0=0 THEN relation_peak_close(p.c6) END AS measured FROM popped p),
published AS MATERIALIZED (SELECT p.*,COALESCE(m.truth,p.truth) AS returned FROM closed p LEFT JOIN constant0_11 f ON p.c0=0 AND f.id=p.c3 LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND p.c0=0 AND p.truth>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS f.memo AND m.file IS d.file AND m.node IS p.c1 AND m.k0 IS CASE f.id WHEN 0 THEN relation_state_get(p.c7,0) WHEN 1 THEN relation_state_get(p.c7,0) WHEN 2 THEN relation_state_get(p.c7,0) ELSE NULL END AND m.v0 IS CASE WHEN p.truth=1 THEN CASE f.id WHEN 0 THEN relation_state_get(p.env,0) WHEN 1 THEN relation_state_get(p.env,0) WHEN 2 THEN relation_state_get(p.env,0) ELSE NULL END END AND m.vtruth IS p.truth AND m.vcost IS CASE WHEN p.c0=0 AND p.truth>=0 THEN MAX(0,p.c4-p.work-relation_cache_fill_delta(p.c5)) END AND m.vpeak IS p.measured WHERE COALESCE(p.measured,0)>=0),
classified AS MATERIALIZED (SELECT p.*,CASE WHEN p.c0 IN (2,3) AND p.truth>=0 AND NOT ((p.c0=2 AND p.truth=0) OR (p.c0=3 AND p.truth=1)) THEN (SELECT child FROM constant0_10 WHERE pc=p.c3 AND ordinal=p.c4+1) END AS child,CASE WHEN p.c0=1 AND p.truth IN (0,2) THEN CASE p.c3 WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (candidate.kind IN (228)) ORDER BY candidate.id LIMIT 1) WHEN 16 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 24 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 30 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 33 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.parent=p.c1 AND candidate.id>n."last" AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 41 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=d.file AND (candidate.id>CASE WHEN (n.kind IN (197,221,222,223,224)) THEN n."last" ELSE p.c4 END AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END END AS candidate FROM published p LEFT JOIN node n ON p.c0=1 AND n.file=d.file AND n.id=p.c4)
SELECT CASE WHEN p.handle IS NULL THEN p.node WHEN p.c0=1 AND search_again.handle IS NOT NULL THEN p.candidate ELSE p.c1 END,
CASE WHEN p.handle IS NULL THEN -1 WHEN bool_again.handle IS NOT NULL THEN p.child WHEN search_again.handle IS NOT NULL THEN -2 ELSE 0 END,
CASE WHEN p.handle IS NULL THEN p.level ELSE p.c2 END,p.work,
COALESCE(bool_again.handle,search_again.handle,p.parent),
CASE WHEN p.handle IS NULL THEN p.truth WHEN p.c0=0 THEN p.returned WHEN p.c0=4 THEN CASE p.truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE p.truth END
WHEN bool_again.handle IS NOT NULL OR search_again.handle IS NOT NULL THEN 0 WHEN p.truth<0 THEN p.truth
WHEN p.c0=2 AND p.truth=0 THEN 0 WHEN p.c0=3 AND p.truth=1 THEN 1
WHEN p.c0 IN (2,3) THEN CASE WHEN p.c5 OR p.truth=2 THEN 2 WHEN p.c0=2 THEN 1 ELSE 0 END
WHEN p.c0=1 THEN CASE WHEN p.truth=1 THEN 1 WHEN p.c6 OR p.truth=2 THEN 2 ELSE 0 END END,
CASE WHEN p.handle IS NULL THEN p.env
WHEN p.c0=0 THEN CASE WHEN p.truth=1 THEN p.env ELSE p.c7 END
WHEN p.c0=4 THEN p.c3
WHEN p.c0 IN (2,3) THEN CASE WHEN bool_again.handle IS NOT NULL AND p.c0=2 THEN p.env WHEN bool_again.handle IS NOT NULL OR p.truth<>1 THEN p.c6 ELSE p.env END
WHEN p.c0=1 THEN CASE WHEN search_again.handle IS NOT NULL OR p.truth<>1 THEN p.c7 ELSE p.env END END
FROM classified p LEFT JOIN relation_continuation bool_again ON bool_again.mode IS CASE WHEN p.c0 IN (2,3) AND p.truth>=0 AND NOT ((p.c0=2 AND p.truth=0) OR (p.c0=3 AND p.truth=1)) AND p.child IS NOT NULL THEN 1 END AND bool_again.parent_input IS p.parent AND bool_again.v0 IS (p.c0) AND bool_again.v1 IS (p.c1) AND bool_again.v2 IS (p.c2) AND bool_again.v3 IS (p.c3) AND bool_again.v4 IS (p.c4+1) AND bool_again.v5 IS (p.c5 OR p.truth=2) AND bool_again.v6 IS (p.c6) LEFT JOIN relation_continuation search_again ON search_again.mode IS CASE WHEN p.c0=1 AND p.truth IN (0,2) AND p.candidate IS NOT NULL THEN 1 END AND search_again.parent_input IS p.parent AND search_again.v0 IS (1) AND search_again.v1 IS (p.c1) AND search_again.v2 IS (p.c2) AND search_again.v3 IS (p.c3) AND search_again.v4 IS (p.candidate) AND search_again.v5 IS (p.c5) AND search_again.v6 IS (p.c6 OR p.truth=2) AND search_again.v7 IS (p.c7)) WHERE mixed_entry_4000000.pc=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=2) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(d.state_scope,s.env,0,r.c2) ELSE s.env END FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,mixed_entry_4000000.node AS node,mixed_entry_4000000.work AS work,relation_state_get(mixed_entry_4000000.env,0) AS c0 WHERE mixed_entry_4000000.pc=2
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((mixed_entry_4000000.level)+0) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((mixed_entry_4000000.level)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (1)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.next LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.prev WHERE NOT (((COALESCE(bound0.kind IN (215),0) AND CASE WHEN bound1.id IS NOT NULL THEN node_regex(1,bound1.file,bound1.id) ELSE 0 END) OR CASE WHEN bound2.id IS NOT NULL THEN node_regex(0,bound2.file,bound2.id) ELSE 0 END))))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 FROM outcome1 o)) WHERE mixed_entry_4000000.pc=2
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6 FROM schedule mixed_entry_4000000 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6) IS (WITH s AS MATERIALIZED (SELECT mixed_entry_4000000.node AS node,mixed_entry_4000000.pc AS pc,mixed_entry_4000000.level AS level,mixed_entry_4000000.work AS work,mixed_entry_4000000.handle AS handle,mixed_entry_4000000.truth AS truth,mixed_entry_4000000.env AS env WHERE mixed_entry_4000000.pc=36) SELECT s.node,0,s.level,r.c1,s.handle,r.c0,CASE WHEN r.c0=1 THEN relation_state_put(d.state_scope,s.env,0,r.c2) ELSE s.env END FROM s CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,mixed_entry_4000000.node AS node,mixed_entry_4000000.work AS work,relation_state_get(mixed_entry_4000000.env,0) AS c0 WHERE mixed_entry_4000000.pc=36
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((mixed_entry_4000000.level)+0) AS incoming,m.truth AS hit,m.cost,m.peak,m.o0 AS hit0 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.peak<=256-((mixed_entry_4000000.level)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (1)) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.parent LEFT JOIN node bound1 ON bound1.file=n.file AND bound1.id=n.next LEFT JOIN node bound2 ON bound2.file=n.file AND bound2.id=n.prev WHERE NOT (((COALESCE(bound0.kind IN (215),0) AND CASE WHEN bound1.id IS NOT NULL THEN node_regex(1,bound1.file,bound1.id) ELSE 0 END) OR CASE WHEN bound2.id IS NOT NULL THEN node_regex(0,bound2.file,bound2.id) ELSE 0 END))))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 FROM outcome1 o)) WHERE mixed_entry_4000000.pc=36) SELECT truth,work,relation_state_get(env,0) FROM schedule WHERE pc=-1) WHERE relation_state_end(CASE WHEN r.c0 IS NOT NULL THEN d.state_scope END)=1
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome2 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.next END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN w.stopped=0 THEN n.next END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN w.stopped=0 THEN n.next END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)) WHERE recursive_entry_0.phase=10
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor,recursive_entry_0.c0 AS c0 WHERE recursive_entry_0.phase=11),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (s.cursor=0 AND child.id=n.parent) AND ((1) AND (EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=child.file AND bound0.id=child.parent LEFT JOIN node bound1 ON bound1.file=child.file AND bound1.id=child.prev WHERE NOT ((COALESCE(bound0.kind IN (137),0) AND CASE WHEN bound1.id IS NOT NULL THEN node_regex(2,bound1.file,bound1.id) ELSE 0 END))))) AND (1) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 3 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0,NULL
FROM s  LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS 1 AND p.v7 IS 11) WHERE recursive_entry_0.phase=11) SELECT truth,work,c0 FROM schedule WHERE phase=5)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS d.c0 AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (197)) ORDER BY candidate.id LIMIT 1),w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (197)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (197)) ORDER BY candidate.id LIMIT 1)) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c0 AS c0 FROM outcome6 s
),
outcome8 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome7
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(2,bound0.file,bound0.id) ELSE 0 END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome5 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome8 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,NULL,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (NULL) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (NULL) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.next WHERE CASE WHEN bound0.id IS NOT NULL THEN node_regex(2,bound0.file,bound0.id) ELSE 0 END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)) WHERE recursive_entry_1.phase=10
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11 FROM schedule recursive_entry_1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_1.node AS node,recursive_entry_1.level AS level,recursive_entry_1.phase AS phase,recursive_entry_1.parent AS parent,recursive_entry_1.work AS work,recursive_entry_1.start AS start,recursive_entry_1.fill AS fill,recursive_entry_1.token AS token,recursive_entry_1.truth AS truth,recursive_entry_1.uncertain AS uncertain,recursive_entry_1.cursor AS cursor,recursive_entry_1.c0 AS c0 WHERE recursive_entry_1.phase=11),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (s.cursor=0 AND child.id=n.parent) AND (1) AND (1) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 3 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0,NULL
FROM s  LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS 1 AND p.v7 IS 11) WHERE recursive_entry_1.phase=11) SELECT truth,work,c0 FROM schedule WHERE phase=5)
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o)) WHERE machine.pc=15 UNION ALL SELECT * FROM (SELECT machine.node,0,machine.level,machine.work,machine.handle,CASE WHEN machine.pc IN (10) THEN CASE WHEN n.kind IN (137) THEN 1 ELSE 0 END WHEN machine.pc IN (12) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END WHEN machine.pc IN (14) THEN CASE WHEN EXISTS (SELECT 1 FROM (SELECT 1) AS bound_unit LEFT JOIN node bound0 ON bound0.file=n.file AND bound0.id=n.prev WHERE NOT (CASE WHEN bound0.id IS NOT NULL THEN node_regex(0,bound0.file,bound0.id) ELSE 0 END)) THEN 1 ELSE 0 END END,machine.env,machine.scope FROM node n  WHERE (machine.pc IN (10,12,14)) AND n.file=d.file AND n.id=machine.node) WHERE machine.pc IN (10,12,14)) WHERE machine.pc<>-1 AND r.c0 IS NOT NULL),returned AS MATERIALIZED (SELECT scope,truth,work,relation_state_get(env,0) c0 FROM schedule WHERE pc=-1),closed AS MATERIALIZED (SELECT returned.*,relation_state_end(scope) ready FROM returned) SELECT truth,work,c0 FROM closed WHERE ready=1)
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome1 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 pc,column2 op,column3 a,column4 ml,column5 mh,column6 wl,column7 wh,column8 strict FROM (VALUES (10,1,0,0,0,0,0,0),(11,6,0,0,0,0,0,0),(12,1,1,0,0,0,0,0),(13,1,2,1,0,1,0,1),(14,1,3,0,0,0,0,0),(15,1,4,1,0,1,0,1),(16,3,0,1,0,1,0,1))),
constant0_1 AS MATERIALIZED (SELECT column1 pc,column2 ordinal,column3 child FROM (VALUES (16,0,11),(16,1,12),(16,2,13),(16,3,14),(16,4,15))),
constant0_2 AS MATERIALIZED (SELECT NULL id,NULL entry,NULL memo,NULL fills WHERE 0),
constant0_3 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a FROM (VALUES (0,0,0),(1,1,0),(2,3,0),(3,2,0),(4,2,0),(5,4,0),(6,2,0),(7,5,1),(8,7,7),(9,5,1),(10,7,9),(11,5,1),(12,2,0),(13,4,1),(14,2,0),(15,5,1),(16,7,15),(17,5,1),(18,2,0),(19,4,2),(20,5,1),(21,5,0),(22,2,0),(23,4,1),(24,7,23),(25,5,1),(26,2,0),(27,4,0),(28,2,0),(29,4,0),(30,7,29),(31,5,1),(32,5,0),(33,7,32),(34,5,1),(35,5,0),(36,3,1),(37,2,0),(38,4,0),(39,5,1),(40,5,0),(41,7,40),(42,4,0))),
constant0_4 AS MATERIALIZED (SELECT column1 AS pc,column2 AS ordinal,column3 AS child FROM (VALUES (7,0,5),(7,1,6),(9,0,4),(9,1,8),(11,0,3),(11,1,10),(15,0,13),(15,1,14),(17,0,12),(17,1,16),(20,0,18),(20,1,19),(21,0,2),(21,1,11),(21,2,17),(21,3,20),(25,0,22),(25,1,24),(31,0,28),(31,1,30),(32,0,27),(32,1,31),(34,0,26),(34,1,33),(35,0,25),(35,1,34),(39,0,37),(39,1,38),(40,0,36),(40,1,39))),
constant0_5 AS MATERIALIZED (SELECT column1 AS id,column2 AS entry,column3 AS memo FROM (VALUES (0,21,4000000),(1,35,4000001),(2,41,4000002))),
constant0_6 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a FROM (VALUES (0,0,0),(1,1,0),(2,3,0),(3,2,0),(4,2,0),(5,4,0),(6,2,0),(7,5,1),(8,7,7),(9,5,1),(10,7,9),(11,5,1),(12,2,0),(13,4,1),(14,2,0),(15,5,1),(16,7,15),(17,5,1),(18,2,0),(19,4,2),(20,5,1),(21,5,0),(22,2,0),(23,4,1),(24,7,23),(25,5,1),(26,2,0),(27,4,0),(28,2,0),(29,4,0),(30,7,29),(31,5,1),(32,5,0),(33,7,32),(34,5,1),(35,5,0),(36,3,1),(37,2,0),(38,4,0),(39,5,1),(40,5,0),(41,7,40),(42,4,0))),
constant0_7 AS MATERIALIZED (SELECT column1 AS pc,column2 AS ordinal,column3 AS child FROM (VALUES (7,0,5),(7,1,6),(9,0,4),(9,1,8),(11,0,3),(11,1,10),(15,0,13),(15,1,14),(17,0,12),(17,1,16),(20,0,18),(20,1,19),(21,0,2),(21,1,11),(21,2,17),(21,3,20),(25,0,22),(25,1,24),(31,0,28),(31,1,30),(32,0,27),(32,1,31),(34,0,26),(34,1,33),(35,0,25),(35,1,34),(39,0,37),(39,1,38),(40,0,36),(40,1,39))),
constant0_8 AS MATERIALIZED (SELECT column1 AS id,column2 AS entry,column3 AS memo FROM (VALUES (0,21,4000000),(1,35,4000001),(2,41,4000002))),
constant0_9 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a FROM (VALUES (0,0,0),(1,1,0),(2,3,0),(3,2,0),(4,2,0),(5,4,0),(6,2,0),(7,5,1),(8,7,7),(9,5,1),(10,7,9),(11,5,1),(12,2,0),(13,4,1),(14,2,0),(15,5,1),(16,7,15),(17,5,1),(18,2,0),(19,4,2),(20,5,1),(21,5,0),(22,2,0),(23,4,1),(24,7,23),(25,5,1),(26,2,0),(27,4,0),(28,2,0),(29,4,0),(30,7,29),(31,5,1),(32,5,0),(33,7,32),(34,5,1),(35,5,0),(36,3,1),(37,2,0),(38,4,0),(39,5,1),(40,5,0),(41,7,40),(42,4,0))),
constant0_10 AS MATERIALIZED (SELECT column1 AS pc,column2 AS ordinal,column3 AS child FROM (VALUES (7,0,5),(7,1,6),(9,0,4),(9,1,8),(11,0,3),(11,1,10),(15,0,13),(15,1,14),(17,0,12),(17,1,16),(20,0,18),(20,1,19),(21,0,2),(21,1,11),(21,2,17),(21,3,20),(25,0,22),(25,1,24),(31,0,28),(31,1,30),(32,0,27),(32,1,31),(34,0,26),(34,1,33),(35,0,25),(35,1,34),(39,0,37),(39,1,38),(40,0,36),(40,1,39))),
constant0_11 AS MATERIALIZED (SELECT column1 AS id,column2 AS entry,column3 AS memo FROM (VALUES (0,21,4000000),(1,35,4000001),(2,41,4000002))),
outcome15 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c0 AS v0 FROM outcome2 o WHERE o.truth=1 OR o.truth<0
),
outcome16 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome15 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(m.v0) END AS payload,0 AS failure,m.work FROM outcome15 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome16 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome16
ORDER BY 1,2,3