WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n WHERE 1 AND n.kind IN (191)
),
outcome1 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0,NULL AS c1,NULL AS c2 FROM outcome0 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2,r.c3,r.c4 FROM outcome1 w CROSS JOIN outcome0 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,NULL AS c1,NULL AS c2,0 AS u0,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.u0,d.u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0 AND (n.kind IN (191))
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,NULL,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (NULL) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (NULL) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id>origin.id AND n.id<=origin."last" WHERE n.kind IN (99)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (99) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome6 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,v.work,v.truth FROM outcome1 d CROSS JOIN relation_value_budget(1,d.file,d.node,d.work) v
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,v.truth AS tested,v.work AS remaining FROM outcome3 d LEFT JOIN relation_value_budget(2,d.file,d.node,CASE WHEN d.truth>0 AND NOT (0) THEN d.work END) v ON 1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome8 s
),
outcome10 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome9
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.u0,d.u1,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.u0,d.u1,d.u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0,r.c3 AS e1,r.c4 AS e2 FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u0 OR d.u1 OR d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0,NULL AS v1,NULL AS v2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2,r.c3,r.c4 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 WHERE w.stopped>=0 AND (n.kind IN (196,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,0 AS u0,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,d.c1 AS c1,d.c2 AS c2,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0,d.u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,r.c0 AS tree,COALESCE(r.c1,1) AS rank,COALESCE(r.c2,1) AS finish,COALESCE(r.c3,0) AS origin,(0) AS incoming FROM outcome0 d CROSS JOIN node probe ON probe.file=d.file AND probe.id=d.node CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT tree,rank,finish,depth FROM semantic0_0_summary WHERE file=d.file AND node=d.node AND d.work>0 AND (0)<256 AND (probe.kind IN (226)))
),
outcome2 AS MATERIALIZED (
SELECT s.k,s.file,s.node,s.tree,s.rank,s.finish,s.origin,s.incoming,s.incoming AS level,0 AS phase,0 AS own,0 AS uncertain,s.work,NULL AS c1 FROM outcome1 s
UNION ALL
SELECT semantic_entry0_0.k,semantic_entry0_0.file,semantic_entry0_0.node,semantic_entry0_0.tree,semantic_entry0_0.rank,semantic_entry0_0.finish,semantic_entry0_0.origin,semantic_entry0_0.incoming,semantic_entry0_0.level,1,CASE WHEN semantic_entry0_0.level>=256 THEN -1 WHEN semantic_entry0_0.work=0 THEN -2 ELSE r.c0 END,semantic_entry0_0.uncertain,COALESCE(r.c1,semantic_entry0_0.work),r.c2
FROM outcome2 semantic_entry0_0 JOIN outcome0 d ON d.k=semantic_entry0_0.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,semantic_entry0_0.file AS file,semantic_entry0_0.node AS node,semantic_entry0_0.work-1 AS work,d.c1 AS c1 WHERE semantic_entry0_0.work>0 AND semantic_entry0_0.level<256
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c1 AS c1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN n.named AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome6 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(3,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome8 s
),
outcome10 AS (
SELECT d.parent,o.truth,o.c1 AS c1,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome9 o ON o.k=d.k WHERE o.truth<>0
),
outcome11 AS MATERIALIZED (
SELECT * FROM outcome10 WHERE choice=1
),
outcome12 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c1 ELSE d.c1 END AS c1 FROM outcome0 d LEFT JOIN outcome11 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome12 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(3,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, CASE WHEN w.stopped<0 THEN 0 WHEN w.work=0 THEN -2 ELSE COALESCE(r.c0,0) END,w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe."end">probe.start THEN 1 ELSE 0 END,w.work-1 FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0 AND w.work>0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>3)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>3)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<0) OR COALESCE(t.low,0)>3 THEN 0 WHEN COALESCE(t.low,0)>=0 AND (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<=3) AND (1) THEN 1 ELSE 2 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome8 o) WHERE semantic_entry0_0.phase=0
UNION ALL
SELECT w.k,w.file,n.node,w.tree,n.rank,w.finish,w.origin,w.incoming,w.incoming+n.depth-w.origin,0,0,w.uncertain OR w.own=2,w.work,NULL
FROM outcome2 w JOIN semantic0_0_ranked n ON n.file=w.file AND n.tree=w.tree AND n.rank=w.rank+1
WHERE w.phase=1 AND (w.own=0) AND w.rank<w.finish
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own=0 AND w.uncertain THEN 2 ELSE w.own END AS truth,w.c1 AS c1 FROM outcome2 w WHERE w.phase=1 AND (NOT (w.own=0) OR w.rank=w.finish)
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,d.c2 AS c2,d.u0,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1,r.c3 AS e2 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u0 OR d.u1 OR d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v1,NULL AS v2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,COALESCE(r.c0,0),w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),w.v1,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2,r.c3 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 WHERE w.stopped>=0 AND (n.kind IN (191))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome1 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0 AND (n.kind IN (191))
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,NULL,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (NULL) IS NOT NULL
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (NULL) IS NULL)
),
outcome4 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome1 d LEFT JOIN outcome3 t ON t.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome4
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.u1,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1,r.c3 AS e2 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u1 OR d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v1,NULL AS v2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2,r.c3 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2 WHERE w.stopped>=0 AND (n.kind IN (196,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u2) THEN CASE WHEN n.named AND (CASE WHEN d.c2 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c2,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,CASE WHEN d.tested=1 THEN d.node ELSE d.c2 END AS c2,d.u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.u1,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,r.c0 AS tree,COALESCE(r.c1,1) AS rank,COALESCE(r.c2,1) AS finish,COALESCE(r.c3,0) AS origin,(0) AS incoming FROM outcome0 d CROSS JOIN node probe ON probe.file=d.file AND probe.id=d.node CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT tree,rank,finish,depth FROM semantic0_0_summary WHERE file=d.file AND node=d.node AND d.work>0 AND (0)<256 AND (probe.kind IN (226)))
),
outcome2 AS MATERIALIZED (
SELECT s.k,s.file,s.node,s.tree,s.rank,s.finish,s.origin,s.incoming,s.incoming AS level,0 AS phase,0 AS own,0 AS uncertain,s.work,NULL AS c1 FROM outcome1 s
UNION ALL
SELECT semantic_entry0_0.k,semantic_entry0_0.file,semantic_entry0_0.node,semantic_entry0_0.tree,semantic_entry0_0.rank,semantic_entry0_0.finish,semantic_entry0_0.origin,semantic_entry0_0.incoming,semantic_entry0_0.level,1,CASE WHEN semantic_entry0_0.level>=256 THEN -1 WHEN semantic_entry0_0.work=0 THEN -2 ELSE r.c0 END,semantic_entry0_0.uncertain,COALESCE(r.c1,semantic_entry0_0.work),r.c2
FROM outcome2 semantic_entry0_0 JOIN outcome0 d ON d.k=semantic_entry0_0.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,semantic_entry0_0.file AS file,semantic_entry0_0.node AS node,semantic_entry0_0.work-1 AS work,d.c1 AS c1 WHERE semantic_entry0_0.work>0 AND semantic_entry0_0.level<256
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c1 AS c1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN n.named AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome6 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(3,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome8 s
),
outcome10 AS (
SELECT d.parent,o.truth,o.c1 AS c1,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome9 o ON o.k=d.k WHERE o.truth<>0
),
outcome11 AS MATERIALIZED (
SELECT * FROM outcome10 WHERE choice=1
),
outcome12 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c1 ELSE d.c1 END AS c1 FROM outcome0 d LEFT JOIN outcome11 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome12 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(3,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, CASE WHEN w.stopped<0 THEN 0 WHEN w.work=0 THEN -2 ELSE COALESCE(r.c0,0) END,w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe."end">probe.start THEN 1 ELSE 0 END,w.work-1 FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0 AND w.work>0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>3)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>3)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<0) OR COALESCE(t.low,0)>3 THEN 0 WHEN COALESCE(t.low,0)>=0 AND (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<=3) AND (1) THEN 1 ELSE 2 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome8 o) WHERE semantic_entry0_0.phase=0
UNION ALL
SELECT w.k,w.file,n.node,w.tree,n.rank,w.finish,w.origin,w.incoming,w.incoming+n.depth-w.origin,0,0,w.uncertain OR w.own=2,w.work,NULL
FROM outcome2 w JOIN semantic0_0_ranked n ON n.file=w.file AND n.tree=w.tree AND n.rank=w.rank+1
WHERE w.phase=1 AND (w.own=0) AND w.rank<w.finish
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own=0 AND w.uncertain THEN 2 ELSE w.own END AS truth,w.c1 AS c1 FROM outcome2 w WHERE w.phase=1 AND (NOT (w.own=0) OR w.rank=w.finish)
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,d.c2 AS c2,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,d.u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,p.work,p.truth FROM outcome0 d CROSS JOIN relation_bound_budget p ON p.term=5 AND p.file=d.file AND p.node=d.node AND p.allowance=d.work AND p.i0 IS d.c2 AND p.i1 IS d.c0
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.u1,d.u2 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1,s.c2 AS c2 FROM outcome9 s
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome10 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,COALESCE(r.c0,0),w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),w.v1,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v1,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v1 AS c1,t.v2 AS c2 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1,s.c2 AS c2 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome8 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.parent END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN w.stopped=0 THEN n.parent END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v1,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN w.stopped=0 THEN n.parent END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v1 AS c1,t.v2 AS c2 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,d.u0,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c1 AS c1 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c1 AS c1 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome2 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c1 AS c1 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.prev AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.prev) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work,w.v1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0 AND (n.kind IN (191,196,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c1 AS c1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,r.c0 AS tree,COALESCE(r.c1,1) AS rank,COALESCE(r.c2,1) AS finish,COALESCE(r.c3,0) AS origin,(0) AS incoming FROM outcome0 d CROSS JOIN node probe ON probe.file=d.file AND probe.id=d.node CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT tree,rank,finish,depth FROM semantic0_0_summary WHERE file=d.file AND node=d.node AND d.work>0 AND (0)<256 AND (probe.kind IN (226)))
),
outcome2 AS MATERIALIZED (
SELECT s.k,s.file,s.node,s.tree,s.rank,s.finish,s.origin,s.incoming,s.incoming AS level,0 AS phase,0 AS own,0 AS uncertain,s.work,NULL AS c1 FROM outcome1 s
UNION ALL
SELECT semantic_entry0_0.k,semantic_entry0_0.file,semantic_entry0_0.node,semantic_entry0_0.tree,semantic_entry0_0.rank,semantic_entry0_0.finish,semantic_entry0_0.origin,semantic_entry0_0.incoming,semantic_entry0_0.level,1,CASE WHEN semantic_entry0_0.level>=256 THEN -1 WHEN semantic_entry0_0.work=0 THEN -2 ELSE r.c0 END,semantic_entry0_0.uncertain,COALESCE(r.c1,semantic_entry0_0.work),r.c2
FROM outcome2 semantic_entry0_0 JOIN outcome0 d ON d.k=semantic_entry0_0.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,semantic_entry0_0.file AS file,semantic_entry0_0.node AS node,semantic_entry0_0.work-1 AS work,d.c1 AS c1 WHERE semantic_entry0_0.work>0 AND semantic_entry0_0.level<256
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c1 AS c1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN n.named AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome6 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(3,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome8 s
),
outcome10 AS (
SELECT d.parent,o.truth,o.c1 AS c1,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome9 o ON o.k=d.k WHERE o.truth<>0
),
outcome11 AS MATERIALIZED (
SELECT * FROM outcome10 WHERE choice=1
),
outcome12 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c1 ELSE d.c1 END AS c1 FROM outcome0 d LEFT JOIN outcome11 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome12 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(3,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, CASE WHEN w.stopped<0 THEN 0 WHEN w.work=0 THEN -2 ELSE COALESCE(r.c0,0) END,w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe."end">probe.start THEN 1 ELSE 0 END,w.work-1 FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0 AND w.work>0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>3)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>3)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<0) OR COALESCE(t.low,0)>3 THEN 0 WHEN COALESCE(t.low,0)>=0 AND (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<=3) AND (1) THEN 1 ELSE 2 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome8 o) WHERE semantic_entry0_0.phase=0
UNION ALL
SELECT w.k,w.file,n.node,w.tree,n.rank,w.finish,w.origin,w.incoming,w.incoming+n.depth-w.origin,0,0,w.uncertain OR w.own=2,w.work,NULL
FROM outcome2 w JOIN semantic0_0_ranked n ON n.file=w.file AND n.tree=w.tree AND n.rank=w.rank+1
WHERE w.phase=1 AND (w.own=0) AND w.rank<w.finish
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own=0 AND w.uncertain THEN 2 ELSE w.own END AS truth,w.c1 AS c1 FROM outcome2 w WHERE w.phase=1 AND (NOT (w.own=0) OR w.rank=w.finish)
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1 WHERE w.stopped>=0 AND (n.kind IN (196,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,r.c0 AS tree,COALESCE(r.c1,1) AS rank,COALESCE(r.c2,1) AS finish,COALESCE(r.c3,0) AS origin,(0) AS incoming FROM outcome0 d CROSS JOIN node probe ON probe.file=d.file AND probe.id=d.node CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT tree,rank,finish,depth FROM semantic0_0_summary WHERE file=d.file AND node=d.node AND d.work>0 AND (0)<256 AND (probe.kind IN (226)))
),
outcome2 AS MATERIALIZED (
SELECT s.k,s.file,s.node,s.tree,s.rank,s.finish,s.origin,s.incoming,s.incoming AS level,0 AS phase,0 AS own,0 AS uncertain,s.work,NULL AS c1 FROM outcome1 s
UNION ALL
SELECT semantic_entry0_0.k,semantic_entry0_0.file,semantic_entry0_0.node,semantic_entry0_0.tree,semantic_entry0_0.rank,semantic_entry0_0.finish,semantic_entry0_0.origin,semantic_entry0_0.incoming,semantic_entry0_0.level,1,CASE WHEN semantic_entry0_0.level>=256 THEN -1 WHEN semantic_entry0_0.work=0 THEN -2 ELSE r.c0 END,semantic_entry0_0.uncertain,COALESCE(r.c1,semantic_entry0_0.work),r.c2
FROM outcome2 semantic_entry0_0 JOIN outcome0 d ON d.k=semantic_entry0_0.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,semantic_entry0_0.file AS file,semantic_entry0_0.node AS node,semantic_entry0_0.work-1 AS work,d.c1 AS c1 WHERE semantic_entry0_0.work>0 AND semantic_entry0_0.level<256
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c1 AS c1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,0 AS u1 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN n.named AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome6 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(3,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome8 s
),
outcome10 AS (
SELECT d.parent,o.truth,o.c1 AS c1,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome9 o ON o.k=d.k WHERE o.truth<>0
),
outcome11 AS MATERIALIZED (
SELECT * FROM outcome10 WHERE choice=1
),
outcome12 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c1 ELSE d.c1 END AS c1 FROM outcome0 d LEFT JOIN outcome11 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome12 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(3,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, CASE WHEN w.stopped<0 THEN 0 WHEN w.work=0 THEN -2 ELSE COALESCE(r.c0,0) END,w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe."end">probe.start THEN 1 ELSE 0 END,w.work-1 FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0 AND w.work>0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>3)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>3)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<0) OR COALESCE(t.low,0)>3 THEN 0 WHEN COALESCE(t.low,0)>=0 AND (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<=3) AND (1) THEN 1 ELSE 2 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.u1 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome8 o) WHERE semantic_entry0_0.phase=0
UNION ALL
SELECT w.k,w.file,n.node,w.tree,n.rank,w.finish,w.origin,w.incoming,w.incoming+n.depth-w.origin,0,0,w.uncertain OR w.own=2,w.work,NULL
FROM outcome2 w JOIN semantic0_0_ranked n ON n.file=w.file AND n.tree=w.tree AND n.rank=w.rank+1
WHERE w.phase=1 AND (w.own=0) AND w.rank<w.finish
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own=0 AND w.uncertain THEN 2 ELSE w.own END AS truth,w.c1 AS c1 FROM outcome2 w WHERE w.phase=1 AND (NOT (w.own=0) OR w.rank=w.finish)
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,COALESCE(r.c0,0),w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),w.v1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v1 AS c1 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c1 AS c1 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.prev END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN w.stopped=0 THEN n.prev END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN w.stopped=0 THEN n.prev END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v1 AS c1 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome3 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c1 AS c1 FROM outcome6 s
),
outcome8 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome7
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.c2 AS c2,d.u0,d.u1,d.u2 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c1 AS c1,s.c2 AS c2 FROM outcome9 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2 FROM outcome10 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,COALESCE(r.c0,0),w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),w.v0,w.v1,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (191) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL,NULL,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0,w.v1,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0,t.v1 AS c1,t.v2 AS c2 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2 FROM outcome3 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c1 AS c1,s.c2 AS c2 FROM outcome9 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1,o.c2 AS c2 FROM outcome10 o) WHERE w.truth>=0
),
semantic0_0_seed(file,node,active) AS MATERIALIZED (
 SELECT n.file,n.id,CASE WHEN NOT (0) AND (n.kind IN (226)) THEN 1 ELSE 0 END
 FROM node n
 WHERE n.kind IN (226) AND n.file IN (SELECT DISTINCT file FROM outcome0)
),
semantic0_0_domain(file,node) AS MATERIALIZED (
 SELECT file,node FROM semantic0_0_seed
 UNION
 SELECT c.file,c.id FROM semantic0_0_seed s
 CROSS JOIN node c ON c.file=s.file AND c.parent=s.node
 WHERE s.active AND (c.kind IN (196,226))
),
semantic0_0_local(file,node,parent,last,base,active,eligible) AS MATERIALIZED (
 SELECT n.file,n.id,n.parent,n."last",(0),
 CASE WHEN NOT (0) AND (n.kind IN (226)) THEN 1 ELSE 0 END,(n.kind IN (196,226))
 FROM semantic0_0_domain d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
semantic0_0_forest(file,node,tree,depth) AS MATERIALIZED (
 SELECT l.file,l.node,l.node,0 FROM semantic0_0_local l
 LEFT JOIN semantic0_0_local p ON p.file=l.file AND p.node=l.parent
 WHERE NOT l.eligible OR COALESCE(p.active,0)=0
 UNION ALL
 SELECT c.file,c.node,f.tree,f.depth+1
 FROM semantic0_0_forest f
 JOIN semantic0_0_local p ON p.file=f.file AND p.node=f.node AND p.active
 JOIN semantic0_0_local c ON c.file=p.file AND c.parent=p.node AND c.eligible
),
semantic0_0_ranked(file,node,tree,depth,last,base,rank) AS MATERIALIZED (
 SELECT f.file,f.node,f.tree,f.depth,l.last,l.base,
 ROW_NUMBER() OVER (PARTITION BY f.file,f.tree ORDER BY f.node)
 FROM semantic0_0_forest f JOIN semantic0_0_local l ON l.file=f.file AND l.node=f.node
),
semantic0_0_success(file,node,tree,depth,last,rank,success) AS MATERIALIZED (
 SELECT file,node,tree,depth,last,rank,
 MIN(CASE WHEN base THEN rank END) OVER (
 PARTITION BY file,tree ORDER BY rank
 ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING)
 FROM semantic0_0_ranked
),
semantic0_0_events(file,node,tree,position,event,rank) AS MATERIALIZED (
 SELECT file,node,tree,node,0,rank FROM semantic0_0_ranked
 UNION ALL
 SELECT file,node,tree,last,1,NULL FROM semantic0_0_ranked
),
semantic0_0_exits(file,node,tree,event,endrank) AS MATERIALIZED (
 SELECT file,node,tree,event,
 MAX(rank) OVER (PARTITION BY file,tree ORDER BY position,event
 ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
 FROM semantic0_0_events
),
semantic0_0_finished(file,node,tree,depth,rank,finish,truth) AS MATERIALIZED (
 SELECT s.file,s.node,s.tree,s.depth,s.rank,
 CASE WHEN s.success<=e.endrank THEN s.success ELSE e.endrank END,
 CASE WHEN s.success<=e.endrank THEN 1 ELSE 0 END
 FROM semantic0_0_success s JOIN semantic0_0_exits e
 ON e.file=s.file AND e.node=s.node AND e.tree=s.tree AND e.event=1
),
semantic0_0_summary(file,node,tree,depth,rank,finish,truth,cost) AS MATERIALIZED (
 SELECT file,node,tree,depth,rank,finish,truth,finish-rank+1
 FROM semantic0_0_finished
),
outcome3 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c0 AS v0,o.c1 AS v1,o.c2 AS v2 FROM outcome1 o WHERE o.truth=1 OR o.truth<0
),
outcome4 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome3 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(m.v0,m.v1,m.v2) END AS payload,0 AS failure,m.work FROM outcome3 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome4 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome4
ORDER BY 1,2,3