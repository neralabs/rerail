WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM node AS a0n0 WHERE a0n0.kind IN (121)
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node