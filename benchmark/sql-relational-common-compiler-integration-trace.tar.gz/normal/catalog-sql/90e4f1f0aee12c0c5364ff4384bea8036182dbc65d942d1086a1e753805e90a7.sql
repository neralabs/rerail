WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT relation_memo_reset(0) AS ready
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n CROSS JOIN outcome0 init ON init.ready=1 WHERE 1 AND n.kind IN (1)
),
outcome2 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0 FROM outcome1 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2 FROM outcome2 w CROSS JOIN outcome1 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE (CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END) WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE 2 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE schedule AS (SELECT d.node AS node,(0) AS level,0 AS phase,NULL AS parent,d.work AS work,d.work AS start,0 AS fill,NULL AS token,0 AS truth,0 AS uncertain,0 AS cursor
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor WHERE recursive_entry_0.phase=0),
lookup AS MATERIALIZED (SELECT s.*,m.truth AS hit,m.cost,m.peak FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 THEN 0 END AND m.clause IS 0 AND m.utility IS 2000000 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.peak<=256-s.level),
opened AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NULL AND s.level<256 THEN relation_peak_open(s.level) END AS opened_token FROM lookup s),
noted AS MATERIALIZED (SELECT s.*,CASE WHEN s.hit IS NOT NULL THEN relation_peak_note(s.level+s.peak) WHEN s.opened_token IS NOT NULL THEN relation_peak_note(s.level+1) ELSE 1 END AS ready FROM opened s)
SELECT s.node,s.level,CASE WHEN s.hit IS NOT NULL THEN 4 WHEN s.level>=256 OR s.work=0 THEN 3 ELSE 10 END,s.parent,
CASE WHEN s.hit IS NOT NULL THEN MAX(0,s.work-s.cost) WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,
s.work,relation_cache_fill_steps(),s.opened_token,
CASE WHEN s.hit IS NOT NULL THEN CASE WHEN s.work<s.cost THEN -2 ELSE s.hit END WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END,0,0 FROM noted s WHERE s.ready=1) WHERE recursive_entry_0.phase=0
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor WHERE recursive_entry_0.phase=3),
s AS MATERIALIZED (SELECT s.*,CASE WHEN s.token IS NOT NULL THEN relation_peak_close(s.token) END AS measured FROM reached s)
SELECT s.node,s.level,4,s.parent,s.work,s.start,s.fill,NULL,COALESCE(m.truth,s.truth),s.uncertain,s.cursor FROM s LEFT JOIN relation_memo m ON m.mode IS CASE WHEN 1 AND s.truth>=0 AND s.token IS NOT NULL THEN 1 END AND m.clause IS 0 AND m.utility IS 2000000 AND m.file IS d.file AND m.node IS s.node AND m.k0 IS d.c0 AND m.vtruth IS s.truth AND m.vcost IS MAX(0,s.start-s.work-relation_cache_fill_delta(s.fill)) AND m.vpeak IS s.measured WHERE COALESCE(s.measured,0)>=0) WHERE recursive_entry_0.phase=3
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor WHERE recursive_entry_0.phase=4)
SELECT COALESCE(p.c0,s.node),COALESCE(p.c1,s.level),CASE WHEN s.parent IS NULL THEN 5 WHEN s.truth IN (0,2) THEN p.c7 ELSE 3 END,p.parent,s.work,p.c2,p.c3,p.c4,s.truth,COALESCE(p.c5,0) OR s.truth=2,p.c6
FROM s LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.parent IS NOT NULL THEN 2 END AND p.h IS s.parent) WHERE recursive_entry_0.phase=4
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH s AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor WHERE recursive_entry_0.phase=10) SELECT s.node,s.level,CASE WHEN r.c0 IN (0,2) THEN 11 ELSE 3 END,s.parent,r.c1,s.start,s.fill,s.token,CASE WHEN r.c0=0 AND s.uncertain THEN 2 ELSE r.c0 END,s.uncertain OR r.c0=2,0 FROM s CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,recursive_entry_0.node AS node,recursive_entry_0.work AS work,d.c0 AS c0 WHERE recursive_entry_0.phase=10
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0 AND (n.kind IN (137))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (137) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome1 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0 AND (n.kind IN (161))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (161) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (1)) ORDER BY candidate.id LIMIT 1) AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE ((SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (1)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (1) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,((recursive_entry_0.level+1)+0) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.peak<=256-((recursive_entry_0.level+1)+0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(1,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (215)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (215) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(2,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(3,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (146,147)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN ((n.kind IN (146)) OR (n.kind IN (147))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome4 s
),
outcome6 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome5 o ON o.k=d.k WHERE o.truth<>0
),
outcome7 AS MATERIALIZED (
SELECT * FROM outcome6 WHERE choice=1
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome7 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome9 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (182,183,208)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN (n.kind IN (182)) OR (n.kind IN (208)) OR (n.kind IN (183)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (146,147)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN ((n.kind IN (146)) OR (n.kind IN (147))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome4 s
),
outcome6 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome5 o ON o.k=d.k WHERE o.truth<>0
),
outcome7 AS MATERIALIZED (
SELECT * FROM outcome6 WHERE choice=1
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome7 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(4,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome11 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome10 d
),
outcome12 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome11 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (184,185)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN (n.kind IN (184)) OR (n.kind IN (185)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (146,147,208)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN ((n.kind IN (146)) OR (n.kind IN (147)) OR (n.kind IN (208))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome4 s
),
outcome6 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome5 o ON o.k=d.k WHERE o.truth<>0
),
outcome7 AS MATERIALIZED (
SELECT * FROM outcome6 WHERE choice=1
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome7 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome13 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome12 d
),
outcome14 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome13 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (163)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (163) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(1,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome5 o ON o.parent=d.k
),
outcome7 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome6
) SELECT o.truth,o.work FROM outcome7 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome6 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (164,172)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN ((n.kind IN (164)) OR (n.kind IN (172))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome4 s
),
outcome6 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome5 o ON o.k=d.k WHERE o.truth<>0
),
outcome7 AS MATERIALIZED (
SELECT * FROM outcome6 WHERE choice=1
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome7 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome8 o)
),
outcome8 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome7 d
),
outcome9 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome8 s
),
outcome10 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome9 o ON o.k=d.k WHERE o.truth<>0
),
outcome11 AS MATERIALIZED (
SELECT * FROM outcome10 WHERE choice=1
),
outcome12 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome11 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome12 o)
),
outcome15 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome14 d
),
outcome16 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome15 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (172)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (172) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(2,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome17 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome16 d
),
outcome18 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome17 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (173)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (173) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome19 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome18 d
),
outcome20 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome19 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (186)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (186) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (164)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (164) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(5,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome21 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome20 d
),
outcome22 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome21 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.parent AS node,1 AS distance FROM outcome0 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.parent IS NOT NULL UNION ALL SELECT w.parent,n.file,n.parent,w.distance+1 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.parent IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0 FROM outcome1 w JOIN outcome0 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (111,114,115,150,151)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN ((n.kind IN (111)) OR (n.kind IN (115)) OR (n.kind IN (114)) OR (n.kind IN (150)) OR (n.kind IN (151))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
),
outcome7 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome6 o ON o.k=d.k WHERE o.truth<>0
),
outcome8 AS MATERIALIZED (
SELECT * FROM outcome7 WHERE choice=1
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome8 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome9 o)
),
outcome23 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome22 d
),
outcome24 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome23 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (273)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (273) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (186)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (186) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (140)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (140) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome25 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,d.c0 AS c0 FROM outcome24 d
),
outcome26 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome25 s
) SELECT o.truth,o.work FROM outcome26 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome2
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome8 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (1)) ORDER BY candidate.id LIMIT 1),w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (1)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (1)) ORDER BY candidate.id LIMIT 1)) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome4 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome1 d LEFT JOIN outcome3 t ON t.k=d.k
),
outcome5 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome4
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,NULL,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (NULL) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (NULL) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(6,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)) WHERE recursive_entry_0.phase=10
UNION ALL
SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10 FROM schedule recursive_entry_0 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10) IS (WITH reached AS MATERIALIZED (SELECT recursive_entry_0.node AS node,recursive_entry_0.level AS level,recursive_entry_0.phase AS phase,recursive_entry_0.parent AS parent,recursive_entry_0.work AS work,recursive_entry_0.start AS start,recursive_entry_0.fill AS fill,recursive_entry_0.token AS token,recursive_entry_0.truth AS truth,recursive_entry_0.uncertain AS uncertain,recursive_entry_0.cursor AS cursor WHERE recursive_entry_0.phase=11),
s AS MATERIALIZED (SELECT s.*,(SELECT child.id FROM node child WHERE child.file=d.file AND (s.cursor=0 AND child.id=n.parent) AND ((child.kind IN (180,181,184,201,226)) AND (child.kind IN (180,181,184,201,226))) AND (1) ORDER BY child.id LIMIT 1) AS child FROM reached s CROSS JOIN node n ON n.file=d.file AND n.id=s.node)
SELECT COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN s.level ELSE s.level+1 END,CASE WHEN s.child IS NULL THEN 3 ELSE 0 END,COALESCE(p.handle,s.parent),s.work,s.start,s.fill,CASE WHEN s.child IS NULL THEN s.token END,CASE WHEN s.uncertain THEN 2 ELSE 0 END,s.uncertain,0
FROM s  LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND p.parent_input IS s.parent AND p.v0 IS s.node AND p.v1 IS s.level AND p.v2 IS s.start AND p.v3 IS s.fill AND p.v4 IS s.token AND p.v5 IS s.uncertain AND p.v6 IS 1 AND p.v7 IS 11) WHERE recursive_entry_0.phase=11) SELECT truth,work FROM schedule WHERE phase=5)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome7 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,(0) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.peak<=256-(0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,origin.parent AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (origin.parent) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, w.own,COALESCE(r.c0,0),w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN probe.kind IN (137) THEN 1 ELSE 0 END,w.work FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (1)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0 AND (n.kind IN (137))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (137) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0 AND (n.kind IN (161))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (161) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=origin.file AND candidate.id>origin.id AND candidate.id<=origin."last" AND (candidate.kind IN (207) AND node_regex(8,candidate.file,candidate.id)) ORDER BY candidate.id LIMIT 1) AS node,origin."last" AS bound,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node
),
outcome2 AS MATERIALIZED (
SELECT k,file,node,bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,work FROM outcome1 WHERE node IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0
),
outcome1 AS MATERIALIZED (
SELECT d.*,(1) AS incoming,m.truth AS hit,m.cost,m.peak FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.peak<=256-(1)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (207) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (1)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN ((n.kind IN (1)) AND (node_regex(7,n.file,n.id))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome4 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE n.kind IN (158)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n.kind IN (158) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 1 AND m.file IS d.file AND m.node IS d.node AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,(SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (207) AND node_regex(8,candidate.file,candidate.id)) ORDER BY candidate.id LIMIT 1),w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (207) AND node_regex(8,candidate.file,candidate.id)) ORDER BY candidate.id LIMIT 1)) IS NOT NULL
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome2 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR ((SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND candidate.id>w.node AND candidate.id<=w.bound AND (candidate.kind IN (207) AND node_regex(8,candidate.file,candidate.id)) ORDER BY candidate.id LIMIT 1)) IS NULL)
),
outcome4 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome3 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome4 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN w.stopped=0 THEN n.parent END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN w.stopped=0 THEN n.parent END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN w.stopped=0 THEN n.parent END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 2 AND m.file IS d.file AND m.node IS d.node AND m.vtruth IS d.tested AND m.vcost IS (d.work-d.remaining) AND m.vpeak IS d.measured_peak WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work FROM outcome6 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome9 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o) WHERE w.truth>=0
),
outcome3 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c0 AS v0 FROM outcome2 o WHERE o.truth=1 OR o.truth<0
),
outcome4 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome3 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(m.v0) END AS payload,0 AS failure,m.work FROM outcome3 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome4 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome4
ORDER BY 1,2,3