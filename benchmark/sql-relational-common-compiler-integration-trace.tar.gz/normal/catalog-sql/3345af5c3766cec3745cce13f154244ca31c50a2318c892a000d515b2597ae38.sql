WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM r2 AS seed0 CROSS JOIN node AS a0n1 ON a0n1.file=seed0.file AND a0n1.id=seed0.node CROSS JOIN node AS a0n0 ON a0n0.file=a0n1.file AND a0n0.parent=a0n1.id CROSS JOIN node AS a0n2 ON a0n2.file=a0n0.file AND a0n2.id=a0n0.next WHERE node_regex(0,a0n0.file,a0n0.id) AND a0n1.kind IN (140) AND node_regex(1,a0n2.file,a0n2.id)
),
-- linear walk target
r1(file,node) AS (
SELECT a1n0.file,a1n0.id FROM node AS a1n0 WHERE a1n0.kind IN (140)
),
-- linear walk answers
r2(file,node) AS MATERIALIZED (
SELECT a2n0.file,a2n0.id FROM r1 AS seed2 CROSS JOIN node AS a2n1 ON a2n1.file=seed2.file AND a2n1.id=seed2.node CROSS JOIN node AS a2n0 ON a2n0.file=a2n1.file AND a2n0.id=a2n1.prev
UNION
SELECT a3n0.file,a3n0.id FROM r2 AS seed3 CROSS JOIN node AS a3n1 ON a3n1.file=seed3.file AND a3n1.id=seed3.node CROSS JOIN node AS a3n0 ON a3n0.file=a3n1.file AND a3n0.id=a3n1.prev
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node