WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM r1 AS seed0 CROSS JOIN node AS a0n0 ON a0n0.file=seed0.file AND a0n0.id=seed0.node WHERE EXISTS (SELECT 1 FROM r2 k WHERE k.file=a0n0.file AND k.node=a0n0.id)
UNION
SELECT a1n0.file,a1n0.id FROM r2 AS seed1 CROSS JOIN node AS a1n0 ON a1n0.file=seed1.file AND a1n0.id=seed1.node WHERE a1n0.kind IN (231) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit2 CROSS JOIN node AS a2n1 ON a2n1.file=a1n0.file AND a2n1.parent=a1n0.id WHERE a2n1.kind IN (232) AND NOT (EXISTS (SELECT 1 FROM r1 k WHERE k.file=a2n1.file AND k.node=a2n1.id))))
UNION
SELECT a4n0.file,a4n0.id FROM r2 AS seed4 CROSS JOIN node AS a4n0 ON a4n0.file=seed4.file AND a4n0.id=seed4.node WHERE a4n0.kind IN (93)
UNION
SELECT a5n0.file,a5n0.id FROM r2 AS seed5 CROSS JOIN node AS a5n0 ON a5n0.file=seed5.file AND a5n0.id=seed5.node WHERE a5n0.kind IN (94)
UNION
SELECT a6n0.file,a6n0.id FROM r2 AS seed6 CROSS JOIN node AS a6n0 ON a6n0.file=seed6.file AND a6n0.id=seed6.node WHERE a6n0.kind IN (96)
UNION
SELECT a7n0.file,a7n0.id FROM r2 AS seed7 CROSS JOIN node AS a7n0 ON a7n0.file=seed7.file AND a7n0.id=seed7.node WHERE a7n0.kind IN (97)
UNION
SELECT a8n0.file,a8n0.id FROM r2 AS seed8 CROSS JOIN node AS a8n0 ON a8n0.file=seed8.file AND a8n0.id=seed8.node WHERE a8n0.kind IN (98)
UNION
SELECT a9n0.file,a9n0.id FROM r2 AS seed9 CROSS JOIN node AS a9n0 ON a9n0.file=seed9.file AND a9n0.id=seed9.node WHERE a9n0.kind IN (88)
),
-- utility[0]
r1(file,node) AS MATERIALIZED (
SELECT a10n0.file,a10n0.id FROM node AS a10n0 WHERE a10n0.kind IN (232) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit11 CROSS JOIN node AS a11n1 ON a11n1.file=a10n0.file AND a11n1.parent=a10n0.id WHERE a11n1.kind IN (104) AND node_regex(0,a11n1.file,a11n1.id)))
),
-- utility[1]
r2(file,node) AS MATERIALIZED (
SELECT a12n0.file,a12n0.id FROM node AS a12n1 CROSS JOIN node AS a12n0 ON a12n0.file=a12n1.file AND a12n0.parent=a12n1.id CROSS JOIN node AS a12n2 ON a12n2.file=a12n0.file AND a12n2.id=a12n0.prev WHERE a12n1.kind IN (127) AND node_regex(1,a12n2.file,a12n2.id)
UNION
SELECT a13n0.file,a13n0.id FROM r2 AS seed13 CROSS JOIN node AS a13n1 ON a13n1.file=seed13.file AND a13n1.id=seed13.node CROSS JOIN node AS a13n0 ON a13n0.file=a13n1.file AND a13n0.parent=a13n1.id WHERE a13n1.kind IN (226)
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node