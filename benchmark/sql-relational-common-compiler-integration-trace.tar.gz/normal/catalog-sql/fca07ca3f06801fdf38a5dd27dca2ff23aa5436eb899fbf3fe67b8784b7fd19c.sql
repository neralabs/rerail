WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n WHERE 1 AND n.kind IN (207)
),
outcome1 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0 FROM outcome0 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2 FROM outcome1 w CROSS JOIN outcome0 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (207) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,8 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome1 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 5 THEN n.kind IN (226) WHEN 6 THEN n.kind IN (238) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome2 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome2 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome2 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 7 THEN n.parent END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 7 THEN n.kind IN (226,238) ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome2 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome2 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome2 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 7 THEN NULL END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome2 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome3 AS MATERIALIZED (
SELECT k,work,truth FROM outcome2 WHERE pc IS NULL
),
outcome4 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome3
) SELECT o.truth,o.work FROM outcome4 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v0 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c0 AS c0 WHERE w.stopped>=0 AND (n.kind IN (1,204,226))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,r.c0 AS tree,COALESCE(r.c1,1) AS rank,COALESCE(r.c2,1) AS finish,COALESCE(r.c3,0) AS origin,(0) AS incoming FROM outcome0 d CROSS JOIN node probe ON probe.file=d.file AND probe.id=d.node CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT tree,rank,finish,depth FROM semantic0_0_summary WHERE file=d.file AND node=d.node AND d.work>0 AND (0)<256 AND (probe.kind IN (226)))
),
outcome2 AS MATERIALIZED (
SELECT s.k,s.file,s.node,s.tree,s.rank,s.finish,s.origin,s.incoming,s.incoming AS level,0 AS phase,0 AS own,0 AS uncertain,s.work FROM outcome1 s
UNION ALL
SELECT semantic_entry0_0.k,semantic_entry0_0.file,semantic_entry0_0.node,semantic_entry0_0.tree,semantic_entry0_0.rank,semantic_entry0_0.finish,semantic_entry0_0.origin,semantic_entry0_0.incoming,semantic_entry0_0.level,1,CASE WHEN semantic_entry0_0.level>=256 THEN -1 WHEN semantic_entry0_0.work=0 THEN -2 ELSE r.c0 END,semantic_entry0_0.uncertain,COALESCE(r.c1,semantic_entry0_0.work)
FROM outcome2 semantic_entry0_0 JOIN outcome0 d ON d.k=semantic_entry0_0.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,semantic_entry0_0.file AS file,semantic_entry0_0.node AS node,semantic_entry0_0.work-1 AS work WHERE semantic_entry0_0.work>0 AND semantic_entry0_0.level<256
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,d.work) AS work,CASE WHEN ((semantic_entry0_0.level+1)+0)>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT COALESCE(v.truth,0),COALESCE(v.work,d.work-1) FROM node probe LEFT JOIN relation_value_budget(0,d.file,d.node,CASE WHEN (d.work>0 AND ((semantic_entry0_0.level+1)+0)<256) AND (((probe.kind IN (1)) OR (probe.kind IN (204)))) THEN d.work-1 END) v ON 1 WHERE probe.file=d.file AND probe.id=d.node AND (d.work>0 AND ((semantic_entry0_0.level+1)+0)<256))
) SELECT o.truth,o.work FROM outcome1 o) WHERE semantic_entry0_0.phase=0
UNION ALL
SELECT w.k,w.file,n.node,w.tree,n.rank,w.finish,w.origin,w.incoming,w.incoming+n.depth-w.origin,0,0,w.uncertain OR w.own=2,w.work
FROM outcome2 w JOIN semantic0_0_ranked n ON n.file=w.file AND n.tree=w.tree AND n.rank=w.rank+1
WHERE w.phase=1 AND (w.own IN (0,2)) AND w.rank<w.finish
),
outcome3 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own=0 AND w.uncertain THEN 2 ELSE w.own END AS truth FROM outcome2 w WHERE w.phase=1 AND (NOT (w.own IN (0,2)) OR w.rank=w.finish)
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE n.kind IN (158,224)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN n.kind IN (158) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN n.kind IN (224) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome10 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome8 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v0 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v0 AS c0 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome8 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,7,0,1),(5,4,4,1,0),(6,4,0,5,0),(7,6,6,0,1),(8,5,7,0,1))),
semantic0_0_seed(file,node,active) AS MATERIALIZED (
 SELECT n.file,n.id,CASE WHEN NOT (0) AND (n.kind IN (226)) THEN 1 ELSE 0 END
 FROM node n
 WHERE n.kind IN (226) AND n.file IN (SELECT DISTINCT file FROM outcome0)
),
semantic0_0_domain(file,node) AS MATERIALIZED (
 SELECT file,node FROM semantic0_0_seed
 UNION
 SELECT c.file,c.id FROM semantic0_0_seed s
 CROSS JOIN node c ON c.file=s.file AND c.parent=s.node
 WHERE s.active AND (c.kind IN (1,204,226))
),
semantic0_0_local(file,node,parent,last,base,active,eligible) AS MATERIALIZED (
 SELECT n.file,n.id,n.parent,n."last",(0),
 CASE WHEN NOT (0) AND (n.kind IN (226)) THEN 1 ELSE 0 END,(n.kind IN (1,204,226))
 FROM semantic0_0_domain d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
semantic0_0_forest(file,node,tree,depth) AS MATERIALIZED (
 SELECT l.file,l.node,l.node,0 FROM semantic0_0_local l
 LEFT JOIN semantic0_0_local p ON p.file=l.file AND p.node=l.parent
 WHERE NOT l.eligible OR COALESCE(p.active,0)=0
 UNION ALL
 SELECT c.file,c.node,f.tree,f.depth+1
 FROM semantic0_0_forest f
 JOIN semantic0_0_local p ON p.file=f.file AND p.node=f.node AND p.active
 JOIN semantic0_0_local c ON c.file=p.file AND c.parent=p.node AND c.eligible
),
semantic0_0_ranked(file,node,tree,depth,last,base,rank) AS MATERIALIZED (
 SELECT f.file,f.node,f.tree,f.depth,l.last,l.base,
 ROW_NUMBER() OVER (PARTITION BY f.file,f.tree ORDER BY f.node)
 FROM semantic0_0_forest f JOIN semantic0_0_local l ON l.file=f.file AND l.node=f.node
),
semantic0_0_success(file,node,tree,depth,last,rank,success) AS MATERIALIZED (
 SELECT file,node,tree,depth,last,rank,
 MIN(CASE WHEN base THEN rank END) OVER (
 PARTITION BY file,tree ORDER BY rank
 ROWS BETWEEN CURRENT ROW AND UNBOUNDED FOLLOWING)
 FROM semantic0_0_ranked
),
semantic0_0_events(file,node,tree,position,event,rank) AS MATERIALIZED (
 SELECT file,node,tree,node,0,rank FROM semantic0_0_ranked
 UNION ALL
 SELECT file,node,tree,last,1,NULL FROM semantic0_0_ranked
),
semantic0_0_exits(file,node,tree,event,endrank) AS MATERIALIZED (
 SELECT file,node,tree,event,
 MAX(rank) OVER (PARTITION BY file,tree ORDER BY position,event
 ROWS BETWEEN UNBOUNDED PRECEDING AND CURRENT ROW)
 FROM semantic0_0_events
),
semantic0_0_finished(file,node,tree,depth,rank,finish,truth) AS MATERIALIZED (
 SELECT s.file,s.node,s.tree,s.depth,s.rank,
 CASE WHEN s.success<=e.endrank THEN s.success ELSE e.endrank END,
 CASE WHEN s.success<=e.endrank THEN 1 ELSE 0 END
 FROM semantic0_0_success s JOIN semantic0_0_exits e
 ON e.file=s.file AND e.node=s.node AND e.tree=s.tree AND e.event=1
),
semantic0_0_summary(file,node,tree,depth,rank,finish,truth,cost) AS MATERIALIZED (
 SELECT file,node,tree,depth,rank,finish,truth,finish-rank+1
 FROM semantic0_0_finished
),
outcome4 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c0 AS v0 FROM outcome1 o WHERE o.truth=1 OR o.truth<0
),
outcome5 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome4 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(m.v0) END AS payload,0 AS failure,m.work FROM outcome4 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome5 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome5
ORDER BY 1,2,3