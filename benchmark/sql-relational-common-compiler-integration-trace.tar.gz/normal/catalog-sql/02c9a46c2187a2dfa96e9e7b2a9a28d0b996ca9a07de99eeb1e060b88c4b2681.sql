WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work FROM node n WHERE 1 AND n.kind IN (115)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (115) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome3 d WHERE d.truth>0 AND NOT (0)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome4 d WHERE 1
),
outcome6 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome5 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (113,163)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN (n.kind IN (163)) AND (node_regex(0,n.file,n.id)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome7 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome9 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome8 d
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome9 d WHERE d.truth=0
),
outcome11 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome10 d
),
outcome12 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (113) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome11 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome13 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome12 d
),
outcome14 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome13 d WHERE d.truth>0 AND NOT (0)
),
outcome15 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome14 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (163)
),
outcome16 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome15 d
),
outcome17 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (163) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome16 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome18 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome17 d
),
outcome19 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN node_regex(0,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome18 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome20 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome19 d
),
outcome21 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome20 s
),
outcome22 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome15 d JOIN outcome21 o ON o.k=d.k WHERE o.truth<>0
),
outcome23 AS MATERIALIZED (
SELECT * FROM outcome22 WHERE choice=1
),
outcome24 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome14 d LEFT JOIN outcome23 o ON o.parent=d.k
),
outcome25 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(o.work,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN o.truth<0 THEN o.truth WHEN d.truth=0 OR o.truth=0 THEN 0 WHEN d.truth=2 OR o.truth=2 THEN 2 ELSE 1 END AS truth FROM outcome13 d LEFT JOIN outcome24 o ON o.k=d.k
),
outcome26 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome25 s
),
outcome27 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(o.work,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN o.truth<0 THEN o.truth WHEN o.truth=1 THEN 1 WHEN o.truth=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(o.truth=2,0)) AS open FROM outcome9 d LEFT JOIN outcome26 o ON o.k=d.k
),
outcome28 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome27 s
),
outcome29 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome6 d JOIN outcome28 o ON o.k=d.k WHERE o.truth<>0
),
outcome30 AS MATERIALIZED (
SELECT * FROM outcome29 WHERE choice=1
),
outcome31 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome5 d LEFT JOIN outcome30 o ON o.parent=d.k
),
outcome32 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome31
),
outcome33 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(o.work,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN o.truth<0 THEN o.truth WHEN d.truth=0 OR o.truth=0 THEN 0 WHEN d.truth=2 OR o.truth=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome3 d LEFT JOIN outcome32 o ON o.k=d.k
),
outcome34 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome33 d WHERE d.truth>0 AND NOT (d.u0)
),
outcome35 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0 FROM outcome34 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE n.kind IN (118)
),
outcome36 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome35 d
),
outcome37 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (118) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome36 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome38 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome37 d
),
outcome39 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,d.c0 AS c0 FROM outcome38 d WHERE d.truth>0 AND NOT (d.u0)
),
outcome40 AS MATERIALIZED (
SELECT d.k AS parent,n.file,n.prev AS node,1 AS distance FROM outcome39 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node WHERE n.prev IS NOT NULL UNION ALL SELECT w.parent,n.file,n.prev,w.distance+1 FROM outcome40 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.prev IS NOT NULL
),
outcome41 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,w.distance AS rank,d.c0 AS c0 FROM outcome40 w JOIN outcome39 d ON d.k=w.parent CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.kind IN (113,163)
),
outcome42 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,0 AS u0 FROM outcome41 d
),
outcome43 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome42 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome44 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.node ELSE d.c0 END AS c0,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome43 d
),
outcome45 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN (n.kind IN (163)) OR (n.kind IN (113)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome44 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome46 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.u0 FROM outcome45 d
),
outcome47 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome46 s
),
outcome48 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome41 d JOIN outcome47 o ON o.k=d.k WHERE o.truth<>0
),
outcome49 AS MATERIALIZED (
SELECT * FROM outcome48 WHERE choice=1
),
outcome50 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome39 d LEFT JOIN outcome49 o ON o.parent=d.k
),
outcome51 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(o.work,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN o.truth<0 THEN o.truth WHEN d.truth=0 OR o.truth=0 THEN 0 WHEN d.truth=2 OR o.truth=2 THEN 2 ELSE 1 END AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0,(d.u0 OR o.truth=2 OR (o.k IS NULL AND d.truth<>0)) AS u0 FROM outcome38 d LEFT JOIN outcome50 o ON o.k=d.k
),
outcome52 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome51 s
),
outcome53 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome35 d JOIN outcome52 o ON o.k=d.k WHERE o.truth<>0
),
outcome54 AS MATERIALIZED (
SELECT * FROM outcome53 WHERE choice=1
),
outcome55 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome34 d LEFT JOIN outcome54 o ON o.parent=d.k
),
outcome56 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(o.work,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN o.truth<0 THEN o.truth WHEN d.truth=0 OR o.truth=0 THEN 0 WHEN d.truth=2 OR o.truth=2 THEN 2 ELSE 1 END AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0,(d.u0 OR o.truth=2 OR (o.k IS NULL AND d.truth<>0)) AS u0 FROM outcome33 d LEFT JOIN outcome55 o ON o.k=d.k
),
outcome57 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome56 s
)
-- final matches
SELECT 0,d.file,d.node,json_array(o.c0) FROM outcome0 d JOIN outcome57 o ON o.k=d.k WHERE o.truth=1 ORDER BY d.file,d.node