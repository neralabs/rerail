WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM r4 AS seed0 CROSS JOIN node AS a0n0 ON a0n0.file=seed0.file AND a0n0.id=seed0.node WHERE a0n0.kind IN (140)
),
-- utility[0]
r1(file,node) AS MATERIALIZED (
SELECT a1n0.file,a1n0.id FROM node AS a1n1 CROSS JOIN node AS a1n0 ON a1n0.file=a1n1.file AND a1n0.parent=a1n1.id CROSS JOIN node AS a1n2 ON a1n2.file=a1n0.file AND a1n2.id=a1n0.prev WHERE NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit2 CROSS JOIN node AS a2n1 ON a2n1.file=a1n0.file AND a2n1.id=a1n0.next WHERE node_regex(1,a2n1.file,a2n1.id))) AND a1n1.kind IN (140) AND node_regex(2,a1n2.file,a1n2.id)
UNION
SELECT a3n0.file,a3n0.id FROM r1 AS seed3 CROSS JOIN node AS a3n1 ON a3n1.file=seed3.file AND a3n1.id=seed3.node CROSS JOIN node AS a3n0 ON a3n0.file=a3n1.file AND a3n0.parent=a3n1.id WHERE NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit4 CROSS JOIN node AS a4n1 ON a4n1.file=a3n0.file AND a4n1.id=a3n0.prev WHERE a4n1."end">a4n1.start)) AND a3n1.kind IN (186)
UNION
SELECT a5n0.file,a5n0.id FROM r1 AS seed5 CROSS JOIN node AS a5n1 ON a5n1.file=seed5.file AND a5n1.id=seed5.node CROSS JOIN node AS a5n0 ON a5n0.file=a5n1.file AND a5n0.parent=a5n1.id WHERE a5n1.kind IN (226)
),
-- descendant predicate
r2(file,node) AS MATERIALIZED (
SELECT a6n0.file,a6n0.id FROM r1 AS seed6 CROSS JOIN node AS a6n0 ON a6n0.file=seed6.file AND a6n0.id=seed6.node WHERE a6n0.kind IN (218) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit7 CROSS JOIN node AS a7n1 ON a7n1.file=a6n0.file AND a7n1.parent=a6n0.id WHERE NOT ((node_regex(0,a7n1.file,a7n1.id) OR a7n1.kind IN (99)))))
),
-- traversal stop
r3(file,node) AS MATERIALIZED (
SELECT a10n0.file,a10n0.id FROM node AS a10n0 WHERE a10n0.kind IN (161)
),
-- inverse descendant closure
r4(file,node) AS MATERIALIZED (SELECT n.file,n.parent FROM r2 seed CROSS JOIN node n ON n.file=seed.file AND n.id=seed.node WHERE n.parent IS NOT NULL UNION SELECT n.file,n.parent FROM r4 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.parent IS NOT NULL AND NOT EXISTS (SELECT 1 FROM r3 s WHERE s.file=w.file AND s.node=w.node))
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node