//! Worked examples kept within the structural compiler's supported code-rule surface.

use crate::code_rule_dsl::test_support::*;
use serde_json::{Value, json};

const NO_UNUSED_VARS: &str =
    crate::code_rule_dsl::oracle!("ecma/compile/examples/eslint-no-unused-vars.json");
const A005: &str = crate::code_rule_dsl::oracle!("python/compile/examples/ruff-A005.json");

fn configured(source: &str, config: Value) -> crate::code_rule_dsl::CompiledCodeRuleDsl {
    let mut document: Value = serde_json::from_str(source).expect("example");
    let define = document["clauses"]
        .as_array_mut()
        .expect("checks")
        .iter_mut()
        .find(|clause| clause["define"].get("options").is_some())
        .expect("an options define");
    define["define"]["config"] = config;
    compile_document_with(
        document,
        &serde_json::from_str::<Value>(CAPABILITIES).expect("capabilities"),
    )
    .unwrap_or_else(|error| panic!("{}", error.reason))
}

fn messages(
    compiled: &crate::code_rule_dsl::CompiledCodeRuleDsl,
    language: &str,
    path: &str,
    source: &str,
) -> Vec<String> {
    let result = evaluate_file(compiled, language, path, source);
    assert_eq!(result["failures"], json!([]), "{result}");
    result["violations"]
        .as_array()
        .expect("findings")
        .iter()
        .map(|violation| violation["message"].as_str().expect("message").to_owned())
        .collect()
}

#[test]
fn no_unused_vars_is_one_document_configured_per_variant() {
    assert_eq!(
        messages(
            &configured(NO_UNUSED_VARS, json!({ "enabled": true })),
            "typescript",
            "a.ts",
            "const a = 1; let b = 2;\n",
        ),
        ["variable declaration", "variable declaration"],
    );
}

#[test]
fn a005_takes_its_scope_and_allowed_modules_from_options() {
    let compiled = configured(A005, json!({ "enabled": true }));
    assert!(compiled.in_scope("src/module.py".to_owned()));
    assert!(!compiled.in_scope("src/module.ts".to_owned()));
    assert_eq!(
        messages(&compiled, "python", "src/module.py", "x = 1\n"),
        ["module assignment"],
    );
}
