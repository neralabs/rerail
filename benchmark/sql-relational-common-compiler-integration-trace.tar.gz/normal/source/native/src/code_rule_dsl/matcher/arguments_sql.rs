//! The arguments a SQL call passes, as PostgreSQL 18.6's parser (`gram.y`, `func_arg_list`,
//! `func_arg_expr`, `extract_list`, `position_list`, `substr_list`, `overlay_list`, `trim_list`)
//! reads them, over the DerekStride grammar's `invocation`, and the signature slots they fill.

use super::{Arguments, Passed};
use crate::code_rule_dsl::value::sql;
use ast_grep_core::{Doc, Node};
use std::collections::BTreeSet;

/// The grammar's call node: an `object_reference` callee, then `parameter:` children.
pub(crate) const SQL_CALL_KINDS: &[&str] = &["invocation"];

/// One argument of a call.
pub(crate) struct SqlArgument<'r, D: Doc> {
    /// A named argument's name as PostgreSQL stores it (`name => v` and `name := v`).
    pub(crate) name: Option<String>,
    /// The argument's expression: a `term`'s `value`, a named argument's `value`.
    pub(crate) value: Node<'r, D>,
}

/// The arguments of `call`, an `invocation`, in the order PostgreSQL passes them.
///
/// * `DISTINCT`/`ALL`, `ORDER BY` and `FILTER (...)` are not arguments and are skipped, as are
///   comments and the keywords of the SQL-syntax forms.
/// * A leading `ALL` (read by the grammar as a unary operator) is dropped from the first argument.
/// * `count(*)` passes no arguments (`Some(vec![])`): `FuncCall.agg_star` carries the star.
/// * `extract(unit FROM x)` passes the unit first (`unit:` child, then the bare `term` `x`).
/// * `position(sub IN str)` and `trim([both|leading|trailing] chars FROM str)` are written in the
///   opposite order to the call PostgreSQL builds (`position_list: b_expr IN_P b_expr` gives
///   `list_make2($3, $1)`, `TRIM ... trim_list: a_expr FROM expr_list` gives
///   `lappend($3, $1)`), so their two operands are swapped to `(str, sub)`. `overlay` operands
///   keep their source order, as do `substring`'s written `FROM m FOR n`.
/// * `substring(s FOR n)` passes `(s, 1, n)` (`substr_list: a_expr FOR a_expr` gives
///   `list_make3($1, makeIntConst(1, -1), $3)`): its start is a constant no source holds, so the
///   arguments do not read (`None`). `substring(s FOR n FROM m)`, which PostgreSQL passes as
///   `(s, m, n)`, is a parse error in the grammar, so it is `None` too.
/// * `VARIADIC x`: the grammar reads it as a `field` named `VARIADIC` with `x` as its `alias`.
///   The `VARIADIC` marker is dropped and the argument is `x` (the alias identifier), positioned
///   last as PostgreSQL does (`func_arg_list` keeps it in place, `variadic` only flags the call).
///   Only the single-identifier operand is read that way; the grammar errors on other operands,
///   and then the result is `None` for the unreadable shape rather than a guess.
///
/// `None` when an argument is not one of those shapes (a parse error inside the call).
pub(crate) fn sql_arguments<'r, D: Doc>(call: &Node<'r, D>) -> Option<Vec<SqlArgument<'r, D>>> {
    if call.kind() != "invocation" || call.children().any(|child| child.is_error()) {
        return None;
    }
    let has = |kind: &str| call.children().any(|child| child.kind() == kind);
    if is_named(call, "substring") && has("keyword_for") && !has("keyword_from") {
        return None;
    }
    let mut operands: Vec<Node<'r, D>> = call
        .field_children("parameter")
        .chain(call.field_children("unit"))
        .collect();
    // `extract(unit FROM source)`: the source is a bare `term` child, not a `parameter:`.
    for child in call.children() {
        if child.kind() == "term" && operands.iter().all(|o| o.range() != child.range()) {
            operands.push(child);
        }
    }
    operands.sort_by_key(|operand| operand.range().start);

    let mut arguments = Vec::with_capacity(operands.len());
    for operand in &operands {
        arguments.push(read_operand(operand)?);
    }
    if let Some(first) = arguments.first_mut()
        && let Some(operand) = all_quantified_operand(&first.value)
    {
        first.value = operand;
    }
    if is_swapped_form(call, arguments.len()) {
        arguments.swap(0, 1);
    }
    if arguments.len() == 1 && is_star(&operands[0]) {
        arguments.clear();
    }
    Some(arguments)
}

impl Arguments {
    /// What a SQL call passes for each slot, as PostgreSQL binds a call's arguments to a
    /// function's parameters (`ParseFuncOrColumn`, `FuncnameGetCandidates`): positional arguments
    /// fill the slots in order, a named argument (`name => v`, `name := v`) the slot of its name
    /// (PostgreSQL's folded name, as a slot is written). Every slot is unknown where PostgreSQL
    /// refuses the call (a positional argument after a named one, a name passed twice or
    /// for a slot a position already filled) or the arguments do not read (`sql_arguments`).
    pub(crate) fn sql<'r, D: Doc>(&self, call: &Node<'r, D>) -> Vec<Passed<'r, D>> {
        let unknown = || (0..self.slots.len()).map(|_| Passed::Unknown).collect();
        let Some(arguments) = sql_arguments(call) else {
            return unknown();
        };
        let mut passed: Vec<Passed<'r, D>> =
            (0..self.slots.len()).map(|_| Passed::Absent).collect();
        let mut names = BTreeSet::new();
        let mut position = 0;
        for argument in arguments {
            match argument.name {
                Some(name) => {
                    let slot = self.slots.iter().position(|(slot, _)| *slot == name);
                    if !names.insert(name) {
                        return unknown();
                    }
                    if let Some(slot) = slot {
                        if !matches!(passed[slot], Passed::Absent) {
                            return unknown();
                        }
                        passed[slot] = Passed::Value(argument.value);
                    }
                }
                None if !names.is_empty() => return unknown(),
                None => {
                    if let Some(slot) = passed.get_mut(position) {
                        *slot = Passed::Value(argument.value);
                    }
                    position += 1;
                }
            }
        }
        passed
    }
}

fn read_operand<'r, D: Doc>(operand: &Node<'r, D>) -> Option<SqlArgument<'r, D>> {
    match operand.kind().as_ref() {
        "named_argument" => Some(SqlArgument {
            name: sql::node_name(&operand.field("name")?),
            value: operand.field("value")?,
        })
        .filter(|argument| argument.name.is_some()),
        "term" => {
            if let Some(alias) = operand.field("alias") {
                let marker = operand.field("value")?;
                let is_variadic = marker.kind() == "field"
                    && marker.text().eq_ignore_ascii_case("variadic")
                    && alias.kind() == "identifier";
                return is_variadic.then_some(SqlArgument {
                    name: None,
                    value: alias,
                });
            }
            Some(SqlArgument {
                name: None,
                value: operand.field("value")?,
            })
        }
        "object_reference" | "literal" => Some(SqlArgument {
            name: None,
            value: operand.clone(),
        }),
        _ => None,
    }
}

/// `f(ALL a)`: the grammar reads the leading `ALL` as a unary operator on the first argument.
fn all_quantified_operand<'r, D: Doc>(value: &Node<'r, D>) -> Option<Node<'r, D>> {
    (value.kind() == "unary_expression"
        && value
            .field("operator")
            .is_some_and(|op| op.kind() == "keyword_all"))
    .then(|| value.field("operand"))
    .flatten()
}

/// `count(*)`: a lone `*` term.
fn is_star<D: Doc>(operand: &Node<'_, D>) -> bool {
    operand.kind() == "term"
        && operand.field("value").is_some_and(|value| {
            value.kind() == "all_fields" && value.children().all(|c| !c.is_named())
        })
}

/// `position(a IN b)` and `trim(... a FROM b)`, whose two operands PostgreSQL passes as `(b, a)`.
fn is_swapped_form<D: Doc>(call: &Node<'_, D>, count: usize) -> bool {
    if count != 2 {
        return false;
    }
    let has = |kind: &str| call.children().any(|child| child.kind() == kind);
    if has("keyword_in") {
        return true;
    }
    has("keyword_from") && is_named(call, "trim")
}

/// Whether `call`'s callee is the unqualified function `name`.
fn is_named<D: Doc>(call: &Node<'_, D>, name: &str) -> bool {
    call.field("function")
        .or_else(|| call.children().next())
        .and_then(|callee| sql::node_name(&callee.field("name")?))
        .is_some_and(|callee| callee == name)
}

#[cfg(test)]
mod tests {
    use super::*;
    use crate::code_rule_dsl::language::GrammarDialect;
    use ast_grep_language::LanguageExt;
    use serde_json::Value as Json;

    /// 1-based line and 1-based code point column of a byte offset.
    fn position(source: &str, byte: usize) -> (u64, u64) {
        let before = &source[..byte];
        let line = before.matches('\n').count() as u64 + 1;
        let start = before.rfind('\n').map_or(0, |i| i + 1);
        (line, before[start..].chars().count() as u64 + 1)
    }

    /// Oracle calls the grammar does not read as an `invocation`, by (name, line): none; the
    /// oracle holds no `cast` (PostgreSQL's TypeCast is not a FuncCall).
    const MISMATCHES: &[(&str, u64, &str)] = &[];

    /// Oracle calls whose arguments the grammar errors on, by (name, line), so `sql_arguments`
    /// is `None`: `substring(s FOR 2 FROM 1)`.
    const UNREADABLE: &[(&str, u64)] = &[("substring", 22)];

    #[test]
    fn matches_postgres_oracle() {
        let dir = std::path::Path::new(crate::code_rule_dsl::fixtures_dir!())
            .join("sql/matcher/arguments");
        let source = std::fs::read_to_string(dir.join("postgres.sql")).unwrap();
        let oracle: Json = serde_json::from_str(
            &std::fs::read_to_string(dir.join("postgres.expected.json")).unwrap(),
        )
        .unwrap();
        let grep = GrammarDialect::Sql.ast_grep(&source);
        let root = grep.root();
        let invocations: Vec<_> = root.dfs().filter(|n| n.kind() == "invocation").collect();

        let (mut matched, mut skipped) = (0, 0);
        for call in oracle["calls"].as_array().unwrap() {
            let at = (
                call["line"].as_u64().unwrap(),
                call["column"].as_u64().unwrap(),
            );
            let found = invocations
                .iter()
                .find(|n| position(&source, n.range().start) == at);
            let Some(node) = found else {
                assert!(
                    MISMATCHES.iter().any(|(name, line, _)| {
                        *line == at.0 && call["name"][0].as_str() == Some(name)
                    }),
                    "no invocation at {at:?}: {call}"
                );
                skipped += 1;
                continue;
            };
            let expected = call["args"].as_array().unwrap();
            // An argument PostgreSQL supplies (`substring(s FOR n)`'s start) has no source, and a
            // call the grammar errors in has no operands to read: either way every slot is unknown.
            let unreadable = UNREADABLE
                .iter()
                .any(|(name, line)| *line == at.0 && call["name"][0].as_str() == Some(name));
            if unreadable || expected.iter().any(|want| want["implicit"] == true) {
                assert!(
                    sql_arguments(node).is_none(),
                    "arguments read at {at:?}: {call}"
                );
                matched += 1;
                continue;
            }
            let arguments = sql_arguments(node).unwrap_or_else(|| panic!("None at {at:?}"));
            assert_eq!(arguments.len(), expected.len(), "count at {at:?}: {call}");
            for (argument, want) in arguments.iter().zip(expected) {
                let got_value = position(&source, argument.value.range().start);
                let want_value = (
                    want.get("valueLine")
                        .unwrap_or(&want["line"])
                        .as_u64()
                        .unwrap(),
                    want.get("valueColumn")
                        .unwrap_or(&want["column"])
                        .as_u64()
                        .unwrap(),
                );
                assert_eq!(got_value, want_value, "value at {at:?}: {want}");
                assert_eq!(
                    argument.name.as_deref(),
                    want.get("name").and_then(Json::as_str),
                    "name at {at:?}: {want}"
                );
            }
            matched += 1;
        }
        eprintln!("matched {matched}, mismatches {skipped}");
        assert_eq!(skipped, MISMATCHES.len());
        assert!(matched > 40);
    }

    #[test]
    fn comments_and_keywords_are_not_arguments() {
        let grep = GrammarDialect::Sql.ast_grep("SELECT f(DISTINCT a, /* c */ b ORDER BY a)");
        let call = grep
            .root()
            .dfs()
            .find(|n| n.kind() == "invocation")
            .unwrap();
        let values: Vec<_> = sql_arguments(&call)
            .unwrap()
            .iter()
            .map(|a| a.value.text().to_string())
            .collect();
        assert_eq!(values, ["a", "b"]);
    }
}
