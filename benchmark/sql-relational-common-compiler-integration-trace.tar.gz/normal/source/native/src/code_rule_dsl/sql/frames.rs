//! Frames in Rust memory (`docs/sql-set-composition-design.md`, "Speed levers", lever 2): a
//! session's frame and stage tables are instances of the `frame` virtual table, columnar buffers
//! the session owns, instead of TEMP B-trees. A statement appends to a frame through `xUpdate`
//! (`INSERT … SELECT`) and reads it through `xFilter`: a scan in the table's key order, or an
//! equality lookup through an index built on the frame's first read constrained on those columns
//! and kept until the frame is written again. The driver empties a frame directly (`CLEAR`), and
//! an emptied frame keeps its buffers for the next batch, up to `RETAIN` rows.
//!
//! Each frame is an eponymous virtual table: a module registered under the frame's name, whose
//! declaration the module's data carries (`FrameStore::register`). Creating one writes nothing to
//! the schema, so a session's setup takes time linear in its tables; a `CREATE TABLE` would scan
//! the whole schema to parse its own entry, and setup would grow with the square of the tables.
//!
//! A frame keeps the B-tree semantics the statements rely on:
//! - an `INTEGER PRIMARY KEY` column is the rowid: a NULL takes the largest key so far plus one,
//!   a key is unique, and scans run in key order;
//! - a table `PRIMARY KEY (…)` is unique, and scans run in its order;
//! - any other table scans in insertion order;
//! - column types (affinity) and `DEFAULT`s are declared, so SQLite applies them as before.
//!
//! No constraint is omitted: SQLite checks every row a lookup returns, so a lookup only has to
//! return every row SQLite's comparison would accept. It compares as SQLite does across storage
//! classes (NULL, numbers, text, blobs), with numeric affinity on a probe of an `INTEGER` column.
//!
//! Only tables that statements append to and empty whole are frames (`exec`): a table some
//! statement updates or deletes from by a condition stays a B-tree.

mod frontier;

use super::nodes::integer;
use rusqlite::types::{ToSqlOutput, Value, ValueRef};
use rusqlite::vtab::{
    Context, CreateVTab, Filters, IndexConstraintOp, IndexFlags, IndexInfo, Inserts, Module,
    UpdateVTab, Updates, VTab, VTabConnection, VTabCursor, VTabKind, sqlite3_vtab,
    sqlite3_vtab_cursor,
};
use rusqlite::{Connection, Error, Result};
use std::borrow::Cow;
use std::cell::{RefCell, UnsafeCell};
use std::cmp::Ordering;
use std::collections::HashMap;
use std::ffi::{CStr, CString, c_int};
use std::marker::PhantomData;
use std::rc::Rc;
use std::sync::Arc;
use std::sync::atomic::{AtomicUsize, Ordering as Atomic};

#[cfg(feature = "unbounded-work")]
thread_local! { static SELECTION_TRACE: RefCell<Option<(String, [i64; 4])>> = const { RefCell::new(None) }; }
#[cfg(feature = "unbounded-work")]
pub(super) fn take_selection_trace() -> Option<(String, [i64; 4])> {
    SELECTION_TRACE.take()
}

/// A step that empties the frame it names (`CLEAR` then the table's name): the driver runs it on
/// the frame's buffers instead of a `DELETE`.
pub(super) const CLEAR: &str = "/*CLEAR*/";

/// A step that makes a frame (`FRAME` then the table's name and its declaration in parentheses:
/// the column definitions and table constraints of the `CREATE TABLE` it stands for, then its
/// indexes as `INDEX (…)`): the driver registers it (`FrameStore::register`).
pub(super) const FRAME: &str = "/*FRAME*/";

/// The most rows a session's frames hold at once: a batch that would hold more fails.
pub(super) const BUDGET: usize = 1 << 26;

/// The rows a frame's buffers keep across batches; a frame that held more frees the rest when
/// the batch ends.
const RETAIN: usize = 1 << 16;

/// The `xBestIndex` cost of a full scan: a stat-less B-tree's row estimate, so that plans weigh
/// a frame as they weighed its table.
const SCAN_COST: f64 = 1_048_576.0;

/// The table a statement's text names after `prefix`, up to a space or parenthesis.
fn table_after<'s>(sql: &'s str, prefix: &str) -> Option<&'s str> {
    let rest = sql.strip_prefix(prefix)?;
    rest.split([' ', '('])
        .next()
        .filter(|name| !name.is_empty())
}

/// A stage's or clause's statements with its frames in Rust memory: each table they create that
/// no statement updates or deletes from by a condition becomes a `FRAME` step, its indexes
/// `INDEX (…)` entries of its declaration (the plans weigh them as before; a frame builds an
/// index on its first read on those columns), and emptying it whole becomes a `CLEAR` step.
pub(super) fn rewrite(statements: Vec<String>) -> Vec<String> {
    let mut mutated: std::collections::HashSet<String> = std::collections::HashSet::new();
    // Each table's indexed columns, as `INDEX (…)` arguments.
    let mut indexes: HashMap<String, String> = HashMap::new();
    for sql in &statements {
        mutated.extend(table_after(sql, "UPDATE ").map(str::to_owned));
        if let Some(name) = table_after(sql, "DELETE FROM ")
            && sql.len() > "DELETE FROM ".len() + name.len()
        {
            mutated.insert(name.to_owned());
        }
        if sql.starts_with("CREATE INDEX ")
            && let Some((_, on)) = sql.split_once(" ON ")
            && let Some((name, columns)) = on.split_once('(')
        {
            let columns = columns.trim_end().trim_end_matches(')');
            indexes
                .entry(name.trim().to_owned())
                .or_default()
                .push_str(&format!(", INDEX ({columns})"));
        }
    }
    let mut frames = std::collections::HashSet::new();
    let mut rewritten = Vec::with_capacity(statements.len());
    for sql in statements {
        if let Some(rest) = sql.strip_prefix("CREATE TEMP TABLE ") {
            let rest = rest.strip_prefix("IF NOT EXISTS ").unwrap_or(rest);
            if let (Some(open), Some(close)) = (rest.find('('), rest.rfind(')'))
                && rest[close + 1..].trim().is_empty()
            {
                let name = rest[..open].trim();
                // A column default keeps the B-tree: SQLite passes an omitted column as NULL.
                if !mutated.contains(name) && !rest.contains(" DEFAULT ") {
                    let frame = format!(
                        "{FRAME}{name}({}{})",
                        &rest[open + 1..close],
                        indexes.get(name).map_or("", String::as_str)
                    );
                    frames.insert(name.to_owned());
                    rewritten.push(frame);
                    continue;
                }
            }
        }
        if sql.starts_with("CREATE INDEX ")
            && let Some((_, on)) = sql.split_once(" ON ")
            && let Some(name) = on.split([' ', '(']).next()
            && frames.contains(name)
        {
            continue;
        }
        if let Some(name) = sql.strip_prefix("DELETE FROM ")
            && frames.contains(name)
        {
            rewritten.push(format!("{CLEAR}{name}"));
            continue;
        }
        rewritten.push(sql);
    }
    rewritten
}

/// The frames of one session's connection, by table name.
#[derive(Default)]
pub(super) struct FrameStore {
    frames: parking_lot::Mutex<HashMap<String, Arc<Shared>>>,
    /// Rows held across every frame.
    live: AtomicUsize,
    /// The most rows held at once since the store was made.
    peak: AtomicUsize,
    retained: Arc<AtomicUsize>,
    selections: parking_lot::Mutex<HashMap<String, Option<Selection>>>,
}

/// The `frame` module: every frame is an eponymous table of its own registration of it.
const MODULE: Module<'static, FrameTable> = Module::update_module();

/// What a frame's module registration carries: the frame, and the store that counts its rows.
pub(super) struct FrameAux {
    store: Arc<FrameStore>,
    shared: Arc<Shared>,
    schema: CString,
}

/// Positions outside parentheses and quoted SQL tokens. Clause and argument splitting must
/// use the same scope rules: a FROM inside a literal or subquery is not the projection's source.
fn top_level(text: &str) -> impl Iterator<Item = usize> + '_ {
    let (mut depth, mut quote, mut escaped) = (0usize, 0u8, false);
    text.bytes().enumerate().filter_map(move |(at, byte)| {
        if escaped {
            escaped = false;
            return None;
        }
        if quote != 0 {
            if byte == quote {
                if text.as_bytes().get(at + 1) == Some(&quote) {
                    escaped = true;
                } else {
                    quote = 0;
                }
            }
            return None;
        }
        match byte {
            b'\'' | b'"' | b'`' => {
                quote = byte;
                None
            }
            b'[' => {
                quote = b']';
                None
            }
            b'(' => {
                depth += 1;
                None
            }
            b')' => {
                depth = depth.saturating_sub(1);
                None
            }
            _ => (depth == 0).then_some(at),
        }
    })
}

/// `text` split at top-level commas, as SQLite splits a virtual table's arguments.
fn arguments(text: &str) -> Vec<&str> {
    let mut parts = Vec::new();
    let mut from = 0;
    for at in top_level(text).filter(|&at| text.as_bytes()[at] == b',') {
        parts.push(text[from..at].trim());
        from = at + 1;
    }
    parts.push(text[from..].trim());
    parts.retain(|part| !part.is_empty());
    parts
}

/// A projection that preserves source row keys. SQLite still evaluates the predicate.
/// Joined filters and computed captures share the direct columns; SQLite evaluates expressions.
/// Generated keys and affinity changes retain ordinary insertion.
/// Duplicate keys retain ordinary insertion semantics.
enum Projection<T> {
    Column(T),
    Constant(Option<i64>),
    Expression(usize),
}

struct Selection {
    target: String,
    source: String,
    columns: Vec<Projection<String>>,
    query: String,
    identity: bool,
}
impl Selection {
    fn parse(sql: &str) -> Option<Self> {
        let (target, select) = sql.strip_prefix("INSERT INTO ")?.split_once(" SELECT ")?;
        let at = top_level(select).find(|&at| select.as_bytes()[at..].starts_with(b" FROM "))?;
        let (columns, from) = (&select[..at], &select[at + " FROM ".len()..]);
        let (source, tail) = from.split_once(' ')?;
        let alias = tail.split_whitespace().next()?;
        let projection_upper = columns.to_ascii_uppercase();
        if [
            " UNION ",
            " GROUP ",
            " ORDER ",
            " LIMIT ",
            " RIGHT JOIN ",
            " FULL JOIN ",
        ]
        .iter()
        .any(|part| from.contains(part))
        {
            return None;
        }
        if [
            "DISTINCT ",
            "SELECT ",
            " OVER ",
            "COUNT(",
            "SUM(",
            "MIN(",
            "MAX(",
            "AVG(",
            "TOTAL(",
            "GROUP_CONCAT(",
        ]
        .iter()
        .any(|part| projection_upper.contains(part))
        {
            return None;
        }
        let mut expressions = String::new();
        let mut expression_index = 0;
        let columns = arguments(columns)
            .into_iter()
            .map(|column| {
                if column == "NULL" {
                    return Projection::Constant(None);
                }
                if let Ok(value) = column.parse::<i64>() {
                    return Projection::Constant(Some(value));
                }
                if let Some(name) = column.strip_prefix(&format!("{alias}."))
                    && !name.is_empty()
                    && name.bytes().all(|c| c.is_ascii_alphanumeric() || c == b'_')
                {
                    return Projection::Column(name.to_owned());
                }
                expression_index += 1;
                expressions.push_str(", ");
                expressions.push_str(column);
                Projection::Expression(expression_index)
            })
            .collect::<Vec<_>>();
        if !matches!(columns.first(), Some(Projection::Column(name)) if name == "k") {
            return None;
        }
        Some(Self {
            target: target.into(),
            source: source.into(),
            columns,
            query: format!("SELECT {alias}.rowid{expressions} FROM {from}"),
            identity: tail == alias && expressions.is_empty(),
        })
    }
}

impl Column {
    fn view(
        &mut self,
        selected: Option<&Arc<[u32]>>,
        retained: &Arc<AtomicUsize>,
        composed: &mut HashMap<usize, Arc<[u32]>>,
    ) -> Option<Self> {
        if !self.data.is_shared() {
            let bytes = self.nulls.capacity() * 8
                + match &self.data {
                    Data::Narrow(v) => v.capacity() * 4,
                    Data::Wide(v) => v.capacity() * 8,
                    Data::Any(v) => {
                        v.capacity() * std::mem::size_of::<Value>()
                            + v.iter()
                                .map(|v| match v {
                                    Value::Text(s) => s.capacity(),
                                    Value::Blob(b) => b.capacity(),
                                    _ => 0,
                                })
                                .sum::<usize>()
                    }
                    _ => unreachable!(),
                };
            retained
                .fetch_update(Atomic::Relaxed, Atomic::Relaxed, |n| {
                    n.checked_add(bytes).filter(|n| *n <= BUDGET * 8)
                })
                .ok()?;
            let data = std::mem::replace(&mut self.data, Data::Narrow(Vec::new()));
            let nulls = std::mem::take(&mut self.nulls);
            self.data = match data {
                Data::Narrow(values) => Data::SharedNarrow(
                    Arc::new(Page {
                        values,
                        nulls,
                        retained: Arc::clone(retained),
                        bytes,
                    }),
                    None,
                ),
                Data::Wide(values) => Data::SharedWide(
                    Arc::new(Page {
                        values,
                        nulls,
                        retained: Arc::clone(retained),
                        bytes,
                    }),
                    None,
                ),
                Data::Any(values) => Data::SharedAny(
                    Arc::new(Page {
                        values,
                        nulls,
                        retained: Arc::clone(retained),
                        bytes,
                    }),
                    None,
                ),
                _ => unreachable!(),
            };
        }
        let mut selected_rows = |rows: &Option<Arc<[u32]>>| match (selected, rows) {
            (None, rows) => rows.clone(),
            (Some(selected), None) => Some(Arc::clone(selected)),
            (Some(selected), Some(rows)) => Some(Arc::clone(
                composed
                    .entry(Arc::as_ptr(rows) as *const u32 as usize)
                    .or_insert_with(|| {
                        selected
                            .iter()
                            .map(|&row| rows[row as usize])
                            .collect::<Vec<_>>()
                            .into()
                    }),
            )),
        };
        let data = match &self.data {
            Data::SharedNarrow(page, rows) => {
                Data::SharedNarrow(Arc::clone(page), selected_rows(rows))
            }
            Data::SharedWide(page, rows) => Data::SharedWide(Arc::clone(page), selected_rows(rows)),
            Data::SharedAny(page, rows) => Data::SharedAny(Arc::clone(page), selected_rows(rows)),
            _ => unreachable!(),
        };
        Some(Self {
            data,
            nulls: Vec::new(),
            integer: self.integer,
            default: self.default,
        })
    }
}

impl FrameStore {
    /// Execute a proved key-preserving projection as a selection over immutable pages.
    /// Returns None for SQL shapes or frame states that require ordinary insertion.
    pub(super) fn select(&self, connection: &Connection, sql: &str) -> Result<Option<usize>> {
        #[cfg(feature = "unbounded-work")]
        SELECTION_TRACE.set(None);
        let mut cached = self.selections.lock();
        if !cached.contains_key(sql) {
            cached.insert(sql.to_owned(), Selection::parse(sql));
        }
        let Some(selection) = cached.get(sql).and_then(Option::as_ref) else {
            return Ok(None);
        };
        let frames = self.frames.lock();
        let (Some(source), Some(target)) =
            (frames.get(&selection.source), frames.get(&selection.target))
        else {
            return Ok(None);
        };
        if Arc::ptr_eq(source, target) {
            return Ok(None);
        }
        let (source, target) = (Arc::clone(source), Arc::clone(target));
        drop(frames);
        let input = source.get();
        let output = target.get();
        if input.key != Key::Rowid(0)
            || output.key != Key::Rowid(0)
            || output.len != 0
            || output.columns.len() != selection.columns.len()
            || !input.ascending
        {
            return Ok(None);
        }
        let Some(columns) = selection
            .columns
            .iter()
            .map(|column| match column {
                Projection::Column(name) => input
                    .names
                    .iter()
                    .position(|c| c == name)
                    .map(Projection::Column),
                Projection::Constant(value) => Some(Projection::Constant(*value)),
                Projection::Expression(index) => Some(Projection::Expression(*index)),
            })
            .collect::<Option<Vec<_>>>()
        else {
            return Ok(None);
        };
        if columns
            .iter()
            .zip(&output.columns)
            .any(|(column, out)| match column {
                Projection::Column(i) => {
                    input.columns[*i].integer != out.integer
                        || input.columns[*i].default != out.default
                }
                Projection::Constant(_) => false,
                Projection::Expression(_) => out.integer || out.default.is_some(),
            })
        {
            return Ok(None);
        }
        let mut computed: Vec<_> = columns
            .iter()
            .zip(&output.columns)
            .map(|(column, schema)| {
                matches!(column, Projection::Expression(_))
                    .then(|| Column::new(schema.integer, schema.default))
            })
            .collect();
        let keys = if selection.identity {
            (0..input.len)
                .map(|row| input.columns[0].integer(row))
                .collect::<Vec<_>>()
        } else {
            let mut statement = connection.prepare_cached(&selection.query)?;
            let mut keys = Vec::new();
            {
                let mut result = statement.query([])?;
                while let Some(row) = result.next()? {
                    for (column, computed) in columns.iter().zip(&mut computed) {
                        if let Projection::Expression(index) = column {
                            computed
                                .as_mut()
                                .unwrap()
                                .push(keys.len(), row.get_ref(*index)?);
                        }
                    }
                    keys.push(row.get::<_, i64>(0)?);
                }
            }
            #[cfg(feature = "unbounded-work")]
            if super::diagnostics::enabled(sql) {
                SELECTION_TRACE.set(Some((
                    selection.query.clone(),
                    super::diagnostics::counters(&statement),
                )));
            }
            drop(statement);
            keys
        };
        if keys.is_empty() {
            return Ok(Some(0));
        }
        if self.live.load(Atomic::Relaxed).saturating_add(keys.len()) > BUDGET {
            return Err(Error::ModuleError("frame: row budget exceeded".into()));
        }
        if !keys.windows(2).all(|p| p[0] < p[1]) {
            let mut sorted = keys.clone();
            sorted.sort_unstable();
            if sorted.windows(2).any(|p| p[0] == p[1]) {
                return Ok(None);
            }
        }
        let identity = keys.len() == input.len && keys.windows(2).all(|p| p[0] < p[1]);
        let rows: Option<Arc<[u32]>> = if identity {
            None
        } else {
            Some(
                keys.iter()
                    .map(|&key| {
                        if input.dense {
                            key.wrapping_sub(input.columns[0].integer(0)) as u32
                        } else {
                            partition(input.len, |row| input.columns[0].integer(row) < key) as u32
                        }
                    })
                    .collect::<Vec<_>>()
                    .into(),
            )
        };
        if rows
            .as_ref()
            .is_some_and(|rows| rows.iter().any(|&row| row as usize >= input.len))
        {
            return Err(Error::ModuleError("frame: invalid selection key".into()));
        }
        // SAFETY: the SELECT and all its cursors have completed. The frames differ.
        let input = unsafe { source.get_mut() };
        let mut projected = Vec::with_capacity(columns.len());
        let mut composed = HashMap::new();
        for ((column, schema), computed) in
            columns.into_iter().zip(&target.get().columns).zip(computed)
        {
            let projected_column = match column {
                Projection::Column(column) => {
                    match input.columns[column].view(rows.as_ref(), &self.retained, &mut composed) {
                        Some(view) => view,
                        None => return Ok(None),
                    }
                }
                Projection::Constant(value) => {
                    let mut column = Column::new(schema.integer, schema.default);
                    let value = value.or(schema.default);
                    column.data = match value {
                        Some(value) if i32::try_from(value).is_err() => {
                            Data::Wide(vec![value; keys.len()])
                        }
                        _ => Data::Narrow(vec![value.unwrap_or(0) as i32; keys.len()]),
                    };
                    if value.is_none() {
                        column.nulls = vec![u64::MAX; keys.len().div_ceil(64)];
                    }
                    column
                }
                Projection::Expression(_) => computed.unwrap(),
            };
            projected.push(projected_column);
        }
        let output = unsafe { target.get_mut() };
        output.lookups.get_mut().clear();
        *output.order.get_mut() = None;
        output.columns = projected;
        output.len = keys.len();
        output.ascending = keys.windows(2).all(|p| p[0] < p[1]);
        output.dense = keys.windows(2).all(|p| p[1].checked_sub(p[0]) == Some(1));
        output.largest = keys.iter().copied().max().unwrap_or(0);
        let live = self.live.fetch_add(keys.len(), Atomic::Relaxed) + keys.len();
        self.peak.fetch_max(live, Atomic::Relaxed);
        Ok(Some(keys.len()))
    }

    /// Reads typed pattern inputs by frame key, without a SQL-side environment copy.
    /// The callback cannot retain a reference into the frame or execute SQL on this connection.
    pub(super) fn pattern_inputs(
        &self,
        descriptor: &str,
        keys: &[i64],
        mut visit: impl FnMut(i64, u32, u32, &[Option<i64>]),
    ) -> Result<()> {
        let mut parts = descriptor.split(',');
        let name = parts.next().unwrap_or_default();
        let shared =
            self.frames.lock().get(name).cloned().ok_or_else(|| {
                Error::ModuleError(format!("pattern: missing input frame {name}"))
            })?;
        let frame = shared.get();
        if frame.columns.len() < 3 {
            return Err(Error::ModuleError(
                "pattern: input frame has no node columns".into(),
            ));
        }
        let columns = parts
            .map(|name| {
                frame
                    .names
                    .iter()
                    .position(|column| column == name)
                    .ok_or_else(|| Error::ModuleError(format!("pattern: no input column {name}")))
            })
            .collect::<Result<Vec<_>>>()?;
        let Key::Rowid(column) = frame.key else {
            return Err(Error::ModuleError(
                "pattern: input requires an integer row key".into(),
            ));
        };
        let order = if frame.ascending {
            None
        } else {
            Some(frame.lookup(&[column])?)
        };
        let mut values = Vec::with_capacity(columns.len());
        for &key in keys {
            // Borrow only while copying this row's scalar inputs. No frame reference is
            // live across the callback, which evaluates the native pattern.
            let frame = shared.get();
            let at = if let Some(order) = &order {
                let at =
                    order.partition_point(|&row| frame.columns[column].integer(row as usize) < key);
                order.get(at).copied().map(|row| row as usize)
            } else if frame.dense && frame.len > 0 {
                usize::try_from(key.wrapping_sub(frame.columns[column].integer(0))).ok()
            } else {
                Some(partition(frame.len, |row| {
                    frame.columns[column].integer(row) < key
                }))
            };
            let Some(row) =
                at.filter(|&row| row < frame.len && frame.columns[column].integer(row) == key)
            else {
                continue;
            };
            let (Some(file), Some(node)) = (
                integer(frame.columns[1].get(row)),
                integer(frame.columns[2].get(row)),
            ) else {
                continue;
            };
            let (Ok(file), Ok(node)) = (u32::try_from(file), u32::try_from(node)) else {
                continue;
            };
            values.clear();
            let mut valid = true;
            for &column in &columns {
                let value = match frame.columns[column].get(row) {
                    ValueRef::Null => None,
                    ValueRef::Integer(value) => Some(value),
                    ValueRef::Text(value) => match std::str::from_utf8(value)
                        .ok()
                        .and_then(|text| text.parse().ok())
                    {
                        Some(value) => Some(value),
                        None => {
                            valid = false;
                            break;
                        }
                    },
                    _ => {
                        valid = false;
                        break;
                    }
                };
                values.push(value);
            }
            if !valid {
                continue;
            }
            visit(key, file, node, &values);
        }
        Ok(())
    }

    /// Makes the frame a `FRAME` step declares (`declaration` is the step after the marker) on
    /// `connection`: a registration of the `frame` module under the frame's name, whose eponymous
    /// table is the frame. A frame of that name already made stays (`CREATE TABLE IF NOT
    /// EXISTS`). Returns the frame's name.
    pub(super) fn register<'d>(
        self: &Arc<Self>,
        connection: &Connection,
        declaration: &'d str,
    ) -> Result<&'d str> {
        let bad = || Error::ModuleError(format!("frame: bad declaration {declaration}"));
        let open = declaration.find('(').ok_or_else(bad)?;
        let close = declaration
            .rfind(')')
            .filter(|&close| close > open)
            .ok_or_else(bad)?;
        let name = declaration[..open].trim();
        if self.frames.lock().contains_key(name) {
            return Ok(name);
        }
        let (schema, frame) = parse(&arguments(&declaration[open + 1..close]))?;
        let shared = Arc::new(Shared(UnsafeCell::new(frame)));
        self.frames
            .lock()
            .insert(name.to_owned(), Arc::clone(&shared));
        connection.create_module(
            name,
            &MODULE,
            Some(FrameAux {
                store: Arc::clone(self),
                shared,
                schema,
            }),
        )?;
        Ok(name)
    }

    /// How many frames the store holds.
    #[cfg(test)]
    pub(super) fn len(&self) -> usize {
        self.frames.lock().len()
    }

    /// Empties frame `name`, keeping its buffers. `false` where no frame has that name.
    pub(super) fn clear(&self, name: &str) -> bool {
        let Some(shared) = self.frames.lock().get(name).cloned() else {
            return false;
        };
        // SAFETY: the connection thread serializes clear with cursor methods. No borrowed
        // frame data is live here; publication callbacks finish consuming their inputs first.
        let frame = unsafe { shared.get_mut() };
        self.live.fetch_sub(frame.len, Atomic::Relaxed);
        frame.clear();
        true
    }

    /// The rows frame `name` holds (exact: every insert and clear goes through its buffers).
    /// `None` where no frame has that name.
    pub(super) fn rows(&self, name: &str) -> Option<usize> {
        self.frames.lock().get(name).map(|shared| shared.get().len)
    }

    /// End a statement-local producer's lifetime. Its schema remains registered, while its
    /// buffers can no longer retain a whole prior operator's intermediate rows.
    pub(super) fn program_release(&self, name: &str) -> bool {
        if !self.clear(name) {
            return false;
        }
        let shared = self
            .frames
            .lock()
            .get(name)
            .cloned()
            .expect("a cleared relation");
        // SAFETY: the generated consumer has completed before the release instruction.
        let frame = unsafe { shared.get_mut() };
        for column in &mut frame.columns {
            column.data = Data::Narrow(Vec::new());
            column.nulls = Vec::new();
        }
        true
    }

    /// Publish an aggregate's completed input batch, with no nested SQL. Experiments register
    /// a separate immutable handle for each terminal demand before preparing the query.
    pub(super) fn publish_relation(&self, name: &str, rows: &[Vec<Value>]) -> Result<()> {
        let shared = self
            .frames
            .lock()
            .get(name)
            .cloned()
            .ok_or_else(|| Error::ModuleError(format!("unknown relation handle {name}")))?;
        let frame = shared.get();
        if frame.len != 0 || rows.iter().any(|row| row.len() != frame.columns.len()) {
            return Err(Error::ModuleError(format!(
                "relation {name}: {} existing rows, {} columns, incoming width {:?}",
                frame.len,
                frame.columns.len(),
                rows.first().map(Vec::len)
            )));
        }
        let key = match frame.key {
            Key::Rowid(column) => Some(column),
            _ => None,
        };
        let mut keys = std::collections::HashSet::new();
        if let Some(key) = key
            && rows
                .iter()
                .any(|row| !matches!(row.get(key),Some(Value::Integer(k)) if keys.insert(*k)))
        {
            return Err(Error::ModuleError(
                "relation keys must be unique integers".into(),
            ));
        }
        let live = self.live.fetch_add(rows.len(), Atomic::Relaxed) + rows.len();
        if live > BUDGET {
            self.live.fetch_sub(rows.len(), Atomic::Relaxed);
            return Err(Error::ModuleError("relation publication budget".into()));
        }
        self.peak.fetch_max(live, Atomic::Relaxed);
        // SAFETY: publication has its own handle, never a source CTE's handle. The scalar
        // aggregate completes before the dependent terminal opens its reader. No cursor can
        // read this handle before that dependency, and the aggregate publishes it only once.
        let frame = unsafe { shared.get_mut() };
        for (index, values) in rows.iter().enumerate() {
            for (column, value) in frame.columns.iter_mut().zip(values) {
                column.push(index, value.into());
            }
        }
        #[cfg(any(test, feature = "unbounded-work"))]
        super::profiling::frame(super::profiling::FrameEvent::Insert, rows.len());
        frame.len = rows.len();
        frame.ascending = false;
        frame.dense = false;
        frame.largest = keys.into_iter().max().unwrap_or(0);
        Ok(())
    }

    /// SQL-program storage boundary. The SELECT has consumed its inputs before its aggregate
    /// calls this method. No rule or SQL is evaluated here; it implements table append/replace.
    #[cfg(test)]
    pub(super) fn program_rows(
        &self,
        name: &str,
        mut rows: Vec<Vec<Value>>,
        replace: bool,
        ignore: bool,
    ) -> Result<usize> {
        self.program_slices(
            name,
            rows.iter_mut().map(Vec::as_mut_slice),
            replace,
            ignore,
        )
    }

    /// Apply completed SQL column deltas. Keys and predicates are evaluated in SQL before
    /// this storage callback runs, so assignments observe the same original table snapshot.
    pub(super) fn program_patch(
        &self,
        name: &str,
        columns: &[usize],
        mut chunks: Vec<Vec<Value>>,
    ) -> Result<usize> {
        let shared = self
            .frames
            .lock()
            .get(name)
            .cloned()
            .ok_or_else(|| Error::ModuleError(format!("unknown patch relation {name}")))?;
        let frame = shared.get();
        let Key::Rowid(key) = frame.key else {
            return Err(Error::ModuleError(
                "patch requires integer primary key".into(),
            ));
        };
        if columns.is_empty()
            || columns
                .iter()
                .any(|&c| c >= frame.columns.len() || c == key)
        {
            return Err(Error::ModuleError("invalid patch columns".into()));
        }
        let width = columns.len() + 1;
        if chunks.iter().any(|c| c.len() % width != 0) {
            return Err(Error::ModuleError("invalid patch chunk".into()));
        }
        let order = frame.scan_order()?;
        let mut positions = Vec::new();
        for row in chunks.iter().flat_map(|c| c.chunks_exact(width)) {
            let Value::Integer(id) = row[0] else {
                return Err(Error::ModuleError("invalid patch key".into()));
            };
            let position = if frame.ascending && frame.dense && frame.len > 0 {
                usize::try_from(id.wrapping_sub(frame.columns[key].integer(0)))
                    .unwrap_or(usize::MAX)
            } else if let Some(order) = &order {
                let at = order.partition_point(|&r| frame.columns[key].integer(r as usize) < id);
                order.get(at).map_or(usize::MAX, |&r| r as usize)
            } else {
                partition(frame.len, |r| frame.columns[key].integer(r) < id)
            };
            if position >= frame.len || frame.columns[key].integer(position) != id {
                return Err(Error::ModuleError("missing patch key".into()));
            }
            positions.push(position);
        }
        // SAFETY: the producer has reached EOF before aggregate finalization. Validation
        // above owns its ordering vector and leaves no borrowed column values alive.
        let frame = unsafe { shared.get_mut() };
        for (row, &position) in chunks
            .iter_mut()
            .flat_map(|c| c.chunks_exact_mut(width))
            .zip(&positions)
        {
            for (&column, value) in columns.iter().zip(&row[1..]) {
                frame.columns[column].set(position, frame.len, value.into());
            }
        }
        frame
            .lookups
            .borrow_mut()
            .retain(|(index, _)| !index.iter().any(|c| columns.contains(c)));
        #[cfg(any(test, feature = "unbounded-work"))]
        super::profiling::frame(
            super::profiling::FrameEvent::Update,
            positions.len() * columns.len(),
        );
        Ok(positions.len())
    }

    /// A publication buffers bounded row-aligned chunks, rather than one allocation per row.
    /// Values still belong to the aggregate until its producer cursors have reached EOF.
    pub(super) fn program_chunks(
        &self,
        name: &str,
        mut chunks: Vec<Vec<Value>>,
        width: usize,
        replace: bool,
        ignore: bool,
    ) -> Result<usize> {
        if width == 0 || chunks.iter().any(|c| !c.len().is_multiple_of(width)) {
            return Err(Error::ModuleError("program publication width".into()));
        }
        self.program_slices(
            name,
            chunks.iter_mut().flat_map(|c| c.chunks_mut(width)),
            replace,
            ignore,
        )
    }

    fn program_slices<'a>(
        &self,
        name: &str,
        rows: impl Iterator<Item = &'a mut [Value]>,
        replace: bool,
        ignore: bool,
    ) -> Result<usize> {
        let shared = self
            .frames
            .lock()
            .get(name)
            .cloned()
            .ok_or_else(|| Error::ModuleError(format!("unknown program relation {name}")))?;
        let width = shared.get().columns.len();
        if replace {
            self.clear(name);
        }
        // SAFETY: the publication aggregate owns all producer values before finalize. Source
        // cursors reached EOF; no read method is active, including at loop back-edges.
        let frame = unsafe { shared.get_mut() };
        let keys: Vec<usize> = match &frame.key {
            Key::Position => Vec::new(),
            Key::Rowid(at) => vec![*at],
            Key::Primary(columns) => columns.clone(),
        };
        fn encode<'a>(values: impl Iterator<Item = ValueRef<'a>>) -> Vec<u8> {
            let mut out = Vec::new();
            for value in values {
                let value = Probe::of(value);
                match value {
                    Probe::Null => out.push(0),
                    Probe::Integer(n) => {
                        out.push(1);
                        out.extend(n.to_le_bytes());
                    }
                    Probe::Real(n)
                        if n.fract() == 0.0 && n >= i64::MIN as f64 && n < i64::MAX as f64 =>
                    {
                        out.push(1);
                        out.extend((n as i64).to_le_bytes());
                    }
                    Probe::Real(n) => {
                        out.push(2);
                        out.extend(n.to_bits().to_le_bytes());
                    }
                    Probe::Text(s) | Probe::Blob(s) => {
                        out.push(if matches!(value, Probe::Text(_)) {
                            3
                        } else {
                            4
                        });
                        out.extend((s.len() as u64).to_le_bytes());
                        out.extend(s);
                    }
                }
            }
            out
        }
        let mut seen = std::collections::HashSet::new();
        if ignore && !keys.is_empty() {
            for row in 0..frame.len {
                seen.insert(encode(keys.iter().map(|&at| frame.columns[at].get(row))));
            }
        }
        let mut inserted = 0;
        for values in rows {
            if values.len() != width {
                return Err(Error::ModuleError(format!(
                    "program relation {name}: wrong row width"
                )));
            }
            if let Key::Rowid(at) = frame.key {
                if values[at] == Value::Null {
                    values[at] = Value::Integer(
                        frame
                            .largest
                            .checked_add(1)
                            .ok_or_else(|| Error::ModuleError("program rowid overflow".into()))?,
                    );
                }
                if let Probe::Integer(id) = Probe::of((&values[at]).into()).numeric() {
                    values[at] = Value::Integer(id);
                } else {
                    return Err(Error::ModuleError(
                        "program rowid must be an integer".into(),
                    ));
                }
            }
            if ignore
                && !keys.is_empty()
                && !seen.insert(encode(keys.iter().map(|&at| ValueRef::from(&values[at]))))
            {
                continue;
            }
            let live = self.live.fetch_add(1, Atomic::Relaxed) + 1;
            if live > BUDGET {
                self.live.fetch_sub(1, Atomic::Relaxed);
                return Err(Error::ModuleError("program relation row budget".into()));
            }
            self.peak.fetch_max(live, Atomic::Relaxed);
            let row = frame.len;
            if let Key::Rowid(at) = frame.key {
                let Value::Integer(id) = values[at] else {
                    unreachable!()
                };
                frame.ascending &= row == 0 || id > frame.largest;
                frame.dense &= row == 0 || Some(id) == frame.largest.checked_add(1);
                frame.largest = if row == 0 { id } else { frame.largest.max(id) };
            }
            for (column, value) in frame.columns.iter_mut().zip(values.iter()) {
                column.push(row, value.into());
            }
            frame.len += 1;
            inserted += 1;
        }
        frame.lookups.get_mut().clear();
        *frame.order.get_mut() = None;
        #[cfg(any(test, feature = "unbounded-work"))]
        super::profiling::frame(super::profiling::FrameEvent::Insert, inserted);
        Ok(inserted)
    }

    /// Frees what emptied frames keep beyond `RETAIN` rows: a large batch does not keep its
    /// memory for the batches after it.
    pub(super) fn trim(&self) {
        for shared in self.frames.lock().values() {
            // SAFETY: as in `clear`.
            let frame = unsafe { shared.get_mut() };
            if frame.len == 0 {
                for column in &mut frame.columns {
                    column.trim();
                }
            }
        }
    }

    /// The most rows the frames held at once.
    #[cfg(test)]
    pub(super) fn peak(&self) -> usize {
        self.peak.load(Atomic::Relaxed)
    }
}

/// A frame shared by its virtual table, its cursors and the store. A connection is used by one
/// thread at a time and SQLite calls a virtual table's methods one at a time, so a frame is
/// never written while it is read: a statement that reads the frame it inserts into reads it
/// whole first (SQLite materializes such a `SELECT`), and the driver clears frames between
/// statements. Reads borrow it for one method call only.
struct Shared(UnsafeCell<Frame>);

// SAFETY: see `Shared`: one thread at a time, and no read overlaps a write.
unsafe impl Send for Shared {}
unsafe impl Sync for Shared {}

impl Shared {
    fn get(&self) -> &Frame {
        // SAFETY: see `Shared`.
        unsafe { &*self.0.get() }
    }

    /// # Safety
    /// No other borrow of the frame is live (`Shared`).
    #[allow(clippy::mut_from_ref)]
    unsafe fn get_mut(&self) -> &mut Frame {
        unsafe { &mut *self.0.get() }
    }
}

/// How a frame's rows are identified and ordered.
#[derive(Clone, PartialEq)]
enum Key {
    /// Insertion order; the rowid is the position plus one.
    Position,
    /// An `INTEGER PRIMARY KEY` column: the rowid.
    Rowid(usize),
    /// A table `PRIMARY KEY` over these columns.
    Primary(Vec<usize>),
}

/// An index built on a frame's first read constrained on some columns: the columns, and the rows
/// sorted by them, then in scan order.
type Lookup = (Vec<usize>, Rc<[u32]>);

struct Frame {
    names: Vec<String>,
    columns: Vec<Column>,
    len: usize,
    key: Key,
    /// The column lists the table it stands for was indexed on (its key's included): plans
    /// weigh a lookup on a prefix of one as a B-tree index's.
    indexed: Vec<Vec<usize>>,
    /// `Key::Rowid`: whether the keys were appended in ascending order, and whether they are
    /// consecutive besides; the largest so far.
    ascending: bool,
    dense: bool,
    largest: i64,
    /// Indexes built since the last write.
    lookups: RefCell<Vec<Lookup>>,
    /// The scan order where the rows are not stored in it.
    order: RefCell<Option<Rc<[u32]>>>,
}

impl Frame {
    fn clear(&mut self) {
        for column in &mut self.columns {
            column.clear();
        }
        self.len = 0;
        self.ascending = true;
        self.dense = true;
        self.largest = 0;
        self.lookups.get_mut().clear();
        *self.order.get_mut() = None;
    }

    fn rowid(&self, row: usize) -> i64 {
        match self.key {
            Key::Rowid(column) => self.columns[column].integer(row),
            _ => row as i64 + 1,
        }
    }

    /// Compares rows `a` and `b` on `columns`.
    fn compare_rows(&self, columns: &[usize], a: u32, b: u32) -> Ordering {
        for &column in columns {
            let ordering = self.columns[column].compare_rows(a as usize, b as usize);
            if ordering != Ordering::Equal {
                return ordering;
            }
        }
        Ordering::Equal
    }

    /// The rows in scan order, where they are not stored in it.
    fn scan_order(&self) -> Result<Option<Rc<[u32]>>> {
        let columns: &[usize] = match &self.key {
            Key::Position => return Ok(None),
            Key::Rowid(_) if self.ascending => return Ok(None),
            Key::Rowid(column) => std::slice::from_ref(column),
            Key::Primary(columns) => columns,
        };
        if let Some(order) = &*self.order.borrow() {
            return Ok(Some(Rc::clone(order)));
        }
        let identity: Vec<u32> = (0..self.len as u32).collect();
        let sorted = identity
            .windows(2)
            .all(|pair| self.compare_rows(columns, pair[0], pair[1]) == Ordering::Less);
        if sorted {
            // In key order already (and unique): scans need no permutation, but it is
            // remembered so the check runs once.
            let order: Rc<[u32]> = identity.into();
            *self.order.borrow_mut() = Some(Rc::clone(&order));
            return Ok(Some(order));
        }
        let mut rows = identity;
        rows.sort_by(|&a, &b| self.compare_rows(columns, a, b));
        if rows
            .windows(2)
            .any(|pair| self.compare_rows(columns, pair[0], pair[1]) == Ordering::Equal)
        {
            return Err(Error::ModuleError("frame: UNIQUE constraint failed".into()));
        }
        let order: Rc<[u32]> = rows.into();
        *self.order.borrow_mut() = Some(Rc::clone(&order));
        Ok(Some(order))
    }

    /// The index on `columns` (ascending column numbers), built on first use.
    fn lookup(&self, columns: &[usize]) -> Result<Rc<[u32]>> {
        if let Some((_, rows)) = self
            .lookups
            .borrow()
            .iter()
            .find(|(indexed, _)| indexed == columns)
        {
            return Ok(Rc::clone(rows));
        }
        #[cfg(any(test, feature = "unbounded-work"))]
        let _index_build = super::profiling::index_build(self.len);
        let mut rows: Vec<u32> = match self.scan_order()? {
            Some(order) => order.to_vec(),
            None => (0..self.len as u32).collect(),
        };
        // Stable: rows of one value stay in scan order.
        rows.sort_by(|&a, &b| self.compare_rows(columns, a, b));
        let rows: Rc<[u32]> = rows.into();
        self.lookups
            .borrow_mut()
            .push((columns.to_vec(), Rc::clone(&rows)));
        Ok(rows)
    }
}

/// A value as a lookup compares it: SQLite's order across storage classes.
#[derive(Clone, Copy)]
enum Probe<'a> {
    Null,
    Integer(i64),
    Real(f64),
    Text(&'a [u8]),
    Blob(&'a [u8]),
}

impl<'a> Probe<'a> {
    fn of(value: ValueRef<'a>) -> Self {
        match value {
            ValueRef::Null => Self::Null,
            ValueRef::Integer(value) => Self::Integer(value),
            ValueRef::Real(value) => Self::Real(value),
            ValueRef::Text(text) => Self::Text(text),
            ValueRef::Blob(blob) => Self::Blob(blob),
        }
    }

    /// `self` compared with an `INTEGER` column: numeric affinity converts a numeric text.
    fn numeric(self) -> Self {
        let Self::Text(text) = self else {
            return self;
        };
        let Ok(text) = std::str::from_utf8(text) else {
            return self;
        };
        let text = text.trim();
        if let Ok(value) = text.parse::<i64>() {
            Self::Integer(value)
        } else if let Ok(value) = text.parse::<f64>()
            && value.is_finite()
        {
            if value.fract() == 0.0 && value.abs() < 9.0e18 {
                Self::Integer(value as i64)
            } else {
                Self::Real(value)
            }
        } else {
            self
        }
    }

    fn class(self) -> u8 {
        match self {
            Self::Null => 0,
            Self::Integer(_) | Self::Real(_) => 1,
            Self::Text(_) => 2,
            Self::Blob(_) => 3,
        }
    }

    fn compare(self, other: Self) -> Ordering {
        match (self, other) {
            (Self::Integer(a), Self::Integer(b)) => a.cmp(&b),
            (Self::Integer(a), Self::Real(b)) => compare_mixed(a, b),
            (Self::Real(a), Self::Integer(b)) => compare_mixed(b, a).reverse(),
            (Self::Real(a), Self::Real(b)) => a.partial_cmp(&b).unwrap_or(Ordering::Equal),
            (Self::Text(a), Self::Text(b)) | (Self::Blob(a), Self::Blob(b)) => a.cmp(b),
            (a, b) => a.class().cmp(&b.class()),
        }
    }
}

/// An integer against a real, numerically.
fn compare_mixed(integer: i64, real: f64) -> Ordering {
    if real.is_nan() {
        return Ordering::Greater;
    }
    if real >= 9223372036854775808.0 {
        return Ordering::Less;
    }
    if real < -9223372036854775808.0 {
        return Ordering::Greater;
    }
    let truncated = real.trunc() as i64;
    integer.cmp(&truncated).then_with(|| {
        0.0f64
            .partial_cmp(&(real - real.trunc()))
            .unwrap_or(Ordering::Equal)
    })
}

/// One column's values: integers packed while they fit, any value once one does not.
enum Data {
    SharedNarrow(Arc<Page<i32>>, Option<Arc<[u32]>>),
    SharedWide(Arc<Page<i64>>, Option<Arc<[u32]>>),
    SharedAny(Arc<Page<Value>>, Option<Arc<[u32]>>),
    Narrow(Vec<i32>),
    Wide(Vec<i64>),
    Any(Vec<Value>),
}

struct Page<T> {
    values: Vec<T>,
    nulls: Vec<u64>,
    retained: Arc<AtomicUsize>,
    bytes: usize,
}
impl<T> Drop for Page<T> {
    fn drop(&mut self) {
        self.retained.fetch_sub(self.bytes, Atomic::Relaxed);
    }
}

impl Data {
    fn is_shared(&self) -> bool {
        matches!(
            self,
            Self::SharedNarrow(..) | Self::SharedWide(..) | Self::SharedAny(..)
        )
    }
}

impl<T> Page<T> {
    fn is_null(&self, row: usize) -> bool {
        self.nulls
            .get(row / 64)
            .is_some_and(|word| word >> (row % 64) & 1 == 1)
    }
}

#[inline]
fn mapped(rows: &Option<Arc<[u32]>>, row: usize) -> usize {
    rows.as_ref().map_or(row, |rows| rows[row] as usize)
}

struct Column {
    data: Data,
    /// `Narrow`/`Wide`: the rows that are NULL, a bit each (missing words are all clear).
    nulls: Vec<u64>,
    /// Declared `INTEGER`: a probe takes numeric affinity.
    integer: bool,
    /// Declared `NOT NULL DEFAULT` an integer: what a NULL stores. SQLite passes a column an
    /// `INSERT` omits as NULL, and a B-tree would refuse an explicit NULL.
    default: Option<i64>,
}

impl Column {
    fn new(integer: bool, default: Option<i64>) -> Self {
        Self {
            data: Data::Narrow(Vec::new()),
            nulls: Vec::new(),
            integer,
            default,
        }
    }

    fn is_null(&self, row: usize) -> bool {
        self.nulls
            .get(row / 64)
            .is_some_and(|word| word >> (row % 64) & 1 == 1)
    }

    #[inline]
    fn get(&self, row: usize) -> ValueRef<'_> {
        match &self.data {
            Data::SharedNarrow(page, rows) => {
                let row = mapped(rows, row);
                if page.is_null(row) {
                    ValueRef::Null
                } else {
                    ValueRef::Integer(page.values[row].into())
                }
            }
            Data::SharedWide(page, rows) => {
                let row = mapped(rows, row);
                if page.is_null(row) {
                    ValueRef::Null
                } else {
                    ValueRef::Integer(page.values[row])
                }
            }
            Data::SharedAny(page, rows) => ValueRef::from(&page.values[mapped(rows, row)]),
            Data::Narrow(values) if !self.is_null(row) => ValueRef::Integer(values[row].into()),
            Data::Wide(values) if !self.is_null(row) => ValueRef::Integer(values[row]),
            Data::Any(values) => ValueRef::from(&values[row]),
            _ => ValueRef::Null,
        }
    }

    /// Row `row`'s value as an integer (a key column holds integers only).
    #[inline]
    fn integer(&self, row: usize) -> i64 {
        match self.get(row) {
            ValueRef::Integer(value) => value,
            _ => 0,
        }
    }

    fn compare_rows(&self, a: usize, b: usize) -> Ordering {
        match &self.data {
            Data::SharedNarrow(page, rows) if page.nulls.is_empty() => {
                return page.values[mapped(rows, a)].cmp(&page.values[mapped(rows, b)]);
            }
            Data::SharedWide(page, rows) if page.nulls.is_empty() => {
                return page.values[mapped(rows, a)].cmp(&page.values[mapped(rows, b)]);
            }
            Data::Narrow(values) if self.nulls.is_empty() => return values[a].cmp(&values[b]),
            Data::Wide(values) if self.nulls.is_empty() => return values[a].cmp(&values[b]),
            _ => {}
        }
        Probe::of(self.get(a)).compare(Probe::of(self.get(b)))
    }
}

/// A value of SQLite's as an owned one (a text that is not UTF-8 keeps what it can).
fn owned(value: ValueRef<'_>) -> Value {
    match value {
        ValueRef::Text(text) => Value::Text(String::from_utf8_lossy(text).into_owned()),
        value => Value::try_from(value).unwrap_or(Value::Null),
    }
}

impl Column {
    fn set(&mut self, row: usize, len: usize, value: ValueRef<'_>) {
        if self.data.is_shared() {
            let mut column = Self::new(self.integer, self.default);
            for at in 0..len {
                column.push(at, self.get(at));
            }
            *self = column;
        }
        let value = match (value, self.default) {
            (ValueRef::Null, Some(default)) => ValueRef::Integer(default),
            (value, _) => value,
        };
        if let Some(word) = self.nulls.get_mut(row / 64) {
            *word &= !(1 << (row % 64));
        }
        match (value, &mut self.data) {
            (value, Data::Any(values)) => values[row] = owned(value),
            (ValueRef::Null, data) => {
                self.nulls.resize(self.nulls.len().max(row / 64 + 1), 0);
                self.nulls[row / 64] |= 1 << (row % 64);
                match data {
                    Data::Narrow(values) => values[row] = 0,
                    Data::Wide(values) => values[row] = 0,
                    _ => unreachable!("shared columns materialized"),
                }
            }
            (ValueRef::Integer(value), Data::Narrow(values)) => {
                if let Ok(narrow) = i32::try_from(value) {
                    values[row] = narrow;
                } else {
                    let mut wide: Vec<i64> = values.iter().map(|&v| v.into()).collect();
                    wide[row] = value;
                    self.data = Data::Wide(wide);
                }
            }
            (ValueRef::Integer(value), Data::Wide(values)) => values[row] = value,
            (value, _) => {
                // Preserve other rows when the column changes its storage type.
                let mut values: Vec<Value> = (0..len).map(|at| owned(self.get(at))).collect();
                values[row] = owned(value);
                self.data = Data::Any(values);
                self.nulls.clear();
            }
        }
    }

    fn push(&mut self, row: usize, value: ValueRef<'_>) {
        if self.data.is_shared() {
            let mut owned = Self::new(self.integer, self.default);
            for at in 0..row {
                owned.push(at, self.get(at));
            }
            *self = owned;
        }
        let value = match (value, self.default) {
            (ValueRef::Null, Some(default)) => ValueRef::Integer(default),
            (value, _) => value,
        };
        match (value, &mut self.data) {
            (ValueRef::Null, Data::Any(values)) => values.push(Value::Null),
            (ValueRef::Null, data) => {
                let word = row / 64;
                if self.nulls.len() <= word {
                    self.nulls.resize(word + 1, 0);
                }
                self.nulls[word] |= 1 << (row % 64);
                match data {
                    Data::Narrow(values) => values.push(0),
                    Data::Wide(values) => values.push(0),
                    Data::Any(_)
                    | Data::SharedNarrow(..)
                    | Data::SharedWide(..)
                    | Data::SharedAny(..) => unreachable!("matched above or materialized"),
                }
            }
            (ValueRef::Integer(value), Data::Narrow(values)) => match i32::try_from(value) {
                Ok(narrow) => values.push(narrow),
                Err(_) => {
                    let mut wide: Vec<i64> = values.iter().map(|&value| value.into()).collect();
                    wide.push(value);
                    self.data = Data::Wide(wide);
                }
            },
            (ValueRef::Integer(value), Data::Wide(values)) => values.push(value),
            (value, Data::Any(values)) => values.push(owned(value)),
            (value, _) => {
                let mut any: Vec<Value> = (0..row).map(|row| owned(self.get(row))).collect();
                any.push(owned(value));
                self.data = Data::Any(any);
                self.nulls.clear();
            }
        }
    }

    fn clear(&mut self) {
        self.data = match std::mem::replace(&mut self.data, Data::Narrow(Vec::new())) {
            Data::Narrow(mut values) => {
                values.clear();
                Data::Narrow(values)
            }
            Data::SharedNarrow(page, _) => match Arc::try_unwrap(page) {
                Ok(mut page) => {
                    // The final consumer returns its page's buffer to a register. Otherwise
                    // sharing would discard the allocation that ordinary clears retain.
                    let mut values = std::mem::take(&mut page.values);
                    values.clear();
                    self.nulls = std::mem::take(&mut page.nulls);
                    Data::Narrow(values)
                }
                Err(_) => Data::Narrow(Vec::new()),
            },
            _ => Data::Narrow(Vec::new()),
        };
        self.nulls.clear();
    }

    fn trim(&mut self) {
        if let Data::Narrow(values) = &mut self.data
            && values.capacity() > RETAIN
        {
            values.shrink_to(RETAIN);
        }
        if self.nulls.capacity() > RETAIN / 64 {
            self.nulls.shrink_to(RETAIN / 64);
        }
    }
}

/// A frame's declared schema and empty buffers, from its declaration's entries (`FRAME`): the
/// column definitions and table constraints of the `CREATE TABLE` it stands for, then the
/// table's indexes (`INDEX (…)`, `rewrite`).
fn parse(args: &[&str]) -> Result<(CString, Frame)> {
    let mut declared = Vec::new();
    let mut names: Vec<String> = Vec::new();
    let mut columns = Vec::new();
    let mut key = Key::Position;
    let mut primary: Option<Vec<String>> = None;
    let mut index_lists: Vec<Vec<String>> = Vec::new();
    let list = |text: &str| -> Vec<String> {
        let text = text.trim().trim_start_matches('(').trim_end_matches(')');
        text.split(',').map(|name| name.trim().to_owned()).collect()
    };
    for &arg in args {
        let arg = arg.trim();
        if let Some(columns) = arg.strip_prefix("PRIMARY KEY") {
            primary = Some(list(columns));
            continue;
        }
        if let Some(columns) = arg.strip_prefix("INDEX ") {
            index_lists.push(list(columns));
            continue;
        }
        let (name, rest) = if let Some(quoted) = arg.strip_prefix('"') {
            let end = quoted
                .find('"')
                .ok_or_else(|| Error::ModuleError(format!("frame: bad column {arg}")))?;
            (&arg[..end + 2], &quoted[end + 1..])
        } else {
            arg.split_at(arg.find(' ').unwrap_or(arg.len()))
        };
        let rest = rest.trim();
        if rest.contains("PRIMARY KEY") {
            key = Key::Rowid(columns.len());
        }
        let decl = rest.replace("PRIMARY KEY", "");
        let default = match decl.split_once("DEFAULT") {
            None => None,
            Some((_, value)) if decl.contains("NOT NULL") => {
                Some(value.trim().parse::<i64>().map_err(|_| {
                    Error::ModuleError(format!("frame: unsupported default in {arg}"))
                })?)
            }
            Some(_) => {
                return Err(Error::ModuleError(format!(
                    "frame: a nullable default in {arg}"
                )));
            }
        };
        let decl = decl.replace("NOT NULL", "");
        let integer = decl
            .split_whitespace()
            .next()
            .is_some_and(|word| word.contains("INT"));
        declared.push(format!("{name} {}", decl.trim()));
        names.push(name.to_owned());
        columns.push(Column::new(integer, default));
    }
    let position = |name: &String| {
        names
            .iter()
            .position(|column| column == name)
            .ok_or_else(|| Error::ModuleError(format!("frame: no column {name}")))
    };
    if let Some(primary) = primary {
        key = Key::Primary(primary.iter().map(position).collect::<Result<Vec<_>>>()?);
    }
    let mut indexed = index_lists
        .iter()
        .map(|columns| columns.iter().map(position).collect::<Result<Vec<_>>>())
        .collect::<Result<Vec<_>>>()?;
    match &key {
        Key::Position => {}
        Key::Rowid(column) => indexed.push(vec![*column]),
        Key::Primary(columns) => indexed.push(columns.clone()),
    }
    let schema = CString::new(format!("CREATE TABLE x({})", declared.join(", ")))
        .map_err(|_| Error::ModuleError("frame: a NUL in the schema".into()))?;
    Ok((
        schema,
        Frame {
            names,
            columns,
            len: 0,
            key,
            indexed,
            ascending: true,
            dense: true,
            largest: 0,
            lookups: RefCell::default(),
            order: RefCell::default(),
        },
    ))
}

#[repr(C)]
pub(super) struct FrameTable {
    base: sqlite3_vtab,
    shared: Arc<Shared>,
    store: Arc<FrameStore>,
}

impl FrameTable {
    fn of(aux: Option<&FrameAux>) -> Result<(Cow<'static, CStr>, Self)> {
        let aux = aux.ok_or_else(|| Error::ModuleError("frame: no frame".into()))?;
        Ok((
            Cow::Owned(aux.schema.clone()),
            Self {
                base: sqlite3_vtab::default(),
                shared: Arc::clone(&aux.shared),
                store: Arc::clone(&aux.store),
            },
        ))
    }
}

unsafe impl<'vtab> VTab<'vtab> for FrameTable {
    type Aux = FrameAux;
    type Cursor = FrameCursor<'vtab>;

    fn connect(
        _db: &mut VTabConnection,
        aux: Option<&FrameAux>,
        _module: &[u8],
        _database: &[u8],
        _table: &[u8],
        _args: &[&[u8]],
    ) -> Result<(Cow<'static, CStr>, Self)> {
        Self::of(aux)
    }

    fn best_index(&self, info: &mut IndexInfo) -> Result<bool> {
        use IndexConstraintOp as Op;
        #[cfg(not(feature = "unbounded-work"))]
        let scan_cost = SCAN_COST;
        #[cfg(feature = "unbounded-work")]
        let scan_cost =
            {
                static COST: std::sync::LazyLock<f64> =
                    std::sync::LazyLock::new(|| {
                        std::env::var("RERAIL_SQL_FRAME_SCAN_COST").map_or(SCAN_COST, |value| {
                    value.parse::<f64>().ok().filter(|n| n.is_finite() && (1.0..=1e12).contains(n))
                        .expect("RERAIL_SQL_FRAME_SCAN_COST must be finite and between 1 and 1e12")
                })
                    });
                *COST
            };
        let frame = self.shared.get();
        // Per column, its first usable `=` or `IS` constraint.
        let mut used: Vec<(usize, usize, bool)> = Vec::new();
        for (index, constraint) in info.constraints().enumerate() {
            if !constraint.is_usable() {
                continue;
            }
            let Ok(column) = usize::try_from(constraint.column()) else {
                continue;
            };
            let is = match constraint.operator() {
                Op::SQLITE_INDEX_CONSTRAINT_EQ => false,
                Op::SQLITE_INDEX_CONSTRAINT_IS => true,
                _ => continue,
            };
            if !used.iter().any(|&(_, used, _)| used == column) {
                used.push((index, column, is));
            }
        }
        used.sort_unstable_by_key(|&(_, column, _)| column);
        let scan_key: Vec<c_int> = match &frame.key {
            Key::Position => vec![-1],
            Key::Rowid(column) => vec![*column as c_int],
            Key::Primary(columns) => columns.iter().map(|&column| column as c_int).collect(),
        };
        let ordered = {
            let count = info.num_of_order_by();
            count > 0
                && count <= scan_key.len()
                && info
                    .order_bys()
                    .zip(&scan_key)
                    .all(|(order, &column)| order.column() == column && !order.is_order_by_desc())
        };
        if ordered {
            info.set_order_by_consumed(true);
        }
        if let Key::Rowid(key) = frame.key
            && !used.iter().any(|&(_, column, _)| column == key)
        {
            let bounds = info
                .constraints()
                .enumerate()
                .filter_map(|(at, c)| {
                    if !c.is_usable()
                        || c.column() != key as c_int
                        || info.collation(at).ok() != Some("BINARY")
                    {
                        return None;
                    }
                    let code = match c.operator() {
                        Op::SQLITE_INDEX_CONSTRAINT_GT => '>',
                        Op::SQLITE_INDEX_CONSTRAINT_GE => ']',
                        Op::SQLITE_INDEX_CONSTRAINT_LT => '<',
                        Op::SQLITE_INDEX_CONSTRAINT_LE => '[',
                        _ => return None,
                    };
                    Some((at, code))
                })
                .collect::<Vec<_>>();
            if !bounds.is_empty() {
                let mut codes = String::from("@range:");
                for (arg, (at, code)) in bounds.iter().enumerate() {
                    let mut usage = info.constraint_usage(*at);
                    usage.set_argv_index(arg as c_int + 1);
                    usage.set_omit(false);
                    codes.push(*code);
                }
                info.set_idx_num(2);
                info.set_idx_str(&codes);
                info.set_estimated_cost(40.0);
                info.set_estimated_rows(10);
                return Ok(true);
            }
        }
        if used.is_empty() {
            info.set_idx_num(0);
            info.set_estimated_cost(scan_cost);
            info.set_estimated_rows(scan_cost as i64);
            return Ok(true);
        }
        let unique = match &frame.key {
            Key::Position => false,
            Key::Rowid(key) => used.iter().any(|&(_, column, _)| column == *key),
            Key::Primary(key) => key
                .iter()
                .all(|key| used.iter().any(|&(_, column, _)| column == *key)),
        };
        // The estimate the table's B-tree plan had: an index's, an automatic index's for a join
        // on other columns, and a filtered scan's for constants on other columns (SQLite's
        // heuristic: an `=` keeps a quarter of the rows, half for -1, 0 or 1).
        let indexed = frame
            .indexed
            .iter()
            .any(|columns| used.iter().any(|&(_, column, _)| column == columns[0]));
        let mut constants = Vec::with_capacity(used.len());
        for &(index, _, _) in &used {
            constants.push(
                info.rhs_value(index)
                    .ok()
                    .flatten()
                    .map(|value| matches!(Probe::of(value).numeric(), Probe::Integer(-1..=1))),
            );
        }
        let (cost, rows) = if unique {
            (20.0, 1)
        } else if indexed {
            (40.0, 10)
        } else if constants.iter().any(Option::is_none) {
            (60.0, 20)
        } else {
            let rows = constants.iter().fold(scan_cost, |rows, small| {
                if *small == Some(true) {
                    rows / 2.0
                } else {
                    rows / 4.0
                }
            });
            (scan_cost, rows as i64)
        };
        let mut codes = String::from("@");
        for (argv, &(index, column, is)) in used.iter().enumerate() {
            let mut usage = info.constraint_usage(index);
            usage.set_argv_index(argv as c_int + 1);
            usage.set_omit(false);
            codes.push(if is { '~' } else { '=' });
            codes.push_str(&column.to_string());
            codes.push(',');
        }
        info.set_idx_num(1);
        info.set_idx_str(&codes);
        if unique {
            info.set_idx_flags(IndexFlags::SQLITE_INDEX_SCAN_UNIQUE);
        }
        info.set_estimated_cost(cost);
        info.set_estimated_rows(rows);
        Ok(true)
    }

    fn open(&'vtab mut self) -> Result<FrameCursor<'vtab>> {
        Ok(FrameCursor {
            base: sqlite3_vtab_cursor::default(),
            shared: Arc::clone(&self.shared),
            rows: Rows::Range { next: 0, end: 0 },
            row: 0,
            phantom: PhantomData,
        })
    }
}

impl CreateVTab<'_> for FrameTable {
    // Eponymous: `xCreate` is `xConnect`, so a frame is never in the schema.
    const KIND: VTabKind = VTabKind::Eponymous;

    fn create(
        _db: &mut VTabConnection,
        aux: Option<&FrameAux>,
        _module: &[u8],
        _database: &[u8],
        _table: &[u8],
        _args: &[&[u8]],
    ) -> Result<(Cow<'static, CStr>, Self)> {
        Self::of(aux)
    }
}

impl UpdateVTab<'_> for FrameTable {
    fn delete(&mut self, _: ValueRef<'_>) -> Result<()> {
        Err(Error::ModuleError(
            "frame: rows are appended and the frame emptied whole".into(),
        ))
    }

    fn insert(&mut self, args: &Inserts<'_>) -> Result<i64> {
        #[cfg(any(test, feature = "unbounded-work"))]
        super::profiling::frame(super::profiling::FrameEvent::Insert, 1);
        // SAFETY: SQLite calls `xUpdate` with no cursor of the frame inside a method (`Shared`).
        let frame = unsafe { self.shared.get_mut() };
        if args.len() != frame.columns.len() + 2 {
            return Err(Error::ModuleError("frame: wrong column count".into()));
        }
        let live = self.store.live.fetch_add(1, Atomic::Relaxed) + 1;
        if live > BUDGET {
            self.store.live.fetch_sub(1, Atomic::Relaxed);
            return Err(Error::ModuleError(format!(
                "frame: the batch's frames would hold more than {BUDGET} rows"
            )));
        }
        self.store.peak.fetch_max(live, Atomic::Relaxed);
        let row = frame.len;
        let mut values = args.iter();
        let _old = values.next();
        let new_rowid = values.next().unwrap_or(ValueRef::Null);
        let rowid = match frame.key {
            Key::Rowid(key) => {
                let given = args.iter().nth(key + 2).unwrap_or(ValueRef::Null);
                let value = match given {
                    ValueRef::Null => new_rowid,
                    value => value,
                };
                let rowid = match Probe::of(value).numeric() {
                    Probe::Integer(value) => value,
                    Probe::Real(value) if value.fract() == 0.0 => value as i64,
                    Probe::Null if row == 0 => 1,
                    Probe::Null => frame
                        .largest
                        .checked_add(1)
                        .ok_or_else(|| Error::ModuleError("frame: the rowid overflows".into()))?,
                    _ => return Err(Error::ModuleError("frame: datatype mismatch".into())),
                };
                if row > 0 {
                    if rowid <= frame.largest {
                        frame.ascending = false;
                    }
                    if Some(rowid) != frame.largest.checked_add(1) {
                        frame.dense = false;
                    }
                }
                frame.largest = if row == 0 {
                    rowid
                } else {
                    frame.largest.max(rowid)
                };
                for (column, value) in values.enumerate() {
                    let value = if column == key {
                        ValueRef::Integer(rowid)
                    } else {
                        value
                    };
                    frame.columns[column].push(row, value);
                }
                rowid
            }
            _ => {
                for (column, value) in values.enumerate() {
                    frame.columns[column].push(row, value);
                }
                row as i64 + 1
            }
        };
        frame.len += 1;
        if !frame.lookups.get_mut().is_empty() || frame.order.get_mut().is_some() {
            frame.lookups.get_mut().clear();
            *frame.order.get_mut() = None;
        }
        Ok(rowid)
    }

    fn update(&mut self, _: &Updates<'_>) -> Result<()> {
        Err(Error::ModuleError(
            "frame: rows are appended and the frame emptied whole".into(),
        ))
    }
}

/// The rows a cursor yields, in order.
enum Rows {
    /// Stored rows `next..end`.
    Range { next: usize, end: usize },
    /// `rows[next..end]`.
    Listed {
        rows: Rc<[u32]>,
        next: usize,
        end: usize,
    },
}

#[repr(C)]
pub(super) struct FrameCursor<'vtab> {
    base: sqlite3_vtab_cursor,
    shared: Arc<Shared>,
    rows: Rows,
    /// The current row (valid while not at the end).
    row: usize,
    phantom: PhantomData<&'vtab FrameTable>,
}

/// The most constraints a lookup takes without allocating.
const INLINE: usize = 8;

impl FrameCursor<'_> {
    /// Moves to the next row of `rows`.
    fn step(&mut self) {
        match &mut self.rows {
            Rows::Range { next, end } => {
                if *next < *end {
                    self.row = *next;
                    *next += 1;
                } else {
                    *next = end.saturating_add(1);
                }
            }
            Rows::Listed { rows, next, end } => {
                if *next < *end {
                    self.row = rows[*next] as usize;
                    *next += 1;
                } else {
                    *next = end.saturating_add(1);
                }
            }
        }
    }

    /// The rows matching `probes` (column, value) on the ascending columns `columns`.
    fn find(&mut self, columns: &[usize], probes: &[Probe<'_>]) -> Result<Rows> {
        let frame = self.shared.get();
        // A key lookup in a frame whose keys ascend: by position or by binary search.
        if let ([column], [probe]) = (columns, probes)
            && frame.key == Key::Rowid(*column)
            && frame.ascending
        {
            let key = match *probe {
                Probe::Integer(key) => key,
                Probe::Real(key) if key.fract() == 0.0 && key.abs() < 9.0e18 => key as i64,
                _ => return Ok(Rows::Range { next: 0, end: 0 }),
            };
            let values = &frame.columns[*column];
            let at = if frame.dense && frame.len > 0 {
                let first = values.integer(0);
                usize::try_from(key.wrapping_sub(first))
                    .ok()
                    .filter(|&at| at < frame.len)
            } else {
                let at = partition(frame.len, |row| values.integer(row) < key);
                (at < frame.len && values.integer(at) == key).then_some(at)
            };
            return Ok(match at {
                Some(at) => Rows::Range {
                    next: at,
                    end: at + 1,
                },
                None => Rows::Range { next: 0, end: 0 },
            });
        }
        let rows = frame.lookup(columns)?;
        let compare = |row: u32| -> Ordering {
            for (&column, probe) in columns.iter().zip(probes) {
                let ordering = Probe::of(frame.columns[column].get(row as usize)).compare(*probe);
                if ordering != Ordering::Equal {
                    return ordering;
                }
            }
            Ordering::Equal
        };
        let start = rows.partition_point(|&row| compare(row) == Ordering::Less);
        let end = start + rows[start..].partition_point(|&row| compare(row) == Ordering::Equal);
        Ok(Rows::Listed {
            rows,
            next: start,
            end,
        })
    }
}

/// The first of `0..len` where `before` turns false (it holds on a prefix).
fn partition(len: usize, before: impl Fn(usize) -> bool) -> usize {
    let (mut low, mut high) = (0, len);
    while low < high {
        let middle = low + (high - low) / 2;
        if before(middle) {
            low = middle + 1;
        } else {
            high = middle;
        }
    }
    low
}

unsafe impl VTabCursor for FrameCursor<'_> {
    fn filter(&mut self, idx_num: c_int, idx_str: Option<&str>, args: &Filters<'_>) -> Result<()> {
        #[cfg(any(test, feature = "unbounded-work"))]
        super::profiling::frame(
            if idx_num == 0 {
                super::profiling::FrameEvent::Scan
            } else {
                super::profiling::FrameEvent::Lookup
            },
            1,
        );
        if idx_num == 0 {
            let frame = self.shared.get();
            self.rows = match frame.scan_order()? {
                Some(rows) => Rows::Listed {
                    end: rows.len(),
                    rows,
                    next: 0,
                },
                None => Rows::Range {
                    next: 0,
                    end: frame.len,
                },
            };
            self.step();
            return Ok(());
        }
        if idx_num == 2 {
            let frame = self.shared.get();
            let Key::Rowid(key) = frame.key else {
                return Err(Error::ModuleError("frame: range requires row key".into()));
            };
            let order = frame.scan_order()?;
            let value = |at: usize| {
                Probe::of(
                    frame.columns[key].get(order.as_ref().map_or(at, |rows| rows[at] as usize)),
                )
            };
            let mut start = 0;
            let mut end = frame.len;
            let codes = idx_str
                .and_then(|s| s.strip_prefix("@range:"))
                .ok_or_else(|| Error::ModuleError("frame: invalid range plan".into()))?;
            for (code, bound) in codes.bytes().zip(args.iter()) {
                let probe = Probe::of(bound);
                let probe = if frame.columns[key].integer {
                    probe.numeric()
                } else {
                    probe
                };
                if matches!(probe, Probe::Null) {
                    end = 0;
                    break;
                }
                let less = |at| value(at).compare(probe) == Ordering::Less;
                let at_most = |at| value(at).compare(probe) != Ordering::Greater;
                match code {
                    b'>' => start = start.max(partition(frame.len, at_most)),
                    b']' => start = start.max(partition(frame.len, less)),
                    b'<' => end = end.min(partition(frame.len, less)),
                    b'[' => end = end.min(partition(frame.len, at_most)),
                    _ => return Err(Error::ModuleError("frame: invalid range".into())),
                }
            }
            let start = start.min(end);
            self.rows = if let Some(rows) = order {
                Rows::Listed {
                    rows,
                    next: start,
                    end,
                }
            } else {
                Rows::Range { next: start, end }
            };
            self.step();
            return Ok(());
        }
        let codes = idx_str
            .and_then(|codes| codes.strip_prefix('@'))
            .ok_or_else(|| Error::ModuleError("frame: bad plan".into()))?;
        let mut columns = [0usize; INLINE];
        let mut probes = [Probe::Null; INLINE];
        let mut spilled: Option<(Vec<usize>, Vec<Probe<'_>>)> = None;
        let mut empty = false;
        let frame = self.shared.get();
        for (at, (code, value)) in codes.split_terminator(',').zip(args.iter()).enumerate() {
            let (is, column) = match code.as_bytes().first() {
                Some(b'~') => (true, &code[1..]),
                Some(b'=') => (false, &code[1..]),
                _ => return Err(Error::ModuleError("frame: bad plan".into())),
            };
            let column: usize = column
                .parse()
                .map_err(|_| Error::ModuleError("frame: bad plan".into()))?;
            let mut probe = Probe::of(value);
            if frame.columns[column].integer {
                probe = probe.numeric();
            }
            if matches!(probe, Probe::Null) && !is {
                empty = true;
            }
            match &mut spilled {
                Some((more_columns, more_probes)) => {
                    more_columns.push(column);
                    more_probes.push(probe);
                }
                None if at < INLINE => {
                    columns[at] = column;
                    probes[at] = probe;
                }
                None => {
                    let mut more_columns = columns.to_vec();
                    let mut more_probes = probes.to_vec();
                    more_columns.push(column);
                    more_probes.push(probe);
                    spilled = Some((more_columns, more_probes));
                }
            }
        }
        self.rows = if empty {
            Rows::Range { next: 0, end: 0 }
        } else {
            match &spilled {
                Some((columns, probes)) => self.find(columns, probes)?,
                None => {
                    let count = codes.split_terminator(',').count().min(INLINE);
                    self.find(&columns[..count], &probes[..count])?
                }
            }
        };
        self.step();
        Ok(())
    }

    fn next(&mut self) -> Result<()> {
        #[cfg(any(test, feature = "unbounded-work"))]
        super::profiling::frame(super::profiling::FrameEvent::Next, 1);
        self.step();
        Ok(())
    }

    fn eof(&self) -> bool {
        match &self.rows {
            Rows::Range { next, end } | Rows::Listed { next, end, .. } => *next > *end,
        }
    }

    fn column(&self, context: &mut Context, column: c_int) -> Result<()> {
        #[cfg(any(test, feature = "unbounded-work"))]
        super::profiling::frame(super::profiling::FrameEvent::Column, 1);
        let frame = self.shared.get();
        let value = frame.columns[column as usize].get(self.row);
        context.set_result(&ToSqlOutput::Borrowed(value))
    }

    fn rowid(&self) -> Result<i64> {
        Ok(self.shared.get().rowid(self.row))
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn sparse_recursive_answers_probe_callers_instead_of_scanning_them() {
        let (db, store) = connection(
            "/*FRAME*/callers(k INTEGER PRIMARY KEY,file,node,capture); /*FRAME*/demand(id INTEGER PRIMARY KEY,file,node); /*FRAME*/answer(id INTEGER PRIMARY KEY,unk)",
        );
        store
            .program_rows(
                "callers",
                (1..=10000)
                    .map(|k| {
                        vec![
                            Value::Integer(k),
                            Value::Integer(0),
                            Value::Integer(k),
                            Value::Text(format!("capture-{k}")),
                        ]
                    })
                    .collect(),
                false,
                false,
            )
            .unwrap();
        db.execute_batch("INSERT INTO demand VALUES(17,0,5000); INSERT INTO answer VALUES(17,1)")
            .unwrap();
        let project = "SELECT f.k,f.capture,r.unk";
        let broad = format!(
            "{project} FROM callers f CROSS JOIN demand d ON d.file=f.file AND d.node=f.node CROSS JOIN answer r ON r.id=d.id"
        );
        let sparse = format!(
            "{project} FROM answer r CROSS JOIN demand d ON d.id=r.id CROSS JOIN callers f ON f.file=d.file AND f.node=d.node"
        );
        let (expected, before) = super::super::profiling::frame_counts(|| rows(&db, &broad));
        let (actual, after) = super::super::profiling::frame_counts(|| rows(&db, &sparse));
        assert_eq!(actual, expected);
        assert_eq!(
            actual,
            vec![vec![
                Value::Integer(5000),
                Value::Text("capture-5000".into()),
                Value::Integer(1)
            ]]
        );
        assert!(before[2] >= 10000, "{before:?}");
        assert_eq!(
            after[2], 3,
            "only answer, demand, and matching caller advance: {after:?}"
        );
        // Hash-index construction still reads callers once and is separately visible.
        // The traversal reduction is not a claim that all physical work disappears.
        assert!(after[6] >= 10000, "{after:?}");
    }

    #[test]
    fn row_key_ranges_seek_to_bounds_and_match_sqlite_affinity() {
        let (db, store) = connection("/*FRAME*/a(k INTEGER PRIMARY KEY, v)");
        db.execute_batch("CREATE TABLE oracle(k INTEGER PRIMARY KEY,v)")
            .unwrap();
        for k in [100, -4, 0, 2, 7, 9007199254740993, i64::MIN + 1, i64::MAX] {
            db.execute("INSERT INTO a VALUES(?1,?1)", [k]).unwrap();
            db.execute("INSERT INTO oracle VALUES(?1,?1)", [k]).unwrap();
        }
        for (lo, hi) in [
            (Value::Integer(-4), Value::Integer(100)),
            (Value::Text("2".into()), Value::Real(7.5)),
            (Value::Null, Value::Integer(100)),
            (Value::Integer(100), Value::Integer(-4)),
            (
                Value::Integer(9007199254740992),
                Value::Real(9007199254740994.0),
            ),
            (Value::Integer(i64::MIN), Value::Real(1e25)),
            (Value::Integer(i64::MIN), Value::Real(i64::MAX as f64)),
        ] {
            for (left, right) in [("<", ">"), ("<=", ">="), ("<", ">="), ("<=", ">")] {
                let read = |table: &str| {
                    db.prepare(&format!(
                        "SELECT k FROM {table} WHERE ?1 {left} k AND ?2 {right} k ORDER BY k"
                    ))
                    .unwrap()
                    .query_map([&lo, &hi], |r| r.get::<_, i64>(0))
                    .unwrap()
                    .collect::<Result<Vec<_>>>()
                    .unwrap()
                };
                assert_eq!(read("a"), read("oracle"), "{lo:?} {left} k {right} {hi:?}");
            }
        }
        store.clear("a");
        store
            .program_rows(
                "a",
                (1..=10000)
                    .map(|k| vec![Value::Integer(k), Value::Integer(k)])
                    .collect(),
                false,
                false,
            )
            .unwrap();
        let (actual, counts) = super::super::profiling::frame_counts(|| {
            rows(&db, "SELECT k FROM a WHERE k>5000 AND k<=5008")
        });
        assert_eq!(actual.len(), 8);
        assert_eq!(
            counts[2], 8,
            "an eight-row prefix must not scan 10,000 candidates"
        );
        let plan = db
            .prepare("EXPLAIN QUERY PLAN SELECT k FROM a WHERE k>5000 AND k<=5008")
            .unwrap()
            .query_map([], |r| r.get::<_, String>(3))
            .unwrap()
            .collect::<Result<Vec<_>>>()
            .unwrap();
        assert!(
            plan.iter().any(|line| line.contains("INDEX 2:")),
            "{plan:?}"
        );
    }

    #[test]
    fn column_deltas_detach_shared_pages_without_changing_other_views() {
        let (db, store) = connection(
            "/*FRAME*/a(k INTEGER PRIMARY KEY, x); /*FRAME*/b(k INTEGER PRIMARY KEY, x); INSERT INTO a VALUES (1,NULL),(2,2147483648),(3,'text')",
        );
        store
            .select(&db, "INSERT INTO b SELECT f.k,f.x FROM a f WHERE f.k>=2")
            .unwrap();
        let expected = rows(&db, "SELECT * FROM a");
        store
            .program_patch(
                "b",
                &[1],
                vec![vec![
                    Value::Integer(2),
                    Value::Null,
                    Value::Integer(3),
                    Value::Blob(vec![0, 255]),
                ]],
            )
            .unwrap();
        assert_eq!(rows(&db, "SELECT * FROM a"), expected);
        assert_eq!(
            rows(&db, "SELECT * FROM b"),
            vec![
                vec![Value::Integer(2), Value::Null],
                vec![Value::Integer(3), Value::Blob(vec![0, 255])]
            ]
        );
        store
            .program_patch(
                "a",
                &[1],
                vec![vec![Value::Integer(1), Value::Integer(i64::MAX)]],
            )
            .unwrap();
        assert_eq!(
            rows(&db, "SELECT x FROM a WHERE k=1"),
            vec![vec![Value::Integer(i64::MAX)]]
        );
        assert_eq!(
            rows(&db, "SELECT x FROM b WHERE k=2"),
            vec![vec![Value::Null]]
        );
        assert_eq!(store.live.load(Atomic::Relaxed), 5);
    }

    #[test]
    fn selections_share_pages_across_clear_reuse_and_appends() {
        let (db, store) = connection(
            "/*FRAME*/a(k INTEGER PRIMARY KEY, x, y); /*FRAME*/b(k INTEGER PRIMARY KEY, y, x); /*FRAME*/c(k INTEGER PRIMARY KEY, x, y); INSERT INTO a VALUES (1, NULL, 9223372036854775807), (2, 'text', x'1234'), (3, 1.5, -8)",
        );
        let select = "INSERT INTO b SELECT f.k, f.y, f.x FROM a f WHERE f.k >= 2";
        let expected = rows(&db, "SELECT k, y, x FROM a WHERE k >= 2");
        assert_eq!(store.select(&db, select).unwrap(), Some(2));
        assert_eq!(rows(&db, "SELECT * FROM b"), expected);
        assert!(store.retained.load(Atomic::Relaxed) > 0);
        assert_eq!(
            store
                .select(
                    &db,
                    "INSERT INTO c SELECT f.k, f.x, f.y FROM b f WHERE f.k = 3"
                )
                .unwrap(),
            Some(1)
        );
        store.clear("a");
        db.execute_batch(
            "INSERT INTO a VALUES (9, 'reuse', NULL); INSERT INTO b VALUES (4, 42, 'append')",
        )
        .unwrap();
        assert_eq!(
            rows(&db, "SELECT * FROM c"),
            vec![vec![
                Value::Integer(3),
                Value::Real(1.5),
                Value::Integer(-8)
            ]]
        );
        assert_eq!(
            rows(&db, "SELECT x FROM b WHERE k = 2"),
            vec![vec![Value::Text("text".into())]]
        );
        store.clear("b");
        store.clear("c");
        assert_eq!(store.retained.load(Atomic::Relaxed), 0);
        assert_eq!(store.live.load(Atomic::Relaxed), 1);
    }

    #[test]
    fn selection_publication_invalidates_an_index_built_while_empty() {
        let (db, store) = connection(
            "/*FRAME*/a(k INTEGER PRIMARY KEY, x); /*FRAME*/b(k INTEGER PRIMARY KEY, x, INDEX (x)); INSERT INTO a VALUES (1, 7), (2, 'text')",
        );
        assert!(rows(&db, "SELECT k FROM b WHERE x = 7").is_empty());
        assert!(
            !store
                .frames
                .lock()
                .get("b")
                .unwrap()
                .get()
                .lookups
                .borrow()
                .is_empty()
        );
        assert_eq!(
            store
                .select(&db, "INSERT INTO b SELECT f.k, f.x FROM a f")
                .unwrap(),
            Some(2)
        );
        assert_eq!(
            rows(&db, "SELECT k FROM b WHERE x = 7"),
            vec![vec![Value::Integer(1)]]
        );
        assert_eq!(
            rows(&db, "SELECT k FROM b WHERE x = 'text'"),
            vec![vec![Value::Integer(2)]]
        );
    }

    #[test]
    fn selection_budget_fallback_keeps_source_and_target_valid() {
        let (db, store) = connection(
            "/*FRAME*/a(k INTEGER PRIMARY KEY, x); /*FRAME*/b(k INTEGER PRIMARY KEY, x); INSERT INTO a VALUES (1, 7)",
        );
        store.retained.store(BUDGET * 8, Atomic::Relaxed);
        let sql = "INSERT INTO b SELECT f.k, f.x FROM a f";
        assert_eq!(store.select(&db, sql).unwrap(), None);
        assert_eq!(store.rows("b"), Some(0));
        db.execute_batch(sql).unwrap();
        assert_eq!(rows(&db, "SELECT * FROM b"), rows(&db, "SELECT * FROM a"));
        store.retained.store(0, Atomic::Relaxed);
    }

    /// A connection and its frame store, with `sql` run on it: its statements in order, a
    /// `FRAME` step registered.
    fn connection(sql: &str) -> (Connection, Arc<FrameStore>) {
        let store = Arc::new(FrameStore::default());
        let connection = Connection::open_in_memory().expect("opens");
        run(&connection, &store, sql);
        (connection, store)
    }

    fn run(connection: &Connection, store: &Arc<FrameStore>, sql: &str) {
        for statement in sql.split(';').map(str::trim).filter(|s| !s.is_empty()) {
            match statement.strip_prefix(FRAME) {
                Some(declaration) => {
                    store.register(connection, declaration).expect("registers");
                }
                None => connection.execute_batch(statement).expect("runs"),
            }
        }
    }

    fn rows(connection: &Connection, sql: &str) -> Vec<Vec<Value>> {
        let mut statement = connection.prepare(sql).expect("prepares");
        let width = statement.column_count();
        statement
            .query_map([], |row| {
                (0..width).map(|index| row.get::<_, Value>(index)).collect()
            })
            .expect("queries")
            .collect::<Result<_>>()
            .expect("rows")
    }

    #[test]
    fn a_rowid_frame_numbers_null_keys_and_scans_in_key_order() {
        let (connection, store) = connection(
            "/*FRAME*/f(k INTEGER PRIMARY KEY, file, node); \
             INSERT INTO f VALUES (5, 0, 50), (2, 0, 20); \
             INSERT INTO f SELECT NULL, 1, 60; \
             INSERT INTO f(file, node) VALUES (1, 70);",
        );
        assert_eq!(
            rows(&connection, "SELECT k, file, node FROM f"),
            [[2, 0, 20], [5, 0, 50], [6, 1, 60], [7, 1, 70]]
                .map(|row| row.map(Value::Integer).to_vec())
                .to_vec()
        );
        assert_eq!(
            rows(&connection, "SELECT node FROM f WHERE k = 5"),
            vec![vec![Value::Integer(50)]]
        );
        assert_eq!(
            rows(&connection, "SELECT rowid FROM f WHERE file = 1"),
            vec![vec![Value::Integer(6)], vec![Value::Integer(7)]]
        );
        assert!(store.clear("f"));
        connection
            .execute_batch("INSERT INTO f SELECT NULL, 3, 30")
            .expect("refills");
        assert_eq!(
            rows(&connection, "SELECT k, file FROM f"),
            vec![vec![Value::Integer(1), Value::Integer(3)]]
        );
    }

    #[test]
    fn a_duplicate_key_fails() {
        let (connection, _) = connection(
            "/*FRAME*/f(k INTEGER PRIMARY KEY, file); \
             INSERT INTO f VALUES (2, 0), (1, 0), (2, 1);",
        );
        assert!(
            connection
                .prepare("SELECT * FROM f")
                .expect("prepares")
                .query([])
                .expect("runs")
                .next()
                .is_err()
        );
    }

    #[test]
    fn defaults_apply_and_a_primary_key_orders_scans() {
        let (connection, _) = connection(
            "/*FRAME*/s(file INTEGER, node INTEGER, unk INTEGER NOT NULL DEFAULT 0, PRIMARY KEY (file, node)); \
             INSERT INTO s(file, node) VALUES (1, 4), (0, 9), (1, 2);",
        );
        assert_eq!(
            rows(&connection, "SELECT file, node, unk FROM s"),
            [[0, 9, 0], [1, 2, 0], [1, 4, 0]]
                .map(|row| row.map(Value::Integer).to_vec())
                .to_vec()
        );
        assert_eq!(
            rows(
                &connection,
                "SELECT unk FROM s WHERE file = '1' AND node = 4"
            ),
            vec![vec![Value::Integer(0)]]
        );
    }

    #[test]
    fn lookups_compare_as_sqlite_does() {
        let (connection, _) = connection(
            "/*FRAME*/f(k INTEGER PRIMARY KEY, file, node, s0); \
             INSERT INTO f SELECT NULL, 0, 1, NULL; \
             INSERT INTO f SELECT NULL, 0, 1, 'x'; \
             INSERT INTO f SELECT NULL, 0, 1, 3000000000; \
             INSERT INTO f SELECT NULL, 0, 1, 2.0; \
             CREATE TABLE p(v); INSERT INTO p VALUES (NULL), ('x'), (3000000000), (2), (7);",
        );
        assert_eq!(
            rows(
                &connection,
                "SELECT p.v, f.k FROM p JOIN f ON f.file = 0 AND f.node = 1 AND f.s0 IS p.v ORDER BY p.rowid"
            ),
            vec![
                vec![Value::Null, Value::Integer(1)],
                vec![Value::Text("x".into()), Value::Integer(2)],
                vec![Value::Integer(3_000_000_000), Value::Integer(3)],
                vec![Value::Integer(2), Value::Integer(4)],
            ]
        );
        assert_eq!(
            rows(
                &connection,
                "SELECT p.v, f.k FROM p JOIN f ON f.s0 = p.v ORDER BY p.rowid"
            )
            .len(),
            3
        );
    }

    #[test]
    fn a_frame_reads_itself_while_appending() {
        let (connection, store) = connection(
            "/*FRAME*/f(k INTEGER PRIMARY KEY, node); \
             INSERT INTO f(node) VALUES (1), (2); \
             INSERT INTO f SELECT NULL, node + 10 FROM f;",
        );
        assert_eq!(
            rows(&connection, "SELECT k, node FROM f"),
            [[1, 1], [2, 2], [3, 11], [4, 12]]
                .map(|row| row.map(Value::Integer).to_vec())
                .to_vec()
        );
        assert_eq!(store.peak(), 4);
    }

    /// What a frame write costs, by path: a TEMP B-tree's `INSERT … SELECT` (with its index), a
    /// frame's `INSERT … SELECT` (`xUpdate` per row), and a sink (the driver steps the `SELECT`
    /// and appends each row to the frame's buffers itself). Run by hand:
    /// `cargo test --release --lib sql::frames::tests::write_paths -- --ignored --nocapture`.
    #[test]
    #[ignore = "a measurement, run by hand"]
    fn write_paths() {
        const ROWS: i64 = 2_000_000;
        let (connection, store) = connection(
            "PRAGMA temp_store = MEMORY; \
             CREATE TEMP TABLE b(k INTEGER PRIMARY KEY, file, node, s0); \
             CREATE INDEX b_at ON b(file, node); \
             /*FRAME*/f(k INTEGER PRIMARY KEY, file, node, s0, INDEX (file, node)); \
             /*FRAME*/s(k INTEGER PRIMARY KEY, file, node, s0, INDEX (file, node));",
        );
        let source = format!(
            "WITH RECURSIVE g(i) AS (SELECT 1 UNION ALL SELECT i + 1 FROM g WHERE i < {ROWS}) \
             SELECT NULL, i / 1000, i, i % 7 FROM g"
        );
        let time = |label: &str, run: &mut dyn FnMut()| {
            let mut best = f64::MAX;
            for _ in 0..3 {
                let started = std::time::Instant::now();
                run();
                best = best.min(started.elapsed().as_secs_f64());
            }
            eprintln!(
                "{label}: {:.1} ns/row (best of 3)",
                best * 1e9 / ROWS as f64
            );
        };
        time("generate only", &mut || {
            let mut statement = connection.prepare_cached(&source).expect("prepares");
            let mut rows = statement.query([]).expect("runs");
            while rows.next().expect("a row").is_some() {}
        });
        time("B-tree INSERT … SELECT", &mut || {
            connection.execute("DELETE FROM b", []).expect("clears");
            connection
                .execute(&format!("INSERT INTO b {source}"), [])
                .expect("fills");
        });
        time("frame INSERT … SELECT (xUpdate)", &mut || {
            store.clear("f");
            connection
                .execute(&format!("INSERT INTO f {source}"), [])
                .expect("fills");
        });
        let shared = Arc::clone(store.frames.lock().get("s").expect("frame s"));
        time("frame sink (driver appends)", &mut || {
            store.clear("s");
            let mut statement = connection.prepare_cached(&source).expect("prepares");
            let width = statement.column_count();
            let mut rows = statement.query([]).expect("runs");
            // SAFETY: no statement reads `s` while it is filled.
            let frame = unsafe { shared.get_mut() };
            while let Some(row) = rows.next().expect("a row") {
                let at = frame.len;
                for column in 0..width {
                    let value = row.get_ref(column).expect("a value");
                    let value = if column == 0 {
                        ValueRef::Integer(at as i64 + 1)
                    } else {
                        value
                    };
                    frame.columns[column].push(at, value);
                }
                frame.len += 1;
            }
            store.live.fetch_add(frame.len, Atomic::Relaxed);
        });
        assert_eq!(
            rows(&connection, "SELECT count(*) FROM f"),
            rows(&connection, "SELECT count(*) FROM s")
        );
    }
    #[test]
    fn joined_selections_keep_constants_types_and_duplicate_key_semantics() {
        let (db, store) = connection(
            "/*FRAME*/a(k INTEGER PRIMARY KEY, x); /*FRAME*/b(k INTEGER PRIMARY KEY, x, unk); CREATE TABLE accept(k); INSERT INTO a VALUES (1, NULL), (2, 'text'), (3, 9223372036854775807); INSERT INTO accept VALUES(2), (3)",
        );
        assert!(rows(&db, "SELECT * FROM b WHERE x = 7").is_empty());
        let sql = "INSERT INTO b SELECT f.k, f.x, 0 FROM a f JOIN accept p ON p.k = f.k";
        assert_eq!(store.select(&db, sql).unwrap(), Some(2));
        assert_eq!(
            rows(&db, "SELECT * FROM b"),
            rows(
                &db,
                "SELECT f.k, f.x, 0 FROM a f JOIN accept p ON p.k = f.k"
            )
        );
        assert_eq!(
            rows(&db, "SELECT k FROM b WHERE x = 'text'"),
            vec![vec![Value::Integer(2)]]
        );
        store.clear("b");
        db.execute_batch("INSERT INTO accept VALUES (2)").unwrap();
        assert_eq!(store.select(&db, sql).unwrap(), None);
        assert_eq!(store.rows("b"), Some(0));
        assert_eq!(rows(&db, "SELECT * FROM a").len(), 3);
    }

    #[test]
    fn computed_captures_share_metadata_and_keep_sqlite_value_types() {
        let (db, store) = connection(
            "/*FRAME*/a(k INTEGER PRIMARY KEY, x); /*FRAME*/b(k INTEGER PRIMARY KEY, x, capture, literal); CREATE TABLE captures(k, value); INSERT INTO a VALUES (1, NULL), (2, 'text'), (3, 9223372036854775807); INSERT INTO captures VALUES(1, X'0102'), (2, 3.5), (3, NULL)",
        );
        let select = "SELECT f.k, f.x, COALESCE(p.value, f.x), 'a,b)''c' FROM a f JOIN captures p ON p.k = f.k";
        let expected = rows(&db, select);
        assert_eq!(
            store
                .select(&db, &format!("INSERT INTO b {select}"))
                .unwrap(),
            Some(3)
        );
        assert_eq!(rows(&db, "SELECT * FROM b"), expected);
        {
            let frames = store.frames.lock();
            let frame = frames.get("b").unwrap().get();
            assert!(frame.columns[1].data.is_shared());
            assert!(matches!(frame.columns[2].data, Data::Any(..)));
        }
        store.clear("a");
        assert_eq!(rows(&db, "SELECT * FROM b"), expected);
        store
            .register(&db, "c(k INTEGER PRIMARY KEY, x INTEGER)")
            .unwrap();
        assert_eq!(
            store
                .select(&db, "INSERT INTO c SELECT f.k, '12' FROM b f")
                .unwrap(),
            None
        );
        assert_eq!(
            store
                .select(&db, "INSERT INTO c SELECT f.k, count(*) FROM b f")
                .unwrap(),
            None
        );
    }

    #[test]
    fn shared_negative_row_keys_append_as_sqlite_does() {
        let (db, store) = connection(
            "/*FRAME*/a(k INTEGER PRIMARY KEY, x); /*FRAME*/b(k INTEGER PRIMARY KEY, x); CREATE TABLE expected(k INTEGER PRIMARY KEY, x); INSERT INTO a VALUES(-3, 'first'), (-2, 'second'); INSERT INTO expected SELECT * FROM a",
        );
        assert_eq!(
            store
                .select(&db, "INSERT INTO b SELECT f.k, f.x FROM a f")
                .unwrap(),
            Some(2)
        );
        store.clear("a");
        db.execute_batch(
            "INSERT INTO b(x) VALUES('appended'); INSERT INTO expected(x) VALUES('appended')",
        )
        .unwrap();
        assert_eq!(
            rows(&db, "SELECT * FROM b"),
            rows(&db, "SELECT * FROM expected")
        );
    }

    #[test]
    fn projection_sources_respect_subqueries_and_quoted_clauses() {
        let (db, store) = connection(
            "/*FRAME*/a(k INTEGER PRIMARY KEY, x); /*FRAME*/q(k INTEGER PRIMARY KEY, x); /*FRAME*/b(k INTEGER PRIMARY KEY, x, capture); INSERT INTO a VALUES(10, 'inner'), (20, 'inner2'); INSERT INTO q VALUES(1, 'outer'), (2, 'outer2')",
        );
        let select = "SELECT f.k, f.x, (SELECT f.x FROM a f WHERE f.k = 10) FROM q f";
        let expected = rows(&db, select);
        let sql = format!("INSERT INTO b {select}");
        assert_eq!(store.select(&db, &sql).unwrap(), None);
        assert_eq!(store.rows("b"), Some(0));
        db.execute_batch(&sql).unwrap();
        assert_eq!(rows(&db, "SELECT * FROM b"), expected);
        store.clear("b");
        let select = "SELECT f.k, f.x, 'literal FROM a f WHERE ignored' FROM q f";
        let expected = rows(&db, select);
        assert_eq!(
            store
                .select(&db, &format!("INSERT INTO b {select}"))
                .unwrap(),
            Some(2)
        );
        assert_eq!(rows(&db, "SELECT * FROM b"), expected);
    }
}
