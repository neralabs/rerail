//! Atomic pattern, value, and capture-equality leaves. SQL owns all relation and Boolean composition.
use super::super::{exec::Batch, terminals::Terminal};
use crate::code_rule_dsl::matcher::node_at;
use ast_grep_core::matcher::MatcherExt;
use rusqlite::{Connection, Error, Result, functions::FunctionFlags};
use std::{
    panic::AssertUnwindSafe,
    sync::{
        Arc,
        atomic::{AtomicUsize, Ordering},
    },
};

thread_local! {
    pub(super) static VALUE_REQUESTS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
    pub(super) static EQUALITY_REQUESTS: std::cell::Cell<usize> = const { std::cell::Cell::new(0) };
}

struct Leaves(AssertUnwindSafe<Arc<Batch>>);
impl Leaves {
    fn pattern(&self, term: usize, file: usize, node: u32) -> Result<bool> {
        let Some(Terminal::Pattern(term)) = self.0.program.terminals.get(term) else {
            return Err(Error::ModuleError(
                "relational pattern: invalid terminal".into(),
            ));
        };
        if !term.vars.is_empty() {
            return Err(Error::ModuleError(
                "relational pattern: capture-bearing terminal".into(),
            ));
        }
        if let Some(file) = self.0.files.get(file) {
            return Ok(node < file.facts.len()
                && term.pattern.match_node(node_at(&file.root, node)).is_some());
        }
        let Some(sub) = self.0.subfile(file) else {
            return Ok(false);
        };
        Ok(node < sub.facts.len()
            && term
                .pattern
                .match_node(sub.root.adopt(sub.root.root().get_doc().node(node)))
                .is_some())
    }
}

pub(in crate::code_rule_dsl::sql) fn register(
    db: &Connection,
    batch: &Arc<Batch>,
) -> Result<Arc<AtomicUsize>> {
    super::row::register(db)?;
    super::file_guard::register(db, batch)?;
    super::sibling_state::register(db)?;
    super::capture_cell::register(db)?;
    super::capture_state::register(db)?;
    super::bound_leaf::register(db, batch)?;
    super::memo_store::register(db)?;
    super::budget_leaf::register(db, batch)?;
    super::parse_facts::register(db, batch)?;
    super::parse_export::register(db, batch)?;
    super::call_unify::register(db, batch)?;
    super::format_facts::register(db, batch)?;
    super::outcomes::register_binding_facts(db, batch)?;
    let calls = Arc::new(AtomicUsize::new(0));
    super::pattern_leaf::register(db, batch, &calls)?;
    let leaves = Leaves(AssertUnwindSafe(Arc::clone(batch)));
    let count = Arc::clone(&calls);
    let keys = Leaves(AssertUnwindSafe(Arc::clone(batch)));
    let equality = Leaves(AssertUnwindSafe(Arc::clone(batch)));
    // Atomic structural equality, with native capture semantics. No rule composition runs here.
    db.create_scalar_function(
        "relation_capture_equal",
        3,
        FunctionFlags::SQLITE_UTF8,
        move |ctx| {
            let file = ctx.get::<u32>(0)? as usize;
            EQUALITY_REQUESTS.set(EQUALITY_REQUESTS.get() + 1);
            let left_cell = ctx.get::<super::capture_cell::Cell>(1)?;
            let right_cell = ctx.get::<super::capture_cell::Cell>(2)?;
            for cell in [&left_cell, &right_cell] {
                if let super::capture_cell::Cell::Span(bytes) = cell
                    && super::span_capture::decode(bytes)?.file != file as u32
                {
                    return Err(Error::ModuleError(
                        "capture equality: span belongs to another document".into(),
                    ));
                }
            }
            let Some(left) = left_cell.single_node()? else {
                return Ok(true);
            };
            let Some(right) = right_cell.single_node()? else {
                return Ok(true);
            };
            if let Some(file) = equality.0.files.get(file) {
                if left >= file.facts.len() || right >= file.facts.len() {
                    return Err(Error::ModuleError("capture equality: invalid node".into()));
                }
                let mut env = ast_grep_core::meta_var::MetaVarEnv::new();
                env.insert("capture", node_at(&file.root, left));
                return Ok(env.insert("capture", node_at(&file.root, right)).is_some());
            }
            let sub = equality
                .0
                .subfile(file)
                .ok_or_else(|| Error::ModuleError("capture equality: invalid file".into()))?;
            if left >= sub.facts.len() || right >= sub.facts.len() {
                return Err(Error::ModuleError(
                    "capture equality: invalid parsed node".into(),
                ));
            }
            let at = |id| sub.root.adopt(sub.root.root().get_doc().node(id));
            let mut env = ast_grep_core::meta_var::MetaVarEnv::new();
            env.insert("capture", at(left));
            Ok(env.insert("capture", at(right)).is_some())
        },
    )?;
    db.create_scalar_function(
        "relation_leaf_atom",
        3,
        FunctionFlags::SQLITE_UTF8,
        move |ctx| {
            let file = ctx.get::<u32>(0)? as usize;
            let node = ctx.get::<u32>(1)?;
            let named_leaf = if let Some(file) = keys.0.files.get(file) {
                node < file.facts.len() && node_at(&file.root, node).is_named_leaf()
            } else if let Some(sub) = keys.0.subfile(file) {
                node < sub.facts.len()
                    && sub
                        .root
                        .adopt(sub.root.root().get_doc().node(node))
                        .is_named_leaf()
            } else {
                return Err(Error::ModuleError("capture demand: missing file".into()));
            };
            if !named_leaf {
                return Err(Error::ModuleError(
                    "capture demand: composite capture requires structural equality keys".into(),
                ));
            }
            ctx.get::<u32>(2)
        },
    )?;
    db.create_scalar_function(
        "relation_pattern",
        3,
        FunctionFlags::SQLITE_UTF8,
        move |ctx| {
            count.fetch_add(1, Ordering::Relaxed);
            leaves.pattern(
                ctx.get::<u32>(0)? as usize,
                ctx.get::<u32>(1)? as usize,
                ctx.get(2)?,
            )
        },
    )?;
    Ok(calls)
}
