WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n WHERE 1 AND n.kind IN (196)
),
outcome1 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work FROM outcome0 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1 FROM outcome1 w CROSS JOIN outcome0 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0 AND (n.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,50 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 6 THEN n.kind IN (226) WHEN 9 THEN n.kind IN (193) WHEN 11 THEN node_regex(0,n.file,n.id) WHEN 13 THEN n.kind IN (192) WHEN 16 THEN n.kind IN (149) WHEN 18 THEN (node_regex(1,n.file,n.id) OR node_regex(2,n.file,n.id) OR n.kind IN (99)) WHEN 20 THEN n.kind IN (220) WHEN 21 THEN (node_regex(1,n.file,n.id) OR n.kind IN (99)) WHEN 23 THEN n.kind IN (219) WHEN 25 THEN (node_regex(1,n.file,n.id) OR node_regex(2,n.file,n.id) OR n.kind IN (99)) WHEN 27 THEN n.kind IN (216,218) WHEN 31 THEN n.kind IN (88,93,94,96,97,98) WHEN 34 THEN n.kind IN (231,232) WHEN 36 THEN n.kind IN (232) WHEN 38 THEN n.kind IN (231) WHEN 40 THEN n.kind IN (232) WHEN 41 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE a0n1.kind IN (104) AND node_regex(3,a0n1.file,a0n1.id)) WHEN 44 THEN n.kind IN (232) WHEN 46 THEN n.kind IN (231) WHEN 48 THEN n.kind IN (232) WHEN 49 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE a0n1.kind IN (104) AND node_regex(4,a0n1.file,a0n1.id)) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 12 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 19 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 26 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 37 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) WHEN 45 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 8 THEN 1 WHEN 12 THEN 1 WHEN 15 THEN 1 WHEN 19 THEN 1 WHEN 22 THEN 1 WHEN 26 THEN 1 WHEN 37 THEN 1 WHEN 45 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 12 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 19 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 26 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 37 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) WHEN 45 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome3 s
) SELECT o.truth,o.work FROM outcome4 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n."end">n.start THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome5 o ON o.parent=d.k
),
outcome7 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome6
) SELECT o.truth,o.work FROM outcome7 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,50 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome1 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 6 THEN n.kind IN (226) WHEN 9 THEN n.kind IN (193) WHEN 11 THEN node_regex(0,n.file,n.id) WHEN 13 THEN n.kind IN (192) WHEN 16 THEN n.kind IN (149) WHEN 18 THEN (node_regex(1,n.file,n.id) OR node_regex(2,n.file,n.id) OR n.kind IN (99)) WHEN 20 THEN n.kind IN (220) WHEN 21 THEN (node_regex(1,n.file,n.id) OR n.kind IN (99)) WHEN 23 THEN n.kind IN (219) WHEN 25 THEN (node_regex(1,n.file,n.id) OR node_regex(2,n.file,n.id) OR n.kind IN (99)) WHEN 27 THEN n.kind IN (216,218) WHEN 31 THEN n.kind IN (88,93,94,96,97,98) WHEN 34 THEN n.kind IN (231,232) WHEN 36 THEN n.kind IN (232) WHEN 38 THEN n.kind IN (231) WHEN 40 THEN n.kind IN (232) WHEN 41 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE a0n1.kind IN (104) AND node_regex(3,a0n1.file,a0n1.id)) WHEN 44 THEN n.kind IN (232) WHEN 46 THEN n.kind IN (231) WHEN 48 THEN n.kind IN (232) WHEN 49 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE a0n1.kind IN (104) AND node_regex(4,a0n1.file,a0n1.id)) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome2 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome2 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome2 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 12 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 19 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 26 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 37 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) WHEN 45 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 8 THEN 1 WHEN 12 THEN 1 WHEN 15 THEN 1 WHEN 19 THEN 1 WHEN 22 THEN 1 WHEN 26 THEN 1 WHEN 37 THEN 1 WHEN 45 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome2 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome2 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome2 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 12 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (88,93,94,96,97,98,192,193,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 19 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 26 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 37 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) WHEN 45 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome2 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome3 AS MATERIALIZED (
SELECT k,work,truth FROM outcome2 WHERE pc IS NULL
),
outcome4 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome3
) SELECT o.truth,o.work FROM outcome4 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n."end">n.start THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome5 o ON o.parent=d.k
),
outcome7 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome6
) SELECT o.truth,o.work FROM outcome7 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0 AND (n.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232))
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,50 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 6 THEN n.kind IN (226) WHEN 9 THEN n.kind IN (193) WHEN 11 THEN node_regex(0,n.file,n.id) WHEN 13 THEN n.kind IN (192) WHEN 16 THEN n.kind IN (149) WHEN 18 THEN (node_regex(1,n.file,n.id) OR node_regex(2,n.file,n.id) OR n.kind IN (99)) WHEN 20 THEN n.kind IN (220) WHEN 21 THEN (node_regex(1,n.file,n.id) OR n.kind IN (99)) WHEN 23 THEN n.kind IN (219) WHEN 25 THEN (node_regex(1,n.file,n.id) OR node_regex(2,n.file,n.id) OR n.kind IN (99)) WHEN 27 THEN n.kind IN (216,218) WHEN 28 THEN ((n.kind IN (1) AND node_regex(6,n.file,n.id)) OR (n.kind IN (204) AND EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id CROSS JOIN node AS a0n2 ON a0n2.file=a0n1.file AND a0n2.id=a0n1.prev WHERE a0n1.kind IN (1) AND node_regex(6,a0n1.file,a0n1.id) AND node_regex(7,a0n2.file,a0n2.id)))) WHEN 31 THEN n.kind IN (88,93,94,96,97,98) WHEN 34 THEN n.kind IN (231,232) WHEN 36 THEN n.kind IN (232) WHEN 38 THEN n.kind IN (231) WHEN 40 THEN n.kind IN (232) WHEN 41 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE a0n1.kind IN (104) AND node_regex(3,a0n1.file,a0n1.id)) WHEN 44 THEN n.kind IN (232) WHEN 46 THEN n.kind IN (231) WHEN 48 THEN n.kind IN (232) WHEN 49 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE a0n1.kind IN (104) AND node_regex(4,a0n1.file,a0n1.id)) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_2 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_2 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_2 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 12 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 19 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 26 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 37 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) WHEN 45 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 8 THEN 1 WHEN 12 THEN 1 WHEN 15 THEN 1 WHEN 19 THEN 1 WHEN 22 THEN 1 WHEN 26 THEN 1 WHEN 37 THEN 1 WHEN 45 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 12 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 19 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 26 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 37 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) WHEN 45 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome3 s
) SELECT o.truth,o.work FROM outcome4 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.prev WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n."end">n.start THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome5 o ON o.parent=d.k
),
outcome7 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome6
) SELECT o.truth,o.work FROM outcome7 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,50 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome1 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 6 THEN n.kind IN (226) WHEN 9 THEN n.kind IN (193) WHEN 11 THEN node_regex(0,n.file,n.id) WHEN 13 THEN n.kind IN (192) WHEN 16 THEN n.kind IN (149) WHEN 18 THEN (node_regex(1,n.file,n.id) OR node_regex(2,n.file,n.id) OR n.kind IN (99)) WHEN 20 THEN n.kind IN (220) WHEN 21 THEN (node_regex(1,n.file,n.id) OR n.kind IN (99)) WHEN 23 THEN n.kind IN (219) WHEN 25 THEN (node_regex(1,n.file,n.id) OR node_regex(2,n.file,n.id) OR n.kind IN (99)) WHEN 27 THEN n.kind IN (216,218) WHEN 28 THEN ((n.kind IN (1) AND node_regex(6,n.file,n.id)) OR (n.kind IN (204) AND EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id CROSS JOIN node AS a0n2 ON a0n2.file=a0n1.file AND a0n2.id=a0n1.prev WHERE a0n1.kind IN (1) AND node_regex(6,a0n1.file,a0n1.id) AND node_regex(7,a0n2.file,a0n2.id)))) WHEN 31 THEN n.kind IN (88,93,94,96,97,98) WHEN 34 THEN n.kind IN (231,232) WHEN 36 THEN n.kind IN (232) WHEN 38 THEN n.kind IN (231) WHEN 40 THEN n.kind IN (232) WHEN 41 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE a0n1.kind IN (104) AND node_regex(3,a0n1.file,a0n1.id)) WHEN 44 THEN n.kind IN (232) WHEN 46 THEN n.kind IN (231) WHEN 48 THEN n.kind IN (232) WHEN 49 THEN EXISTS (SELECT 1 FROM (SELECT 1) AS unit0 CROSS JOIN node AS a0n1 ON a0n1.file=n.file AND a0n1.parent=n.id WHERE a0n1.kind IN (104) AND node_regex(4,a0n1.file,a0n1.id)) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome2 w JOIN constant0_3 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome2 w JOIN constant0_3 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome2 w JOIN constant0_3 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 12 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 19 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 26 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 37 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) WHEN 45 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 8 THEN 1 WHEN 12 THEN 1 WHEN 15 THEN 1 WHEN 19 THEN 1 WHEN 22 THEN 1 WHEN 26 THEN 1 WHEN 37 THEN 1 WHEN 45 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome2 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome2 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome2 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 8 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 12 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 15 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (1,88,93,94,96,97,98,192,193,204,216,218,219,226,231,232)) ORDER BY candidate.id LIMIT 1) WHEN 19 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 22 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 26 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 37 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) WHEN 45 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (candidate.kind IN (232)) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome2 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome3 AS MATERIALIZED (
SELECT k,work,truth FROM outcome2 WHERE pc IS NULL
),
outcome4 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome3
) SELECT o.truth,o.work FROM outcome4 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work FROM outcome0 d WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome1 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.next WHERE 1
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN n."end">n.start THEN 1 ELSE 0 END AS truth FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome2 d JOIN outcome3 o ON o.k=d.k WHERE o.truth<>0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE choice=1
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome1 d LEFT JOIN outcome5 o ON o.parent=d.k
),
outcome7 AS MATERIALIZED (
SELECT k,work,CASE truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE truth END AS truth FROM outcome6
) SELECT o.truth,o.work FROM outcome7 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,COALESCE(r.c1,0) AS work,CASE WHEN d.work=0 THEN -2 ELSE r.c0 END AS truth FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work WHERE d.work>0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.work,CASE WHEN node_regex(8,n.file,n.id) THEN 1 ELSE 0 END AS truth FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS (
SELECT d.parent,o.truth,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY CASE o.truth WHEN 1 THEN 0 ELSE 1 END,d.rank) AS choice FROM outcome1 d JOIN outcome2 o ON o.k=d.k WHERE o.truth<>0
),
outcome4 AS MATERIALIZED (
SELECT * FROM outcome3 WHERE choice=1
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth FROM outcome0 d LEFT JOIN outcome4 o ON o.parent=d.k
) SELECT o.truth,o.work FROM outcome5 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, CASE WHEN w.stopped<0 THEN 0 WHEN w.work=0 THEN -2 ELSE COALESCE(r.c0,0) END,w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work) FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1) IS (SELECT CASE WHEN node_regex(9,probe.file,probe.id) THEN 1 ELSE 0 END,w.work-1 FROM node probe WHERE probe.file=w.file AND probe.id=n.id AND (w.stopped>=0 AND w.work>0)) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>1)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR ((w.low+(w.own=1))>1)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<0) OR COALESCE(t.low,0)>1 THEN 0 WHEN COALESCE(t.low,0)>=0 AND (NOT COALESCE(t.open,0) AND (COALESCE(t.low,0)+COALESCE(t.uncertain,0))<=1) AND (1) THEN 1 ELSE 2 END END AS truth FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome7 s
) SELECT o.truth,o.work FROM outcome8 o)
) SELECT o.truth,o.work FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth FROM outcome5 s
) SELECT o.truth,o.work FROM outcome6 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,29,0,1),(5,6,4,0,1),(6,4,5,1,0),(7,5,29,0,1),(8,6,7,0,6),(9,4,8,6,0),(10,5,29,1,0),(11,4,1,10,0),(12,6,11,9,0),(13,4,12,9,0),(14,5,29,0,1),(15,6,14,1,0),(16,4,15,0,0),(17,5,29,1,0),(18,4,1,17,0),(19,6,18,16,1),(20,4,19,16,0),(21,4,1,20,0),(22,6,21,13,0),(23,4,22,13,0),(24,5,29,1,0),(25,4,1,24,0),(26,6,25,23,0),(27,4,26,23,0),(28,5,31,0,27),(29,5,31,0,28),(30,5,34,0,1),(31,4,0,30,0),(32,5,48,1,0),(33,5,40,1,32),(34,4,33,1,0),(35,5,41,0,1),(36,4,35,1,0),(37,6,36,0,1),(38,4,37,1,0),(39,5,41,0,38),(40,4,39,38,0),(41,4,0,1,0),(42,5,40,1,0),(43,5,49,0,1),(44,4,43,1,0),(45,6,44,42,1),(46,4,45,1,0),(47,5,49,42,46),(48,4,47,46,0),(49,4,0,1,0),(50,5,29,0,1))),
constant0_1 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,29,0,1),(5,6,4,0,1),(6,4,5,1,0),(7,5,29,0,1),(8,6,7,0,6),(9,4,8,6,0),(10,5,29,1,0),(11,4,1,10,0),(12,6,11,9,0),(13,4,12,9,0),(14,5,29,0,1),(15,6,14,1,0),(16,4,15,0,0),(17,5,29,1,0),(18,4,1,17,0),(19,6,18,16,1),(20,4,19,16,0),(21,4,1,20,0),(22,6,21,13,0),(23,4,22,13,0),(24,5,29,1,0),(25,4,1,24,0),(26,6,25,23,0),(27,4,26,23,0),(28,5,31,0,27),(29,5,31,0,28),(30,5,34,0,1),(31,4,0,30,0),(32,5,48,1,0),(33,5,40,1,32),(34,4,33,1,0),(35,5,41,0,1),(36,4,35,1,0),(37,6,36,0,1),(38,4,37,1,0),(39,5,41,0,38),(40,4,39,38,0),(41,4,0,1,0),(42,5,40,1,0),(43,5,49,0,1),(44,4,43,1,0),(45,6,44,42,1),(46,4,45,1,0),(47,5,49,42,46),(48,4,47,46,0),(49,4,0,1,0),(50,5,29,0,1))),
constant0_2 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,29,0,1),(5,6,4,0,1),(6,4,5,1,0),(7,5,29,0,1),(8,6,7,0,6),(9,4,8,6,0),(10,5,29,1,0),(11,4,1,10,0),(12,6,11,9,0),(13,4,12,9,0),(14,5,29,0,1),(15,6,14,1,0),(16,4,15,0,0),(17,5,29,1,0),(18,4,1,17,0),(19,6,18,16,1),(20,4,19,16,0),(21,4,1,20,0),(22,6,21,13,0),(23,4,22,13,0),(24,5,29,1,0),(25,4,1,24,0),(26,6,25,23,0),(27,4,26,23,0),(28,4,0,27,0),(29,5,31,0,28),(30,5,34,0,1),(31,4,0,30,0),(32,5,48,1,0),(33,5,40,1,32),(34,4,33,1,0),(35,5,41,0,1),(36,4,35,1,0),(37,6,36,0,1),(38,4,37,1,0),(39,5,41,0,38),(40,4,39,38,0),(41,4,0,1,0),(42,5,40,1,0),(43,5,49,0,1),(44,4,43,1,0),(45,6,44,42,1),(46,4,45,1,0),(47,5,49,42,46),(48,4,47,46,0),(49,4,0,1,0),(50,5,29,0,1))),
constant0_3 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,29,0,1),(5,6,4,0,1),(6,4,5,1,0),(7,5,29,0,1),(8,6,7,0,6),(9,4,8,6,0),(10,5,29,1,0),(11,4,1,10,0),(12,6,11,9,0),(13,4,12,9,0),(14,5,29,0,1),(15,6,14,1,0),(16,4,15,0,0),(17,5,29,1,0),(18,4,1,17,0),(19,6,18,16,1),(20,4,19,16,0),(21,4,1,20,0),(22,6,21,13,0),(23,4,22,13,0),(24,5,29,1,0),(25,4,1,24,0),(26,6,25,23,0),(27,4,26,23,0),(28,4,0,27,0),(29,5,31,0,28),(30,5,34,0,1),(31,4,0,30,0),(32,5,48,1,0),(33,5,40,1,32),(34,4,33,1,0),(35,5,41,0,1),(36,4,35,1,0),(37,6,36,0,1),(38,4,37,1,0),(39,5,41,0,38),(40,4,39,38,0),(41,4,0,1,0),(42,5,40,1,0),(43,5,49,0,1),(44,4,43,1,0),(45,6,44,42,1),(46,4,45,1,0),(47,5,49,42,46),(48,4,47,46,0),(49,4,0,1,0),(50,5,29,0,1))),
outcome6 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work FROM outcome1 o WHERE o.truth=1 OR o.truth<0
),
outcome7 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome6 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array() END AS payload,0 AS failure,m.work FROM outcome6 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome7 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome7
ORDER BY 1,2,3