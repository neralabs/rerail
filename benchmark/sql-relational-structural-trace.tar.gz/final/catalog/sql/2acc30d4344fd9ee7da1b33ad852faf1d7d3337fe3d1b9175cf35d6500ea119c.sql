WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM node AS a0n0 CROSS JOIN node AS a0n1 ON a0n1.file=a0n0.file AND a0n1.id=a0n0.parent CROSS JOIN node AS a0n2 ON a0n2.file=a0n0.file AND a0n2.id=a0n0.prev WHERE a0n0.kind IN (1) AND node_regex(0,a0n0.file,a0n0.id) AND a0n1.kind IN (154) AND node_regex(1,a0n2.file,a0n2.id)
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node