WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM r1 AS seed0 CROSS JOIN node AS a0n0 ON a0n0.file=seed0.file AND a0n0.id=seed0.node WHERE relation_pattern(0,a0n0.file,a0n0.id) AND a0n0.kind IN (204)
),
-- utility[1]
r1(file,node) AS MATERIALIZED (
SELECT a1n0.file,a1n0.id FROM r2 AS seed1 CROSS JOIN node AS a1n1 ON a1n1.file=seed1.file AND a1n1.id=seed1.node CROSS JOIN node AS a1n0 ON a1n0.file=a1n1.file AND a1n0.parent=a1n1.id CROSS JOIN node AS a1n2 ON a1n2.file=a1n0.file AND a1n2.id=a1n0.next WHERE node_regex(2,a1n2.file,a1n2.id)
UNION
SELECT a2n0.file,a2n0.id FROM r1 AS seed2 CROSS JOIN node AS a2n1 ON a2n1.file=seed2.file AND a2n1.id=seed2.node CROSS JOIN node AS a2n0 ON a2n0.file=a2n1.file AND a2n0.parent=a2n1.id WHERE a2n1.kind IN (226)
UNION
SELECT a3n0.file,a3n0.id FROM r1 AS seed3 CROSS JOIN node AS a3n1 ON a3n1.file=seed3.file AND a3n1.id=seed3.node CROSS JOIN node AS a3n0 ON a3n0.file=a3n1.file AND a3n0.parent=a3n1.id WHERE a3n1.kind IN (180) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit4 CROSS JOIN node AS a4n1 ON a4n1.file=a3n1.file AND a4n1.parent=a3n1.id WHERE node_regex(3,a4n1.file,a4n1.id)))
),
-- utility[0]
r2(file,node) AS MATERIALIZED (
SELECT a5n0.file,a5n0.id FROM node AS a5n0 WHERE a5n0.kind IN (199) AND NOT ((EXISTS (SELECT 1 FROM (SELECT 1) AS unit6 CROSS JOIN node AS a6n1 ON a6n1.file=a5n0.file AND a6n1.parent=a5n0.id WHERE node_regex(1,a6n1.file,a6n1.id)) OR EXISTS (SELECT 1 FROM (SELECT 1) AS unit7 CROSS JOIN node AS a7n1 ON a7n1.file=a5n0.file AND a7n1.parent=a5n0.id WHERE a7n1.kind IN (199)) OR EXISTS (SELECT 1 FROM (SELECT 1) AS unit8 CROSS JOIN node AS a8n1 ON a8n1.file=a5n0.file AND a8n1.id=a5n0.parent WHERE a8n1.kind IN (199))))
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node