WITH RECURSIVE
outcome0 AS MATERIALIZED (
SELECT relation_memo_reset(0) AS ready
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,n.file,n.id AS node,9223372036854775807 AS work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) AS ordinal FROM node n CROSS JOIN outcome0 init ON init.ready=1 WHERE 1 AND 1
),
outcome2 AS (
SELECT NULL AS k,file,NULL AS node,0 AS ordinal,0 AS truth,9223372036854775807 AS work,NULL AS c0,NULL AS c3 FROM outcome1 GROUP BY file
UNION ALL
SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2,r.c3 FROM outcome2 w CROSS JOIN outcome1 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,w.work AS work WHERE 1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,NULL AS c0,NULL AS c3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c3 AS c3 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c3 AS c3,0 AS u0 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c3 AS c3 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,34 AS pc,d.work,(0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 8 THEN node_regex(0,n.file,n.id) WHEN 11 THEN n.kind IN (226) WHEN 12 THEN n.kind IN (216,217,219,221,222,223) WHEN 16 THEN node_regex(1,n.file,n.id) WHEN 19 THEN n.kind IN (218) WHEN 22 THEN n.kind IN (226) WHEN 23 THEN n.kind IN (88,93,94,96,97,98) WHEN 24 THEN n.kind IN (234) WHEN 26 THEN n.kind IN (231) WHEN 27 THEN n.kind IN (234) WHEN 29 THEN n.kind IN (232) WHEN 32 THEN n.kind IN (226) WHEN 33 THEN n.kind IN (88,96,97,98) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1 AND CASE WHEN w.pc IN (4,6,9,13,14,15,17,20,30,34) AND w.level<256 THEN relation_peak_note(w.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_0 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN n.next WHEN 7 THEN n.prev WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 7 THEN 1 WHEN 10 THEN 1 WHEN 18 THEN 1 WHEN 21 THEN 1 WHEN 25 THEN 1 WHEN 28 THEN 1 WHEN 31 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN NULL WHEN 7 THEN NULL WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c3 AS c3,d.u0 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c3 AS c3 WHERE d.truth>0 AND NOT (d.u0)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0,d.c3 AS c3 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.id=origin.parent WHERE n.kind IN (196)
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c3 AS c3,0 AS u0 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN n.named AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c0,d.node) ELSE d.c0 END AS c0,d.c3 AS c3,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c3 AS c3,d.u0 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,o.c0 AS c0,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c0 ELSE d.c0 END AS c0 FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome10 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,d.c3 AS c3,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0 FROM outcome6 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,d.c3 AS c3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0,r.c3 AS e3 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c3 AS c3 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c0 AS truth,r.c1 AS work,r.c2 AS c0,r.c3 AS c3 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0,d.c3 AS c3
),
outcome1 AS MATERIALIZED (
SELECT d.*,(0) AS incoming,m.truth AS hit,m.cost,m.peak,CASE WHEN m.truth IS NOT NULL THEN relation_capture_replay(d.file,d.c0,m.o0) END AS hit0,CASE WHEN m.truth IS NOT NULL THEN relation_capture_replay(d.file,d.c3,m.o1) END AS hit3 FROM outcome0 d LEFT JOIN relation_memo m ON m.mode IS 0 AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS relation_capture_key(d.c0) AND m.k1 IS relation_capture_key(d.c3) AND m.peak<=256-(0)
),
outcome2 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NULL AND d.incoming<256 THEN relation_peak_open(d.incoming) END AS peak_token FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN relation_peak_note(d.incoming+d.peak) WHEN d.peak_token IS NOT NULL THEN relation_peak_note(d.incoming+1) ELSE 1 END AS peak_ready FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.hit IS NOT NULL THEN CASE WHEN d.work<d.cost THEN -2 ELSE d.hit END WHEN d.incoming>=256 THEN -1 WHEN d.work=0 THEN -2 ELSE r.c0 END AS tested,CASE WHEN d.hit IS NOT NULL THEN MAX(0,d.work-d.cost) WHEN d.incoming>=256 THEN d.work WHEN d.work=0 THEN 0 ELSE r.c1 END AS remaining,CASE WHEN d.hit IS NOT NULL THEN d.hit0 ELSE r.c2 END AS e0,CASE WHEN d.hit IS NOT NULL THEN d.hit3 ELSE r.c3 END AS e3,COALESCE(r.c4,0) AS fill_cost FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4) IS (WITH fill_before AS MATERIALIZED (SELECT relation_cache_fill_steps() AS start WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1),
fill_result AS MATERIALIZED (SELECT b.start,r.c0,r.c1,r.c2,r.c3 FROM fill_before b CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work-1 AS work,d.c0 AS c0,d.c3 AS c3 WHERE d.hit IS NULL AND d.incoming<256 AND d.work>0 AND d.peak_ready=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c3 AS c3,0 AS u0,0 AS u3 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e0,r.c3 AS e3 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c3 AS c3 WHERE d.truth>0 AND NOT (d.u0 OR d.u3)
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 AS work,r.c0 AS truth,r.c2 AS c0,r.c3 AS c3 FROM outcome0 d JOIN node parse_kind ON parse_kind.file=d.file AND parse_kind.id=d.node CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (SELECT 0,d.work,d.c0,d.c3 WHERE NOT (parse_kind.kind IN (231,232)) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3 FROM (SELECT 1 AS reached WHERE parse_kind.kind IN (231,232)) allowed CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file,d.node,d.work,d.c0 AS c0,d.c3 AS c3
),
outcome1 AS MATERIALIZED (
SELECT d.*,p.truth AS parse_truth,p.work AS parse_work,p.parsed_file,p.parsed_node FROM outcome0 d CROSS JOIN relation_parse_budget(2,d.file,d.node,d.work) p
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1,r.c3 AS e2 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.parsed_file AS file,d.parsed_node AS node,d.parse_work AS work WHERE d.parse_truth=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v1,NULL AS v2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2,r.c3 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open,NULL AS c1,NULL AS c2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1,r.c3 AS e2 FROM outcome1 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,d.c2 AS c2,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.c2 AS c2,d.u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN 1 AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c1,d.node) ELSE d.c1 END AS c1,d.c2 AS c2,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,d.c2 AS c2,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u2) THEN CASE WHEN 1 AND (CASE WHEN d.c2 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c2,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c2,d.node) ELSE d.c2 END AS c2,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,34 AS pc,d.work,(1) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 8 THEN node_regex(0,n.file,n.id) WHEN 11 THEN n.kind IN (226) WHEN 12 THEN n.kind IN (216,217,219,221,222,223) WHEN 16 THEN node_regex(1,n.file,n.id) WHEN 19 THEN n.kind IN (218) WHEN 22 THEN n.kind IN (226) WHEN 23 THEN n.kind IN (88,93,94,96,97,98) WHEN 24 THEN n.kind IN (234) WHEN 26 THEN n.kind IN (231) WHEN 27 THEN n.kind IN (234) WHEN 29 THEN n.kind IN (232) WHEN 32 THEN n.kind IN (226) WHEN 33 THEN n.kind IN (88,96,97,98) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1 AND CASE WHEN w.pc IN (4,6,9,13,14,15,17,20,30,34) AND w.level<256 THEN relation_peak_note(w.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_1 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN n.next WHEN 7 THEN n.prev WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 7 THEN 1 WHEN 10 THEN 1 WHEN 18 THEN 1 WHEN 21 THEN 1 WHEN 25 THEN 1 WHEN 28 THEN 1 WHEN 31 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN NULL WHEN 7 THEN NULL WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.c2 AS c2,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v2 AS c2 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,d.u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1,s.c2 AS c2 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome8 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1,r.c3 AS e2 FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE d.truth=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,r.c1 work,r.c0 truth,r.c2 c1,r.c3 c2 FROM outcome0 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE owner AS MATERIALIZED (SELECT relation_state_begin() scope WHERE d.file IS NOT NULL),schedule AS (SELECT owner.scope scope,d.file file,d.node node,8 pc,(1) level,d.work work,NULL handle,relation_state_put_owned(owner.scope,relation_state_put_owned(owner.scope,0,1,d.c1),2,d.c2) env,0 truth FROM owner UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH s AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=2)), entered AS MATERIALIZED (SELECT s.*,f.entry,CASE WHEN s.level<256 THEN relation_peak_note(s.level+1) ELSE 1 END ready FROM s JOIN constant0_2 i ON i.pc=s.pc JOIN constant0_3 f ON f.id=i.a)
SELECT s.scope,s.file,s.node,CASE WHEN s.level>=256 OR s.work=0 THEN 0 ELSE s.entry END,CASE WHEN s.level<256 THEN s.level+1 ELSE s.level END,CASE WHEN s.level<256 AND s.work>0 THEN s.work-1 ELSE s.work END,COALESCE(frame.handle,s.handle),s.env,CASE WHEN s.level>=256 THEN -1 WHEN s.work=0 THEN -2 ELSE 0 END FROM entered s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.level<256 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (0) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (0) AND frame.v6 IS (0) AND frame.v7 IS (s.env) WHERE s.ready=1) WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=2) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH reached AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=3)),s AS MATERIALIZED (SELECT s.*,i.a,c.child FROM reached s JOIN constant0_2 i ON i.pc=s.pc LEFT JOIN constant0_4 c ON c.pc=s.pc AND c.ordinal=0) SELECT s.scope,s.file,s.node,COALESCE(s.child,0),s.level,s.work,COALESCE(frame.handle,s.handle),s.env,CASE WHEN s.child IS NULL THEN s.a ELSE 0 END FROM s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (CASE WHEN s.a THEN 2 ELSE 3 END) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (0) AND frame.v6 IS (0) AND frame.v7 IS (s.env)) WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=3) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH s AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=4)) SELECT s.scope,s.file,s.node,i.a,s.level,s.work,frame.handle,s.env,0 FROM s JOIN constant0_2 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN 1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (4) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (0) AND frame.v6 IS (0) AND frame.v7 IS (s.env)) WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=4) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH reached AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=5)),s AS MATERIALIZED (SELECT s.*,n."last" bound,CASE s.pc WHEN 4 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=s.file AND (candidate.id>s.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END child FROM reached s JOIN node n ON n.file=s.file AND n.id=s.node) SELECT s.scope,s.file,COALESCE(s.child,s.node),CASE WHEN s.child IS NULL THEN 0 ELSE i.a END,s.level,s.work,COALESCE(frame.handle,s.handle),s.env,0 FROM s JOIN constant0_2 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.child IS NOT NULL THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (1) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (s.bound) AND frame.v6 IS (0) AND frame.v7 IS (s.env) AND frame.v8 IS (s.child)) WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=5) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH s AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=6)),parsed AS MATERIALIZED (SELECT s.*,p.truth parsed_truth,p.work parsed_work,p.parsed_file,p.parsed_node FROM s CROSS JOIN relation_parse_budget(CASE s.pc WHEN 5 THEN 3 ELSE NULL END,s.file,s.node,s.work) p) SELECT s.scope,CASE WHEN s.parsed_truth=1 THEN s.parsed_file ELSE s.file END,CASE WHEN s.parsed_truth=1 THEN s.parsed_node ELSE s.node END,CASE WHEN s.parsed_truth=1 THEN i.a ELSE 0 END,s.level,s.parsed_work,COALESCE(frame.handle,s.handle),CASE WHEN s.parsed_truth=1 THEN 0 ELSE s.env END,CASE WHEN s.parsed_truth=1 THEN 0 ELSE s.parsed_truth END FROM parsed s JOIN constant0_2 i ON i.pc=s.pc LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.parsed_truth=1 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS (5) AND frame.v1 IS (s.file) AND frame.v2 IS (s.node) AND frame.v3 IS (s.level) AND frame.v4 IS (s.pc) AND frame.v5 IS (0) AND frame.v6 IS (0) AND frame.v7 IS (s.env)) WHERE machine.pc IN (SELECT pc FROM constant0_2 WHERE op=6) UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH reached AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc=0),popped AS MATERIALIZED (SELECT s.*,frame.parent,frame.c0,frame.c1,frame.c2,frame.c3,frame.c4,frame.c5,frame.c6,frame.c7,frame.c8 FROM reached s LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN s.handle IS NOT NULL THEN 2 END AND frame.h IS s.handle),
classified AS MATERIALIZED (SELECT p.*,CASE WHEN p.c0 IN (2,3) THEN (SELECT child FROM constant0_4 WHERE pc=p.c4 AND ordinal=p.c5+1) END child,CASE WHEN p.c0 IN (2,3) THEN COALESCE((SELECT strict FROM constant0_4 WHERE pc=p.c4 AND ordinal=p.c5),0) WHEN p.c0=1 THEN CASE p.c4 WHEN 4 THEN 1 ELSE 0 END ELSE 0 END strict,CASE WHEN p.c0=1 AND p.truth IN (0,2) THEN CASE p.c4 WHEN 4 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=p.c1 AND (candidate.id>p.c8 AND candidate.id<=p.c5) AND (1) ORDER BY candidate.id LIMIT 1) ELSE NULL END END candidate FROM popped p LEFT JOIN node n ON p.c0=1 AND n.file=p.c1 AND n.id=p.c8),
transition AS MATERIALIZED (SELECT p.scope AS scope,CASE WHEN p.handle IS NULL THEN p.file ELSE p.c1 END AS file,
CASE WHEN search_again.handle IS NOT NULL THEN p.candidate WHEN p.handle IS NULL THEN p.node ELSE p.c2 END AS node,
CASE WHEN p.handle IS NULL THEN -1 WHEN again.handle IS NOT NULL THEN p.child WHEN search_again.handle IS NOT NULL THEN (SELECT a FROM constant0_2 WHERE pc=p.c4) ELSE 0 END AS pc,
CASE WHEN p.handle IS NULL THEN p.level ELSE p.c3 END AS level,p.work,COALESCE(again.handle,search_again.handle,p.parent) AS handle,
CASE WHEN p.handle IS NULL THEN p.env WHEN again.handle IS NOT NULL THEN CASE WHEN p.c0=2 THEN p.env ELSE p.c7 END WHEN search_again.handle IS NOT NULL THEN p.c7 WHEN p.c0=4 OR p.truth<>1 OR (p.c0=2 AND p.c6=1) THEN p.c7 WHEN p.c0=5 THEN CASE p.c4 WHEN 5 THEN relation_state_put_owned(p.scope,relation_state_put(p.scope,p.c7,1,relation_capture_export(relation_state_get(p.c7,1),relation_parse_export(p.file,p.c1,relation_state_get(p.env,1)))),2,relation_capture_export(relation_state_get(p.c7,2),relation_parse_export(p.file,p.c1,relation_state_get(p.env,2)))) ELSE p.c7 END ELSE p.env END AS env,
CASE WHEN p.handle IS NULL THEN p.truth WHEN again.handle IS NOT NULL OR search_again.handle IS NOT NULL THEN 0 WHEN p.c0=4 THEN CASE p.truth WHEN 0 THEN 1 WHEN 1 THEN 0 ELSE p.truth END WHEN p.truth=0 AND p.c6=1 AND p.c0 IN (1,3) THEN 2 WHEN p.truth=1 AND p.c6=1 AND p.c0=2 THEN 2 ELSE p.truth END AS truth,p.env AS previous_env,p.c7 AS saved_env,p.handle AS previous_frame
FROM classified p LEFT JOIN relation_continuation again ON again.mode IS CASE WHEN p.c0 IN (2,3) AND p.truth>=0 AND NOT (p.c0=2 AND p.truth=0) AND NOT (p.c0=3 AND (p.truth=1 OR (p.truth=2 AND p.strict))) AND p.child IS NOT NULL THEN 1 END AND again.parent_input IS p.parent AND again.v0 IS (p.c0) AND again.v1 IS (p.c1) AND again.v2 IS (p.c2) AND again.v3 IS (p.c3) AND again.v4 IS (p.c4) AND again.v5 IS (p.c5+1) AND again.v6 IS (p.c6 OR p.truth=2) AND again.v7 IS (p.c7) LEFT JOIN relation_continuation search_again ON search_again.mode IS CASE WHEN p.c0=1 AND p.truth IN (0,2) AND NOT (p.truth=2 AND p.strict) AND p.candidate IS NOT NULL THEN 1 END AND search_again.parent_input IS p.parent AND search_again.v0 IS (1) AND search_again.v1 IS (p.c1) AND search_again.v2 IS (p.c2) AND search_again.v3 IS (p.c3) AND search_again.v4 IS (p.c4) AND search_again.v5 IS (p.c5) AND search_again.v6 IS (p.c6 OR p.truth=2) AND search_again.v7 IS (p.c7) AND search_again.v8 IS (p.candidate))
SELECT scope,file,node,pc,level,work,handle,env,truth FROM transition WHERE relation_state_drop(CASE WHEN previous_frame IS NOT NULL AND previous_env<>env AND previous_env<>COALESCE(saved_env,0) THEN previous_env END)=1) WHERE machine.pc=0 UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH state AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc=1) SELECT state.scope,state.file,state.node,0,state.level,r.c1,state.handle,CASE WHEN r.c0=1 THEN relation_state_put_owned(state.scope,relation_state_put(state.scope,state.env,1,r.c2),2,r.c3) ELSE state.env END,r.c0 FROM state CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,state.file,state.node,state.work,relation_state_get(state.env,1) AS c1,relation_state_get(state.env,2) AS c2 WHERE state.pc=1
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,d.c2 AS c2,0 AS u1,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.c2 AS c2,d.u1,d.u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN 1 AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c1,d.node) ELSE d.c1 END AS c1,d.c2 AS c2,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e2 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (d.u2)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,CASE WHEN origin.id<origin."last" THEN origin.id+1 END AS node,origin."last" AS bound,0 AS phase,0 AS own,0 AS stopped,0 AS low,0 AS uncertain,0 AS open,d.work,NULL AS v2 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node WHERE (CASE WHEN origin.id<origin."last" THEN origin.id+1 END) IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,w.bound,1, COALESCE(r.c0,0),w.stopped,w.low,w.uncertain,w.open,COALESCE(r.c1,w.work),r.c2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN outcome0 d ON d.k=w.k CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,w.file AS file,n.id AS node,w.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE w.stopped>=0
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c1 AS c1,d.c2 AS c2,0 AS u2 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u2) THEN CASE WHEN 1 AND (CASE WHEN d.c2 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c2,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c2,d.node) ELSE d.c2 END AS c2,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining FROM outcome3 d CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c1 AS c1,d.c2 AS c2 WHERE d.truth>0 AND NOT (0)
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,34 AS pc,d.work,((state.level)+0) AS level,NULL AS handle,0 AS truth FROM outcome0 d
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE w.pc WHEN 8 THEN node_regex(0,n.file,n.id) WHEN 11 THEN n.kind IN (226) WHEN 12 THEN n.kind IN (216,217,219,221,222,223) WHEN 16 THEN node_regex(1,n.file,n.id) WHEN 19 THEN n.kind IN (218) WHEN 22 THEN n.kind IN (226) WHEN 23 THEN n.kind IN (88,93,94,96,97,98) WHEN 24 THEN n.kind IN (234) WHEN 26 THEN n.kind IN (231) WHEN 27 THEN n.kind IN (234) WHEN 29 THEN n.kind IN (232) WHEN 32 THEN n.kind IN (226) WHEN 33 THEN n.kind IN (88,96,97,98) END) THEN i.a ELSE i.b END,w.work,w.level,w.handle,w.truth
FROM outcome1 w JOIN constant0_5 i ON i.pc=w.pc AND i.op=4 JOIN node n ON n.file=w.file AND n.id=w.node
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.level>=256 OR w.work=0 THEN 3 ELSE i.a END,CASE WHEN w.level<256 AND w.work>0 THEN w.work-1 ELSE w.work END,CASE WHEN s.handle IS NOT NULL THEN w.level+1 ELSE w.level END,COALESCE(s.handle,w.handle),CASE WHEN w.level>=256 THEN -1 WHEN w.work=0 THEN -2 ELSE w.truth END
FROM outcome1 w JOIN constant0_5 i ON i.pc=w.pc AND i.op=5 LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN w.level<256 AND w.work>0 THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 0 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level WHERE 1 AND CASE WHEN w.pc IN (4,6,9,13,14,15,17,20,30,34) AND w.level<256 THEN relation_peak_note(w.level+1) ELSE 1 END=1
UNION ALL
SELECT w.k,w.file,COALESCE(target.c0,w.node),CASE WHEN target.c0 IS NULL THEN i.c ELSE 2 END,w.work,w.level,COALESCE(s.handle,w.handle),w.truth
FROM outcome1 w JOIN constant0_5 i ON i.pc=w.pc AND i.op=6 JOIN node n ON n.file=w.file AND n.id=w.node CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE w.pc WHEN 5 THEN n.next WHEN 7 THEN n.prev WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>w.node AND candidate.id<=n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=w.node) AND (1) ORDER BY candidate.id LIMIT 1) END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS w.handle AND s.v0 IS 1 AND s.v1 IS w.node AND s.v2 IS i.b AND s.v3 IS i.c AND s.v4 IS w.level AND s.v5 IS i.a AND s.v6 IS target.c0 AND s.v7 IS n."last" AND s.v8 IS w.pc
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN (CASE p.c8 WHEN 5 THEN 1 WHEN 7 THEN 1 WHEN 10 THEN 1 WHEN 18 THEN 1 WHEN 21 THEN 1 WHEN 25 THEN 1 WHEN 28 THEN 1 WHEN 31 THEN 1 ELSE 1 END) THEN p.c5 ELSE 1 END,w.work,w.level,w.handle,w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=2 AND w.handle IS NOT NULL THEN 0 END AND p.h IS w.handle JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.pc=2
UNION ALL
SELECT w.k,w.file,w.node,NULL,w.work,w.level,NULL,CASE WHEN w.pc=0 THEN 1 ELSE 0 END FROM outcome1 w WHERE w.pc IN (0,1) AND w.handle IS NULL
UNION ALL
SELECT w.k,w.file,CASE WHEN s.handle IS NOT NULL THEN target.c0 ELSE p.c1 END,CASE WHEN s.handle IS NOT NULL THEN 2 WHEN w.pc=0 THEN p.c2 ELSE p.c3 END,w.work,p.c4,COALESCE(s.handle,p.parent),w.truth
FROM outcome1 w CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc IN (0,1) AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle LEFT JOIN node n ON n.file=w.file AND n.id=p.c6 CROSS JOIN relation_row target ON (target.c0) IS (SELECT CASE WHEN p.c0=1 AND w.pc=1 THEN CASE p.c8 WHEN 5 THEN NULL WHEN 7 THEN NULL WHEN 10 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 18 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 21 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) WHEN 25 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 28 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.id>CASE WHEN (0) THEN n."last" ELSE p.c6 END AND candidate.id<=p.c7) AND (1) ORDER BY candidate.id LIMIT 1) WHEN 31 THEN (SELECT candidate.id FROM node candidate WHERE candidate.file=w.file AND (candidate.parent=p.c1 AND candidate.id>n."last") AND (1) ORDER BY candidate.id LIMIT 1) END END) LEFT JOIN relation_continuation s ON s.mode IS (CASE WHEN p.c0=1 AND w.pc=1 AND target.c0 IS NOT NULL THEN 1 END) AND s.parent_input IS p.parent AND s.v0 IS 1 AND s.v1 IS p.c1 AND s.v2 IS p.c2 AND s.v3 IS p.c3 AND s.v4 IS p.c4 AND s.v5 IS p.c5 AND s.v6 IS target.c0 AND s.v7 IS p.c7 AND s.v8 IS p.c8 WHERE w.pc IN (0,1) AND w.handle IS NOT NULL
UNION ALL
SELECT w.k,w.file,w.node,CASE WHEN w.handle IS NULL THEN NULL ELSE 3 END,w.work,w.level,p.parent,w.truth FROM outcome1 w LEFT JOIN relation_continuation p ON p.mode IS CASE WHEN w.pc=3 AND w.handle IS NOT NULL THEN 2 END AND p.h IS w.handle WHERE w.pc=3
),
outcome2 AS MATERIALIZED (
SELECT k,work,truth FROM outcome1 WHERE pc IS NULL
) SELECT o.truth,o.work FROM outcome2 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,d.c2 AS c2,d.u2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (n.next)<=w.bound THEN (n.next) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (n.next)<=w.bound THEN (n.next) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v2 AS c2 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c2 AS c2 FROM outcome3 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c1 AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2,d.u1,(d.u2 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u2 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1,s.c2 AS c2 FROM outcome7 s
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome8 o)) WHERE machine.pc=1 UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8 FROM schedule machine CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8) IS (WITH state AS MATERIALIZED (SELECT machine.scope AS scope,machine.file AS file,machine.node AS node,machine.pc AS pc,machine.level AS level,machine.work AS work,machine.handle AS handle,machine.env AS env,machine.truth AS truth WHERE machine.pc=6) SELECT state.scope,state.file,state.node,0,state.level,r.c1,state.handle,CASE WHEN r.c0=1 THEN state.env ELSE state.env END,r.c0 FROM state CROSS JOIN relation_row r ON (r.c0,r.c1) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,state.file,state.node,state.work WHERE state.pc=6
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,0 AS truth,0 AS open FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth=0 THEN CASE WHEN ((n.kind IN (232)) OR (n.kind IN (231))) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 0 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth FROM outcome3 s
) SELECT o.truth,o.work FROM outcome4 o)) WHERE machine.pc=6),returned AS MATERIALIZED (SELECT scope,truth,work,relation_state_get(env,1) c1,relation_state_get(env,2) c2 FROM schedule WHERE pc=-1),closed AS MATERIALIZED (SELECT returned.*,relation_state_end(returned.scope) ready FROM returned) SELECT truth,work,c1,c2 FROM closed WHERE ready=1)
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,CASE WHEN d.tested=1 THEN d.e2 ELSE d.c2 END AS c2 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c1 AS c1,s.c2 AS c2 FROM outcome5 s
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome6 o) WHERE w.phase=0
UNION ALL
SELECT w.k,w.file,w.node,w.bound,2, w.own,0,w.low,w.uncertain,w.open,w.work,w.v1,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node  WHERE w.phase=1
UNION ALL
SELECT w.k,w.file,CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END,w.bound,0,0,0,(w.low+(w.own=1)),(w.uncertain+(w.own=2)),(w.open OR w.stopped=2),w.work,NULL,NULL FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND NOT (w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) AND (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NOT NULL
),
outcome2 AS MATERIALIZED (
SELECT w.k,w.work,CASE WHEN w.own<0 THEN w.own WHEN w.stopped<0 THEN w.stopped ELSE 0 END AS failure,(w.low+(w.own=1)) AS low,(w.uncertain+(w.own=2)) AS uncertain,(w.open OR w.stopped=2) AS open,w.v1,w.v2 FROM outcome1 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE w.phase=2 AND ((w.own<0 OR w.stopped<0 OR (w.own=1 OR w.own=2 OR w.open)) OR (CASE WHEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END)<=w.bound THEN (CASE WHEN w.stopped=0 THEN n.id+1 ELSE n."last"+1 END) END) IS NULL)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(t.work,d.work) AS work,CASE WHEN t.failure<0 THEN t.failure ELSE CASE WHEN COALESCE(t.low,0)>0 THEN 1 WHEN COALESCE(t.open,0) OR COALESCE(t.uncertain,0)>0 THEN 2 ELSE 0 END END AS truth,t.v1 AS c1,t.v2 AS c2 FROM outcome0 d LEFT JOIN outcome2 t ON t.k=d.k
) SELECT o.truth,o.work,o.c1 AS c1,o.c2 AS c2 FROM outcome3 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,COALESCE(d.remaining,d.parse_work) AS work,CASE WHEN d.parse_truth=1 THEN d.tested ELSE d.parse_truth END AS truth,CASE WHEN d.parse_truth=1 AND d.tested=1 THEN relation_capture_export(d.c0,relation_parse_export(d.parsed_file,d.file,d.e1)) ELSE d.c0 END AS c0,CASE WHEN d.parse_truth=1 AND d.tested=1 THEN relation_capture_export(d.c3,relation_parse_export(d.parsed_file,d.file,d.e2)) ELSE d.c3 END AS c3 FROM outcome2 d
) SELECT o.truth,o.work,o.c0,o.c3 FROM outcome3 o))
) SELECT o.truth,o.work,o.c0 AS c0,o.c3 AS c3 FROM outcome1 o)
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,CASE WHEN d.tested=1 THEN d.e3 ELSE d.c3 END AS c3,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0,(d.u3 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u3 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN (n.kind IN (232)) OR (n.kind IN (231)) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c3 AS c3,d.u0,d.u3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c3 AS c3 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c3 AS c3 FROM outcome6 o))
SELECT v.c0,v.c1,v.c2,v.c3,relation_cache_fill_delta(v.start) FROM fill_result v)
),
outcome5 AS MATERIALIZED (
SELECT d.*,CASE WHEN d.peak_token IS NOT NULL THEN relation_peak_close(d.peak_token) ELSE d.peak END AS measured_peak FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.remaining AS work,COALESCE(m.truth,d.tested) AS truth,d.e0 AS c0,d.e3 AS c3 FROM outcome5 d LEFT JOIN relation_memo m ON m.mode IS CASE WHEN d.hit IS NULL AND d.tested>=0 THEN 1 END AND m.clause IS 0 AND m.utility IS 0 AND m.file IS d.file AND m.node IS d.node AND m.k0 IS relation_capture_key(d.c0) AND m.k1 IS relation_capture_key(d.c3) AND m.vtruth IS d.tested AND m.vcost IS MAX(0,d.work-d.remaining-d.fill_cost) AND m.vpeak IS d.measured_peak AND m.v0 IS CASE WHEN d.tested=1 THEN d.e0 END AND m.v1 IS CASE WHEN d.tested=1 THEN d.e3 END WHERE d.peak_ready=1 AND COALESCE(d.measured_peak,0)>=0
) SELECT o.truth,o.work,o.c0 AS c0,o.c3 AS c3 FROM outcome6 o)
) SELECT o.truth,o.work,o.c0 AS c0,o.c3 AS c3 FROM outcome1 o)
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<>0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.tested=1 THEN 1 WHEN d.tested=2 AND 1 THEN 2 ELSE 0 END AS truth,(d.open OR COALESCE(d.tested=2,0)) AS open,CASE WHEN d.tested=1 THEN d.e0 ELSE d.c0 END AS c0,CASE WHEN d.tested=1 THEN d.e3 ELSE d.c3 END AS c3 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT s.k,s.work,CASE WHEN s.truth=0 AND s.open THEN 2 ELSE s.truth END AS truth,s.c0 AS c0,s.c3 AS c3 FROM outcome5 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c3 AS c3 FROM outcome6 o) WHERE w.truth>=0
),
constant0_0 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,13,0,1),(5,6,4,0,1),(6,5,13,0,1),(7,6,6,0,5),(8,4,7,1,0),(9,5,13,0,1),(10,6,9,0,1),(11,4,10,1,0),(12,4,0,11,0),(13,5,15,0,12),(14,5,33,1,0),(15,5,29,14,1),(16,4,1,0,0),(17,5,29,1,16),(18,6,17,1,0),(19,4,18,1,0),(20,5,29,0,1),(21,6,20,0,19),(22,4,21,19,0),(23,4,0,22,0),(24,4,0,1,0),(25,6,24,23,0),(26,4,25,23,0),(27,4,0,1,0),(28,6,27,26,0),(29,4,28,26,0),(30,5,33,0,1),(31,6,30,0,1),(32,4,31,1,0),(33,4,0,32,0),(34,5,8,0,1))),
constant0_1 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,13,0,1),(5,6,4,0,1),(6,5,13,0,1),(7,6,6,0,5),(8,4,7,1,0),(9,5,13,0,1),(10,6,9,0,1),(11,4,10,1,0),(12,4,0,11,0),(13,5,15,0,12),(14,5,33,1,0),(15,5,29,14,1),(16,4,1,0,0),(17,5,29,1,16),(18,6,17,1,0),(19,4,18,1,0),(20,5,29,0,1),(21,6,20,0,19),(22,4,21,19,0),(23,4,0,22,0),(24,4,0,1,0),(25,6,24,23,0),(26,4,25,23,0),(27,4,0,1,0),(28,6,27,26,0),(29,4,28,26,0),(30,5,33,0,1),(31,6,30,0,1),(32,4,31,1,0),(33,4,0,32,0),(34,5,8,0,1))),
constant0_2 AS MATERIALIZED (SELECT column1 pc,column2 op,column3 a FROM (VALUES (0,0,0),(1,1,0),(2,2,0),(3,3,0),(4,5,3),(5,6,4),(6,1,1),(7,3,1),(8,2,0))),
constant0_3 AS MATERIALIZED (SELECT column1 id,column2 entry FROM (VALUES (0,7))),
constant0_4 AS MATERIALIZED (SELECT column1 pc,column2 ordinal,column3 child,column4 strict FROM (VALUES (3,0,1,1),(3,1,2,1),(7,0,5,1),(7,1,6,0))),
constant0_5 AS MATERIALIZED (SELECT column1 AS pc,column2 AS op,column3 AS a,column4 AS b,column5 AS c FROM (VALUES (0,0,0,0,0),(1,1,0,0,0),(2,2,0,0,0),(3,3,0,0,0),(4,5,13,0,1),(5,6,4,0,1),(6,5,13,0,1),(7,6,6,0,5),(8,4,7,1,0),(9,5,13,0,1),(10,6,9,0,1),(11,4,10,1,0),(12,4,0,11,0),(13,5,15,0,12),(14,5,33,1,0),(15,5,29,14,1),(16,4,1,0,0),(17,5,29,1,16),(18,6,17,1,0),(19,4,18,1,0),(20,5,29,0,1),(21,6,20,0,19),(22,4,21,19,0),(23,4,0,22,0),(24,4,0,1,0),(25,6,24,23,0),(26,4,25,23,0),(27,4,0,1,0),(28,6,27,26,0),(29,4,28,26,0),(30,5,33,0,1),(31,6,30,0,1),(32,4,31,1,0),(33,4,0,32,0),(34,5,8,0,1))),
outcome9 AS MATERIALIZED (
SELECT 0 AS clause,o.file,o.node,o.truth,o.work,o.c0 AS v0,o.c3 AS v1 FROM outcome2 o WHERE o.truth=1 OR o.truth<0
),
outcome10 AS MATERIALIZED (
SELECT clause,file,node,truth,work FROM outcome9 WHERE truth<0
)
-- final matches
SELECT m.clause,m.file,m.node,CASE m.clause WHEN 0 THEN json_array(CASE WHEN typeof(m.v0)='blob' THEN json(relation_span_json(m.v0,m.file)) ELSE m.v0 END,CASE WHEN typeof(m.v1)='blob' THEN json(relation_span_json(m.v1,m.file)) ELSE m.v1 END) END AS payload,0 AS failure,m.work FROM outcome9 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome10 f WHERE f.clause=m.clause AND f.file=m.file)
UNION ALL
SELECT clause,file,NULL,'[]',truth,work FROM outcome10
ORDER BY 1,2,3