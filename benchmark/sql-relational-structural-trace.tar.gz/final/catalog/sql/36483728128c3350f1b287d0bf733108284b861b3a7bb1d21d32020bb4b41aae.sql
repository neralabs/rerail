WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM node AS a0n0 CROSS JOIN node AS a0n1 ON a0n1.file=a0n0.file AND a0n1.id=a0n0.parent CROSS JOIN node AS a0n2 ON a0n2.file=a0n1.file AND a0n2.id=a0n1.parent CROSS JOIN node AS a0n3 ON a0n3.file=a0n2.file AND a0n3.id=a0n2.parent CROSS JOIN node AS a0n4 ON a0n4.file=a0n3.file AND a0n4.parent=a0n3.id CROSS JOIN node AS a0n5 ON a0n5.file=a0n4.file AND a0n5.parent=a0n4.id WHERE a0n0.kind IN (125) AND NOT (EXISTS (SELECT 1 FROM r2 k WHERE k.file=a0n0.file AND k.node=a0n0.id)) AND a0n1.kind IN (161) AND a0n2.kind IN (141) AND a0n3.kind IN (139) AND a0n4.kind IN (161) AND a0n5.kind IN (125)
UNION
SELECT a2n0.file,a2n0.id FROM node AS a2n0 CROSS JOIN node AS a2n1 ON a2n1.file=a2n0.file AND a2n1.id=a2n0.parent CROSS JOIN node AS a2n2 ON a2n2.file=a2n1.file AND a2n2.id=a2n1.parent CROSS JOIN node AS a2n3 ON a2n3.file=a2n2.file AND a2n3.id=a2n2.parent CROSS JOIN node AS a2n4 ON a2n4.file=a2n3.file AND a2n4.parent=a2n3.id CROSS JOIN node AS a2n5 ON a2n5.file=a2n4.file AND a2n5.parent=a2n4.id CROSS JOIN node AS a2n6 ON a2n6.file=a2n5.file AND a2n6.parent=a2n5.id WHERE a2n0.kind IN (125) AND NOT (EXISTS (SELECT 1 FROM r2 k WHERE k.file=a2n0.file AND k.node=a2n0.id)) AND a2n1.kind IN (161) AND a2n2.kind IN (141) AND a2n3.kind IN (139) AND a2n4.kind IN (140) AND a2n5.kind IN (161) AND a2n6.kind IN (125)
),
-- linear walk target
r1(file,node) AS MATERIALIZED (
SELECT a4n0.file,a4n0.id FROM node AS a4n0 WHERE a4n0.kind IN (125)
),
-- linear walk answers
r2(file,node) AS MATERIALIZED (
SELECT a5n0.file,a5n0.id FROM r1 AS seed5 CROSS JOIN node AS a5n1 ON a5n1.file=seed5.file AND a5n1.id=seed5.node CROSS JOIN node AS a5n0 ON a5n0.file=a5n1.file AND a5n0.id=a5n1.next
UNION
SELECT a6n0.file,a6n0.id FROM r2 AS seed6 CROSS JOIN node AS a6n1 ON a6n1.file=seed6.file AND a6n1.id=seed6.node CROSS JOIN node AS a6n0 ON a6n0.file=a6n1.file AND a6n0.id=a6n1.next
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node