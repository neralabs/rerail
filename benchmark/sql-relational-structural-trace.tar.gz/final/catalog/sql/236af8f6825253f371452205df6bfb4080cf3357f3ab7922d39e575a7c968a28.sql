WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT DISTINCT a0n0.file,a0n0.id FROM node AS a0n0 CROSS JOIN node AS a0n1 ON a0n1.file=a0n0.file AND a0n1.parent=a0n0.id WHERE a0n0.kind IN (232) AND NOT ((EXISTS (SELECT 1 FROM r1 k WHERE k.file=a0n0.file AND k.node=a0n0.id) OR EXISTS (SELECT 1 FROM (SELECT 1) AS unit2 CROSS JOIN node AS a2n1 ON a2n1.file=a0n0.file AND a2n1.id=a0n0.parent CROSS JOIN node AS a2n2 ON a2n2.file=a2n1.file AND a2n2.parent=a2n1.id WHERE EXISTS (SELECT 1 FROM r1 k WHERE k.file=a2n2.file AND k.node=a2n2.id) AND a2n1.kind IN (231)))) AND a0n1.kind IN (104) AND node_regex(0,a0n1.file,a0n1.id)
),
-- utility[0]
r1(file,node) AS MATERIALIZED (
SELECT DISTINCT a3n0.file,a3n0.id FROM node AS a3n0 CROSS JOIN node AS a3n1 ON a3n1.file=a3n0.file AND a3n1.parent=a3n0.id WHERE a3n0.kind IN (232) AND a3n1.kind IN (234)
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node