WITH RECURSIVE
-- clause
r0(file,node) AS (
SELECT a0n0.file,a0n0.id FROM r10 AS seed0 CROSS JOIN node AS a0n0 ON a0n0.file=seed0.file AND a0n0.id=seed0.node WHERE a0n0.kind IN (125) AND node_regex(0,a0n0.file,a0n0.id)
),
-- utility[0]
r1(file,node) AS MATERIALIZED (
SELECT a1n0.file,a1n0.id FROM node AS a1n0 WHERE a1n0.kind IN (145) AND NOT (EXISTS (SELECT 1 FROM r4 k WHERE k.file=a1n0.file AND k.node=a1n0.id)) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit3 CROSS JOIN node AS a3n1 ON a3n1.file=a1n0.file AND a3n1.parent=a1n0.id CROSS JOIN node AS a3n2 ON a3n2.file=a3n1.file AND a3n2.parent=a3n1.id WHERE a3n1.kind IN (161) AND NOT (EXISTS (SELECT 1 FROM (SELECT 1) AS unit4 CROSS JOIN node AS a4n1 ON a4n1.file=a3n1.file AND a4n1.parent=a3n1.id WHERE NOT (a4n1.kind IN (99,125)))) AND a3n2.kind IN (125)))
),
-- descendant predicate
r2(file,node) AS MATERIALIZED (
SELECT a6n0.file,a6n0.id FROM node AS a6n0 WHERE a6n0.kind IN (203)
),
-- traversal stop
r3(file,node) AS MATERIALIZED (
SELECT a7n0.file,a7n0.id FROM node AS a7n0 WHERE a7n0.kind IN (145,154)
),
-- inverse descendant closure
r4(file,node) AS MATERIALIZED (SELECT n.file,n.parent FROM r2 seed CROSS JOIN node n ON n.file=seed.file AND n.id=seed.node WHERE n.parent IS NOT NULL UNION SELECT n.file,n.parent FROM r4 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.parent IS NOT NULL AND NOT EXISTS (SELECT 1 FROM r3 s WHERE s.file=w.file AND s.node=w.node)),
-- utility[1]
r5(file,node) AS (
SELECT file,node FROM r8
),
-- utility[4]
r6(file,node) AS MATERIALIZED (
SELECT DISTINCT a8n0.file,a8n0.id FROM node AS a8n0 CROSS JOIN node AS a8n1 ON a8n1.file=a8n0.file AND a8n1.parent=a8n0.id WHERE a8n0.kind IN (125) AND a8n1."end">a8n1.start AND NOT ((node_regex(0,a8n1.file,a8n1.id) OR a8n1.kind IN (99) OR EXISTS (SELECT 1 FROM r7 k WHERE k.file=a8n1.file AND k.node=a8n1.id)))
),
-- utility[2]
r7(file,node) AS MATERIALIZED (
SELECT a12n0.file,a12n0.id FROM node AS a12n0 WHERE a12n0.kind IN (98)
UNION
SELECT a13n0.file,a13n0.id FROM r7 AS seed13 CROSS JOIN node AS a13n1 ON a13n1.file=seed13.file AND a13n1.id=seed13.node CROSS JOIN node AS a13n0 ON a13n0.file=a13n1.file AND a13n0.id=a13n1.parent WHERE a13n0.kind IN (226)
),
-- inverse descendant closure
r8(file,node) AS MATERIALIZED (SELECT n.file,n.parent FROM r6 seed CROSS JOIN node n ON n.file=seed.file AND n.id=seed.node WHERE n.parent IS NOT NULL UNION SELECT n.file,n.parent FROM r8 w CROSS JOIN node n ON n.file=w.file AND n.id=w.node WHERE n.parent IS NOT NULL AND NOT EXISTS (SELECT 1 FROM r3 s WHERE s.file=w.file AND s.node=w.node)),
-- linear walk target
r9(file,node) AS MATERIALIZED (
SELECT a14n0.file,a14n0.id FROM r1 AS seed14 CROSS JOIN node AS a14n0 ON a14n0.file=seed14.file AND a14n0.id=seed14.node WHERE EXISTS (SELECT 1 FROM r5 k WHERE k.file=a14n0.file AND k.node=a14n0.id) AND a14n0.kind IN (145)
),
-- linear walk answers
r10(file,node) AS MATERIALIZED (
SELECT a15n0.file,a15n0.id FROM r9 AS seed15 CROSS JOIN node AS a15n1 ON a15n1.file=seed15.file AND a15n1.id=seed15.node CROSS JOIN node AS a15n0 ON a15n0.file=a15n1.file AND a15n0.parent=a15n1.id
UNION
SELECT a16n0.file,a16n0.id FROM r10 AS seed16 CROSS JOIN node AS a16n1 ON a16n1.file=seed16.file AND a16n1.id=seed16.node CROSS JOIN node AS a16n0 ON a16n0.file=a16n1.file AND a16n0.parent=a16n1.id WHERE NOT (EXISTS (SELECT 1 FROM r3 k WHERE k.file=a16n1.file AND k.node=a16n1.id))
)
SELECT 0,file,node,json_array() FROM r0 ORDER BY file,node