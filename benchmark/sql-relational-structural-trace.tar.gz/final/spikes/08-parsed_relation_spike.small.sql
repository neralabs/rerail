WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT relation_memo_reset(0) ready
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () k,n.file,n.id node,10000 work,ROW_NUMBER() OVER (PARTITION BY n.file ORDER BY n.id) ordinal,n.kind IN (231,232) host,(0) prefix_may_hold FROM node n CROSS JOIN outcome0 i ON i.ready=1 WHERE 1 AND (n.kind IN (231,232))
),
outcome2 AS MATERIALIZED (
WITH events AS (SELECT k,file,node,work,ordinal native_ordinal,1 real,host FROM outcome1 WHERE host OR prefix_may_hold UNION ALL SELECT NULL,file,NULL,10000,MAX(ordinal)+1,0,0 FROM outcome1 GROUP BY file) SELECT k,file,node,work,ROW_NUMBER() OVER (PARTITION BY file ORDER BY native_ordinal) ordinal,host,(native_ordinal-COALESCE(LAG(native_ordinal) OVER (PARTITION BY file ORDER BY native_ordinal),0)-1)*1 gap,real FROM events
),
outcome3 AS (
SELECT NULL k,file,NULL node,0 ordinal,0 truth,10000 work,NULL AS c2,NULL AS c3,0 root_producers,0 parse_requests,0 local_producers FROM outcome2 GROUP BY file UNION ALL SELECT d.k,d.file,d.node,d.ordinal,r.c0,r.c1,r.c2,r.c3,w.root_producers+d.real,w.parse_requests+COALESCE(r.c4,0),w.local_producers+COALESCE(r.c5,0) FROM outcome3 w CROSS JOIN outcome2 d ON d.file=w.file AND d.ordinal=w.ordinal+1 CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5) IS (SELECT CASE WHEN w.work<d.gap THEN -2 WHEN NOT d.real THEN 0 WHEN f.c0 IS NOT 0 THEN f.c0 ELSE a.c0 END,CASE WHEN w.work<d.gap THEN 0 WHEN NOT d.real THEN w.work-d.gap WHEN f.c0 IS NOT 0 THEN f.c1 ELSE a.c1 END,CASE WHEN w.work>=d.gap AND d.real THEN CASE WHEN f.c0 IS NOT 0 THEN NULL ELSE a.c2 END END,CASE WHEN w.work>=d.gap AND d.real THEN CASE WHEN f.c0 IS NOT 0 THEN NULL ELSE a.c3 END END,COALESCE(a.c4,0),COALESCE(a.c5,0) FROM (SELECT 1) seed CROSS JOIN relation_row f ON (f.c0,f.c1) IS (SELECT 0,w.work-d.gap) LEFT JOIN relation_row a ON (a.c0,a.c1,a.c2,a.c3,a.c4,a.c5) IS (SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5 FROM (SELECT d.file,d.node,f.c1 work,d.host WHERE f.c0=0 AND d.real AND w.work>=d.gap) d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5) IS (SELECT CASE WHEN d.work=0 THEN -2 ELSE 0 END,MAX(0,d.work-1),NULL,NULL,0,0 FROM (SELECT 1) unused WHERE NOT d.host UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5 FROM (SELECT 1 reached WHERE d.host) allowed CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5) IS (WITH RECURSIVE initial AS MATERIALIZED (SELECT f.handle FROM relation_continuation f WHERE f.mode IS CASE WHEN d.host THEN 1 END AND f.v0 IS d.file AND f.v1 IS d.node AND f.v2 IS 0 AND f.v3 IS 0 AND f.v4 IS 0),scan(file,node,cursor,bound,level,handle,phase,truth,work,c0,c1,requests,visits) AS (SELECT d.file,d.node,0,0,0,handle,0,0,d.work,NULL AS c0,NULL AS c1,0,0 FROM initial UNION ALL SELECT r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12 FROM scan CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2,r.c3,r.c4,r.c5,r.c6,r.c7,r.c8,r.c9,r.c10,r.c11,r.c12) IS (SELECT * FROM (WITH s AS MATERIALIZED (SELECT scan.file,scan.node,scan.cursor,scan.bound,scan.level,scan.handle,scan.phase,scan.truth,scan.work,scan.c0,scan.c1,scan.requests,scan.visits WHERE scan.phase=0),e AS MATERIALIZED (SELECT s.*,CASE WHEN s.level<256 AND s.work>0 THEN s.work-1 END allowance,CASE WHEN s.level<256 AND s.work>0 THEN relation_peak_note(s.level+1) END noted FROM s),p AS MATERIALIZED (SELECT e.*,a.truth parsed_truth,a.work parsed_work,a.parsed_file,a.parsed_node FROM e LEFT JOIN relation_parse_budget(CASE WHEN e.level=0 THEN 0 ELSE 2 END,e.file,e.node,e.allowance) a ON 1) SELECT COALESCE(p.parsed_file,p.file),p.node,CASE WHEN p.parsed_truth=1 THEN COALESCE((SELECT candidate.id FROM node candidate WHERE candidate.file=p.parsed_file AND candidate.id>p.parsed_node AND candidate.id<=n."last" AND (1) ORDER BY candidate.id LIMIT 1),n."last"+1) ELSE p.cursor END,COALESCE(n."last",p.bound),p.level+CASE WHEN p.parsed_truth=1 THEN 1 ELSE 0 END,p.handle,CASE WHEN p.parsed_truth=1 THEN 1 ELSE 2 END,CASE WHEN p.level>=256 THEN -1 WHEN p.work=0 THEN -2 ELSE p.parsed_truth END,COALESCE(p.parsed_work,p.work),NULL AS c0,NULL AS c1,p.requests+(p.allowance IS NOT NULL),p.visits FROM p LEFT JOIN node n ON n.file=p.parsed_file AND n.id=p.parsed_node WHERE p.noted IS NOT NULL OR p.allowance IS NULL) UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT scan.file,scan.node,scan.cursor,scan.bound,scan.level,scan.handle,scan.phase,scan.truth,scan.work,scan.c0,scan.c1,scan.requests,scan.visits WHERE scan.phase=1) SELECT s.file,CASE WHEN s.cursor<=s.bound THEN s.cursor ELSE s.node END,s.cursor,s.bound,s.level,COALESCE(frame.handle,s.handle),CASE WHEN s.cursor>s.bound OR b.c0 IS NOT 0 THEN 2 ELSE 0 END,CASE WHEN s.cursor>s.bound THEN 0 ELSE b.c0 END,COALESCE(b.c1,s.work),b.c2 AS c0,b.c3 AS c1,s.requests,s.visits+(s.cursor<=s.bound) FROM s CROSS JOIN relation_row b ON (b.c0,b.c1,b.c2,b.c3) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,s.file AS file,s.cursor AS node,s.work AS work WHERE s.cursor<=s.bound
),
outcome1 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,NULL AS c0,NULL AS c1,0 AS u0,0 AS u1 FROM outcome0 d
),
outcome2 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN n.kind IN (196) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome1 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome3 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.u0,d.u1 FROM outcome2 d
),
outcome4 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u0) THEN CASE WHEN 1 AND (CASE WHEN d.c0 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c0,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome3 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome5 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c0,d.node) ELSE d.c0 END AS c0,d.c1 AS c1,(d.u0 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u0,d.u1 FROM outcome4 d
),
outcome6 AS MATERIALIZED (
SELECT d.*,r.c0 AS tested,r.c1 AS remaining,r.c2 AS e1 FROM outcome5 d CROSS JOIN relation_row r ON (r.c0,r.c1,r.c2) IS (WITH RECURSIVE outcome0 AS MATERIALIZED (
SELECT 1 AS k,d.file AS file,d.node AS node,d.work AS work,d.c0 AS c0,d.c1 AS c1 WHERE d.truth>0 AND NOT (d.u1)
),
outcome1 AS MATERIALIZED (
SELECT ROW_NUMBER() OVER () AS k,d.k AS parent,n.file,n.id AS node,d.work,n.id AS rank,d.c0 AS c0,d.c1 AS c1 FROM outcome0 d CROSS JOIN node origin ON origin.file=d.file AND origin.id=d.node CROSS JOIN node n ON n.file=origin.file AND n.parent=origin.id WHERE 1
),
outcome2 AS MATERIALIZED (
SELECT d.k,d.file,d.node,d.work,1 AS truth,d.c0 AS c0,d.c1 AS c1,0 AS u1 FROM outcome1 d
),
outcome3 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (0) THEN CASE WHEN node_regex(1,n.file,n.id) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome2 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome4 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,d.c1 AS c1,d.u1 FROM outcome3 d
),
outcome5 AS MATERIALIZED (
SELECT d.*,d.work AS remaining,CASE WHEN d.truth>0 AND NOT (d.u1) THEN CASE WHEN 1 AND (CASE WHEN d.c1 IS NULL THEN 1 ELSE relation_capture_equal(d.file,d.c1,d.node) END) THEN 1 ELSE 0 END ELSE NULL END AS tested FROM outcome4 d CROSS JOIN node n ON n.file=d.file AND n.id=d.node
),
outcome6 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,CASE WHEN d.tested=1 THEN relation_capture_bind(d.file,d.c1,d.node) ELSE d.c1 END AS c1,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome5 d
),
outcome7 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c1 AS c1 FROM outcome6 s
),
outcome8 AS (
SELECT d.parent,o.truth,o.c1 AS c1,ROW_NUMBER() OVER (PARTITION BY d.parent ORDER BY d.rank) AS choice FROM outcome1 d JOIN outcome7 o ON o.k=d.k WHERE o.truth<>0
),
outcome9 AS MATERIALIZED (
SELECT * FROM outcome8 WHERE choice=1
),
outcome10 AS MATERIALIZED (
SELECT d.k,d.work,COALESCE(o.truth,0) AS truth,CASE WHEN o.truth=1 THEN o.c1 ELSE d.c1 END AS c1 FROM outcome0 d LEFT JOIN outcome9 o ON o.parent=d.k
) SELECT o.truth,o.work,o.c1 AS c1 FROM outcome10 o)
),
outcome7 AS MATERIALIZED (
SELECT d.k,d.file,d.node,COALESCE(d.remaining,d.work) AS work,CASE WHEN d.truth<0 THEN d.truth WHEN d.tested<0 THEN d.tested WHEN d.truth=0 OR d.tested=0 THEN 0 WHEN d.truth=2 OR d.tested=2 THEN 2 ELSE 1 END AS truth,d.c0 AS c0,CASE WHEN d.tested=1 THEN d.e1 ELSE d.c1 END AS c1,d.u0,(d.u1 OR COALESCE(d.tested=2,0) OR (d.tested IS NULL AND d.truth<>0)) AS u1 FROM outcome6 d
),
outcome8 AS MATERIALIZED (
SELECT s.k,s.work,s.truth,s.c0 AS c0,s.c1 AS c1 FROM outcome7 s
) SELECT o.truth,o.work,o.c0 AS c0,o.c1 AS c1 FROM outcome8 o) LEFT JOIN relation_continuation frame ON frame.mode IS CASE WHEN scan.phase=1 AND s.cursor<=s.bound AND b.c0=0 THEN 1 END AND frame.parent_input IS s.handle AND frame.v0 IS s.file AND frame.v1 IS s.cursor AND frame.v2 IS COALESCE((SELECT candidate.id FROM node candidate WHERE candidate.file=s.file AND candidate.id>s.cursor AND candidate.id<=s.bound AND (1) ORDER BY candidate.id LIMIT 1),s.bound+1) AND frame.v3 IS s.bound AND frame.v4 IS s.level) UNION ALL SELECT * FROM (WITH s AS MATERIALIZED (SELECT scan.file,scan.node,scan.cursor,scan.bound,scan.level,scan.handle,scan.phase,scan.truth,scan.work,scan.c0,scan.c1,scan.requests,scan.visits WHERE scan.phase=2) SELECT p.c0,p.c1,p.c2,p.c3,p.c4,p.parent,CASE WHEN p.parent IS NULL THEN 3 WHEN s.truth=0 THEN 1 ELSE 2 END,s.truth,s.work,CASE WHEN s.truth=1 THEN relation_parse_export(s.file,p.c0,s.c0) END AS c0,CASE WHEN s.truth=1 THEN relation_parse_export(s.file,p.c0,s.c1) END AS c1,s.requests,s.visits FROM s CROSS JOIN relation_continuation p ON p.mode IS CASE WHEN scan.phase=2 THEN 2 END AND p.h IS s.handle)) WHERE scan.phase<>3) SELECT s.truth,s.work,s.c0,s.c1,s.requests,s.visits FROM scan s WHERE s.phase=3)))) WHERE w.truth>=0
),
outcome4 AS MATERIALIZED (
SELECT w.file,w.node,w.truth,w.work,w.c2 AS c2,w.c3 AS c3 FROM outcome3 w WHERE w.truth=1 OR w.truth<0
),
outcome5 AS MATERIALIZED (
SELECT * FROM outcome4 WHERE truth<0
) SELECT 0,m.file,m.node,json_array(CASE WHEN typeof(m.c2)='blob' THEN json(relation_span_json(m.c2,m.file)) ELSE m.c2 END,CASE WHEN typeof(m.c3)='blob' THEN json(relation_span_json(m.c3,m.file)) ELSE m.c3 END),0,m.work FROM outcome4 m WHERE m.truth=1 AND NOT EXISTS (SELECT 1 FROM outcome5 f WHERE f.file=m.file) UNION ALL SELECT 0,file,NULL,'[]',truth,work FROM outcome5 ORDER BY 1,2,3