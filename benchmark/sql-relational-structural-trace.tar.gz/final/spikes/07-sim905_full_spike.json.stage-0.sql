CREATE TEMP TABLE spike_sim905_meta AS WITH RECURSIVE
calls AS MATERIALIZED (SELECT n.file,n.id FROM node n WHERE n.kind=207 AND 1 AND (n.kind IN (207))),
attributes AS MATERIALIZED (SELECT c.file,c.id call,a.id FROM calls c JOIN node a ON a.file=c.file AND a.parent=c.id AND a.kind=204),
attribute_children AS MATERIALIZED (SELECT a.call,n.file,n.id,n.kind,n.prev,n."last",a.id attribute FROM attributes a JOIN node n ON n.file=a.file AND n.parent=a.id),
receiver_roots AS MATERIALIZED (
 SELECT a.file,a.call,a.attribute,a.id node FROM attribute_children a
 WHERE EXISTS(SELECT 1 FROM node dot WHERE dot.file=a.file AND dot.parent=a.attribute AND dot.id>a."last" AND dot.kind<>99 AND node_regex(1,dot.file,dot.id)
 AND NOT EXISTS(SELECT 1 FROM node between_node WHERE between_node.file=a.file AND between_node.parent=a.attribute AND between_node.id>a."last" AND between_node.id<dot.id AND between_node.kind<>99))
),
method_calls AS MATERIALIZED (SELECT DISTINCT a.file,a.call,a.attribute FROM attribute_children a JOIN node dot ON dot.file=a.file AND dot.id=a.prev WHERE a.kind=1 AND node_regex(2,a.file,a.id) AND node_regex(1,dot.file,dot.id)),
arguments AS MATERIALIZED (SELECT c.file,c.id call,a.id FROM calls c JOIN node a ON a.file=c.file AND a.parent=c.id AND a.kind=158),
argument_nodes AS MATERIALIZED (SELECT a.call,a.id arguments,n.file,n.id,n.kind,n.prev FROM arguments a JOIN node n ON n.file=a.file AND n.parent=a.id),
noncomments AS MATERIALIZED (SELECT a.*,node_regex(3,a.file,a.id) punct,node_regex(4,a.file,a.id) opening,node_regex(5,a.file,a.id) comma FROM argument_nodes a WHERE a.kind<>99),
positions AS MATERIALIZED (SELECT a.*,
 LAG(a.opening,1,0) OVER w first_position,
 LAG(a.comma,1,0) OVER w previous_comma,
 LAG(a.punct OR a.kind IN (215,148,149),2,1) OVER w previous_previous_excluded,
 LAG(a.opening,3,0) OVER w third_previous_open
 FROM noncomments a WINDOW w AS(PARTITION BY a.file,a.arguments ORDER BY a.id)),
keyword_names AS MATERIALIZED (SELECT a.file,a.arguments,a.id keyword,CASE WHEN node_regex(6,n.file,n.id) THEN 1 WHEN node_regex(7,n.file,n.id) THEN 2 END role
 FROM argument_nodes a JOIN node n ON n.file=a.file AND n.parent=a.id AND n.kind=1 JOIN node eq ON eq.file=n.file AND eq.id=n.next
 WHERE a.kind=215 AND node_regex(8,eq.file,eq.id) AND (node_regex(6,n.file,n.id) OR node_regex(7,n.file,n.id))),
keyword_values AS MATERIALIZED (SELECT k.file,k.arguments,k.role,v.id node FROM keyword_names k JOIN node v ON v.file=k.file AND v.parent=k.keyword JOIN node eq ON eq.file=v.file AND eq.id=v.prev WHERE node_regex(8,eq.file,eq.id)),
selected AS MATERIALIZED (
 SELECT file,arguments,role,node FROM keyword_values
 UNION ALL SELECT p.file,p.arguments,CASE WHEN p.first_position THEN 1 ELSE 2 END,p.id FROM positions p
 WHERE NOT p.punct AND p.kind NOT IN (215,148,149)
 AND (p.first_position OR (p.previous_comma AND NOT p.previous_previous_excluded AND p.third_previous_open))
 AND NOT EXISTS(SELECT 1 FROM keyword_names k WHERE k.file=p.file AND k.arguments=p.arguments AND k.role=CASE WHEN p.first_position THEN 1 ELSE 2 END)
),keyword_groups AS MATERIALIZED(SELECT a.file,a.arguments,a.id keyword,EXISTS(SELECT 1 FROM keyword_names k WHERE k.file=a.file AND k.keyword=a.id AND k.role=1) sep_name,EXISTS(SELECT 1 FROM keyword_names k WHERE k.file=a.file AND k.keyword=a.id AND k.role=2) max_name FROM argument_nodes a WHERE a.kind=215),
helper_candidates AS MATERIALIZED(SELECT k.file,k.arguments,1 group_type,k.keyword group_id,c.id node,EXISTS(SELECT 1 FROM node eq WHERE eq.file=c.file AND eq.id=c.prev AND node_regex(8,eq.file,eq.id)) valid_max,EXISTS(SELECT 1 FROM node eq WHERE eq.file=c.file AND eq.id=c.prev AND node_regex(8,eq.file,eq.id)) valid_sep FROM keyword_groups k JOIN node c ON c.file=k.file AND c.parent=k.keyword
UNION ALL SELECT p.file,p.arguments,2,p.arguments,p.id,(NOT p.punct AND p.kind NOT IN(215,148,149) AND p.previous_comma AND NOT p.previous_previous_excluded AND p.third_previous_open),(NOT p.punct AND p.kind NOT IN(215,148,149) AND p.first_position) FROM positions p
UNION ALL SELECT a.file,a.arguments,2,a.arguments,a.id,0,0 FROM argument_nodes a WHERE NOT EXISTS(SELECT 1 FROM positions p WHERE p.file=a.file AND p.id=a.id))
SELECT file,NULL call,arguments,1 kind,group_type,group_id,node,valid_max,valid_sep,NULL sep_name,NULL max_name,NULL attribute,NULL receiver_guard,NULL method_guard FROM helper_candidates
UNION ALL SELECT file,NULL,arguments,2,NULL,keyword,NULL,NULL,NULL,sep_name,max_name,NULL,NULL,NULL FROM keyword_groups
UNION ALL SELECT a.file,a.call,NULL,3,NULL,NULL,c.id,NULL,NULL,NULL,NULL,a.id,EXISTS(SELECT 1 FROM receiver_roots r WHERE r.file=a.file AND r.attribute=a.id AND r.node=c.id),EXISTS(SELECT 1 FROM method_calls m WHERE m.file=a.file AND m.attribute=a.id) FROM attributes a LEFT JOIN attribute_children c ON c.file=a.file AND c.attribute=a.id
UNION ALL SELECT c.file,c.id,(SELECT a.id FROM arguments a WHERE a.file=c.file AND a.call=c.id ORDER BY a.id LIMIT 1),4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL FROM calls c