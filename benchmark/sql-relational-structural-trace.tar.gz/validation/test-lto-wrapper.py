#!/usr/bin/env python3
import os, sys
args=sys.argv[1:]
if '--test' in args and '--crate-name' in args and args[args.index('--crate-name')+1]=='rerail_engine':
    args += ['-C','lto=off']
    print('rerail validation: disabled local LTO for the test executable only',file=sys.stderr)
os.execvp(args[0],args)
